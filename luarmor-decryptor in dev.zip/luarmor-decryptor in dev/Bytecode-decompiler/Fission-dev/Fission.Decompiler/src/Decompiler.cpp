#include "Decompiler.hpp"
#include "FissionAllocator.hpp"

#include "AbstractSyntaxTree/Nodes/CommentNode.hpp"
#include "AbstractSyntaxTree/Traversal.hpp"
#include "Analysis/ConstantPropagation.hpp"
#include "Analysis/RobloxTypeInferer.hpp"
#include "Luau/Bytecode.h"
#include "Rewriters/AttributeRenamer.hpp"
#include "Rewriters/ChildLookupRenamer.hpp"
#include "Rewriters/ClassMethodRewriter.hpp"
#include "Rewriters/ConditionFolder.hpp"
#include "Rewriters/ConstLocalMarker.hpp"
#include "Rewriters/ConstructorResultRenamer.hpp"
#include "Rewriters/DeadLocalEliminator.hpp"
#include "Rewriters/DeclarationHoister.hpp"
#include "Rewriters/ExportDeclarationRewriter.hpp"
#include "Rewriters/GetterRenamer.hpp"
#include "Rewriters/GlobalAssignmentRenamer.hpp"
#include "Rewriters/IfChainSimplifier.hpp"
#include "Rewriters/IfExpressionFolder.hpp"
#include "Rewriters/InlineRegionMarker.hpp"
#include "Rewriters/LengthCountRenamer.hpp"
#include "Rewriters/LoopVariableRenamer.hpp"
#include "Rewriters/PcallResultRenamer.hpp"
#include "Rewriters/PropertyRenamer.hpp"
#include "Rewriters/RequireRenamer.hpp"
#include "Rewriters/ReverseFieldRenamer.hpp"
#include "Rewriters/ScopeAwareRenamer.hpp"
#include "Rewriters/ScopeBlockIntroducer.hpp"
#include "Rewriters/SelfAssignmentEliminator.hpp"
#include "Rewriters/ShortCircuitChainFolder.hpp"
#include "Rewriters/ShortCircuitFolder.hpp"
#include "Rewriters/WhileTrueRepeatRewriter.hpp"
#include "SafetyGuard.hpp"
#include "SourceGenerator/AstJsonSerializer.hpp"

#include <libassert/assert.hpp>

#include <algorithm>
#include <chrono>
#include <filesystem>
#include <format>
#include <fstream>
#include <future>
#include <iostream>
#include <optional>
#include <ostream>
#include <sstream>
#include <unordered_map>

#ifdef _WIN32
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <process.h>
#include <windows.h>
#else
#include <pthread.h>
#endif

std::string GetIndentation(int indentationLevel) {
    std::string indent(indentationLevel, ' ');
    return indent;
}

std::string FormatIntList(const std::vector<std::uint32_t> &list) {
    if (list.empty())
        return "[]";
    std::stringstream ss;
    ss << "[";
    for (size_t i = 0; i < list.size(); ++i) {
        ss << list[i];
        if (i < list.size() - 1)
            ss << ", ";
    }
    ss << "]";
    return ss.str();
}

void PrintFunctionOntoStream(std::stringstream &stream, int indentationLevel, const AnalyzedFunction &analyzedFunc) {
    LiftedFunction *rawFunc = analyzedFunc.lpLiftedFunction;

    stream << GetIndentation(indentationLevel) << "/* Function Name: '" << rawFunc->name << "' */\n";
    stream << GetIndentation(indentationLevel) << "/* Basic Blocks: " << analyzedFunc.basicBlocks.size() << " */\n";

    // Reverse definitions annotate each instruction with SSA versions and use counts.
    std::unordered_map<const LiftedInstruction *, std::vector<SSARef>> defsByInst;
    for (const auto &[ref, inst] : analyzedFunc.definitionMap)
        defsByInst[inst].push_back(ref);

    for (const auto &block : analyzedFunc.basicBlocks) {
        stream << "\n";
        stream << GetIndentation(indentationLevel + 2) << "BLOCK_" << block.dwBlockId << ":\n";
        stream << GetIndentation(indentationLevel + 4) << "Type: " << BlockTypeToString(block.bType) << "\n";
        stream << GetIndentation(indentationLevel + 4) << "Terminator: " << BlockTerminatorToString(block.bTerminator) << "\n";
        stream << GetIndentation(indentationLevel + 4) << "Predecessors: " << FormatIntList(block.predecessors) << "\n";
        stream << GetIndentation(indentationLevel + 4) << "Successors:   " << FormatIntList(block.successors) << "\n";
        stream << GetIndentation(indentationLevel + 4) << "Code:\n";

        if (block.lpHead == nullptr || block.lpTail == nullptr) {
            stream << GetIndentation(indentationLevel + 6) << "<Empty/Error Block>\n";
            continue;
        }

        LiftedInstruction *currentInst = block.lpHead;
        while (true) {
            stream << GetIndentation(indentationLevel + 6) << "_" << currentInst->instructionIndex << ": " << OperationToString(currentInst->operation) << " ";

            for (std::size_t i = 0; i < currentInst->operands.size(); i++) {
                const auto &operand = currentInst->operands[i];
                switch (operand.type) {
                case LiftedOperandType::Register:
                    stream << "R" << std::to_string(operand.value.reg) << "#" << std::to_string(operand.ssaVersion);
                    break;
                case LiftedOperandType::ImmediateNil:
                    stream << "nil";
                    break;
                case LiftedOperandType::ImmediateInteger:
                    stream << std::format("0x{:X}", static_cast<uint32_t>(operand.value.imm.n));
                    break;
                case LiftedOperandType::ImmediateBool:
                    stream << std::format("{}", operand.value.imm.b ? "true" : "false");
                    break;
                case LiftedOperandType::ImmediateConstant:
                    stream << "K" << std::to_string(operand.value.imm.k);
                    break;
                case LiftedOperandType::ImmediateAux:
                    stream << "AUXV_" << std::to_string(operand.value.imm.u);
                    break;
                default:
                    ASSERT(false, "unhandled mapping of operand to text");
                }
                if (i + 1 != currentInst->operands.size())
                    stream << ", ";
            }

            if (currentInst->instructionRemarks)
                stream << " /* " << *currentInst->instructionRemarks << " */";

            // Single-use definitions expose unexpected spill decisions in diagnostic output.
            if (const auto defIt = defsByInst.find(currentInst); defIt != defsByInst.end() && !defIt->second.empty()) {
                stream << " /* SSA def:";
                for (const auto &ref : defIt->second) {
                    const auto ucIt = analyzedFunc.useCounts.find(ref);
                    const int32_t uses = (ucIt != analyzedFunc.useCounts.end()) ? ucIt->second : 0;
                    stream << " R" << std::to_string(ref.regIndex) << "#" << std::to_string(ref.version) << "(uses=" << uses << ")";
                }
                stream << " */";
            }
            // Include call, SETLIST, and RETURN reads not represented by explicit operands.
            if (const auto iuIt = analyzedFunc.implicitUses.find(currentInst); iuIt != analyzedFunc.implicitUses.end() && !iuIt->second.empty()) {
                stream << " /* implicit-use versions: [";
                for (size_t j = 0; j < iuIt->second.size(); ++j) {
                    stream << iuIt->second[j];
                    if (j + 1 != iuIt->second.size())
                        stream << ", ";
                }
                stream << "] */";
            }

            stream << "\n";

            if (currentInst == block.lpTail)
                break;

            currentInst++;
        }
    }

    if (analyzedFunc.innerFunctions.empty())
        stream << "\n" << GetIndentation(indentationLevel) << "/* There are no nested functions inside of this function. */" << "\n";
    else
        stream << "\n" << GetIndentation(indentationLevel) << "/* Functions inside of Function (size: " << analyzedFunc.innerFunctions.size() << ") */" << "\n";

    for (const auto &subfunction : analyzedFunc.innerFunctions)
        PrintFunctionOntoStream(stream, indentationLevel + 4, subfunction);
}

std::string FormatAnalyzedIR(const AnalyzedFunction &func) {
    std::stringstream sstream;

    sstream << "/* Fission IR Viewer */\n";
    sstream << "/* Created by Fission Contributors */\n";
    sstream << GetIndentation(4) << "/* Program Root (Main Procedure/Prototype/Function) */\n";
    PrintFunctionOntoStream(sstream, 4, func);

    return sstream.str();
}

void writefile(const std::filesystem::path &path, const std::string &content) {
    std::ofstream file(path);

    if (!file.is_open())
        return;

    file << content;
    file.close();
}

std::optional<std::string> readfile(const std::filesystem::path &path, const bool isBinary = false) {
    auto mode = std::ios::ate;
    if (isBinary)
        mode |= std::ios::binary;

    std::ifstream file(path, mode);

    if (!file.is_open())
        return std::nullopt;

    std::streamsize size = file.tellg();

    file.seekg(0, std::ios::beg);

    std::string buffer(size, '\0');

    file.read(&buffer[0], size);
    // Trim after CRLF translation or a short read.
    buffer.resize(static_cast<size_t>(file.gcount()));
    return buffer;
}

static std::string FormatDecompilerOptions(DecompilerFlags flags) {
    std::vector<std::string> enabled;
    if ((flags & DecompilerFlags::PrintIR) == DecompilerFlags::PrintIR)
        enabled.emplace_back("PrintIR");
    if ((flags & DecompilerFlags::WriteIRToFile) == DecompilerFlags::WriteIRToFile)
        enabled.emplace_back("WriteIRToFile");
    if ((flags & DecompilerFlags::GenerateIRGraph) == DecompilerFlags::GenerateIRGraph)
        enabled.emplace_back("GenerateIRGraph");
    if ((flags & DecompilerFlags::GenerateSSAIRGraph) == DecompilerFlags::GenerateSSAIRGraph)
        enabled.emplace_back("GenerateSSAIRGraph");
    if ((flags & DecompilerFlags::PrintTimingBreakdown) == DecompilerFlags::PrintTimingBreakdown)
        enabled.emplace_back("PrintTimingBreakdown");
    if ((flags & DecompilerFlags::InferTypes) == DecompilerFlags::InferTypes)
        enabled.emplace_back("InferTypes");
    if ((flags & DecompilerFlags::OptimizeIR) == DecompilerFlags::OptimizeIR)
        enabled.emplace_back("OptimizeIR");
    if ((flags & DecompilerFlags::InferRobloxTypes) == DecompilerFlags::InferRobloxTypes)
        enabled.emplace_back("InferRobloxTypes");
    if ((flags & DecompilerFlags::AutoNameVariables) == DecompilerFlags::AutoNameVariables)
        enabled.emplace_back("AutoNameVariables");
    if ((flags & DecompilerFlags::OmitFissionComments) == DecompilerFlags::OmitFissionComments)
        enabled.emplace_back("OmitFissionComments");
    if ((flags & DecompilerFlags::RecoverInline) == DecompilerFlags::RecoverInline)
        enabled.emplace_back("RecoverInline");
    if (enabled.empty())
        return "None";

    std::string result = enabled.front();
    for (size_t i = 1; i < enabled.size(); ++i)
        result += ", " + enabled[i];
    return result;
}

static void AddDecompilerOptionsToHeader(ASTFunction &ast, DecompilerFlags flags) {
    if (ast.statements.empty())
        return;
    auto header = std::dynamic_pointer_cast<CommentNode>(ast.statements.front());
    if (!header)
        return;
    header->comment += "\n    Decompile Options: " + FormatDecompilerOptions(flags);
}

static std::shared_ptr<Expression> MakeTypeAnnotation(const std::string &typeName) {
    return Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(typeName));
}

static std::optional<std::string> GetSimpleIdentifierName(const std::shared_ptr<Expression> &expr) {
    if (auto id = std::dynamic_pointer_cast<IdentifierExpressionNode>(expr); id && id->identifier)
        return id->identifier->name;
    if (auto id = std::dynamic_pointer_cast<Identifier>(expr))
        return id->name;
    return std::nullopt;
}

static std::optional<std::string> InferExpressionType(const std::shared_ptr<Expression> &expr) {
    if (!expr)
        return std::nullopt;
    if (AsLiteral<NilLiteralNode>(expr))
        return "nil";
    if (AsLiteral<BooleanLiteralNode>(expr))
        return "boolean";
    if (AsLiteral<NumberLiteralNode>(expr) || AsLiteral<IntegerLiteralNode>(expr))
        return "number";
    if (AsLiteral<StringLiteralNode>(expr))
        return "string";
    if (AsLiteral<TableLiteralNode>(expr))
        return "table";
    if (std::dynamic_pointer_cast<FunctionDeclarationNode>(expr))
        return "function";
    if (auto unary = std::dynamic_pointer_cast<UnaryExpressionNode>(expr)) {
        if (unary->op == "not ")
            return "boolean";
        if (unary->op == "-" || unary->op == "#")
            return "number";
    }
    if (auto binary = std::dynamic_pointer_cast<BinaryExpressionNode>(expr)) {
        if (binary->op == "<" || binary->op == ">" || binary->op == "<=" || binary->op == ">=" || binary->op == "==" || binary->op == "~=")
            return "boolean";
        if (binary->op == "..")
            return "string";
        if (binary->op == "+" || binary->op == "-" || binary->op == "*" || binary->op == "/" || binary->op == "//" || binary->op == "%" || binary->op == "^")
            return "number";
    }
    return std::nullopt;
}

struct TypeFact {
    std::vector<std::string> concrete;
    bool sawNil = false;

    void Add(const std::optional<std::string> &type) {
        if (!type)
            return;
        if (*type == "nil") {
            sawNil = true;
            return;
        }
        if (std::ranges::find(concrete, *type) == concrete.end())
            concrete.push_back(*type);
    }

    std::optional<std::string> Resolve() const {
        if (concrete.empty())
            return std::nullopt;
        std::string type = concrete.front();
        for (size_t i = 1; i < concrete.size(); ++i)
            type += " | " + concrete[i];
        if (sawNil)
            type += " | nil";
        return type;
    }
};

using FunctionMap = std::unordered_map<std::string, std::vector<std::shared_ptr<FunctionDeclarationNode>>>;

static void CollectFunctionsFromExpression(const std::shared_ptr<Expression> &expr, FunctionMap &functions);
static void CollectFunctionsFromStatements(const std::vector<std::shared_ptr<Statement>> &stmts, FunctionMap &functions);

static void CollectFunctionsFromExpression(const std::shared_ptr<Expression> &expr, FunctionMap &functions) {
    if (expr && expr->nodeKind == ASTNodeKind::FunctionDeclarationNode) {
        const auto fn = std::static_pointer_cast<FunctionDeclarationNode>(expr);
        if (!fn->functionName.empty())
            functions[fn->functionName].push_back(fn);
        if (fn->lpFunctionBody)
            CollectFunctionsFromStatements(fn->lpFunctionBody->body, functions);
    } else if (expr) {
        ForEachSubExpression(expr, [&](const std::shared_ptr<Expression> &child) { CollectFunctionsFromExpression(child, functions); });
    }
}

static void CollectFunctionsFromStatements(const std::vector<std::shared_ptr<Statement>> &stmts, FunctionMap &functions) {
    for (const auto &stmt : stmts) {
        if (stmt && stmt->nodeKind == ASTNodeKind::FunctionDeclarationNode) {
            const auto fn = std::static_pointer_cast<FunctionDeclarationNode>(stmt);
            CollectFunctionsFromExpression(fn, functions);
            continue;
        }
        ForEachStatementExpression(stmt, [&](const std::shared_ptr<Expression> &expr) { CollectFunctionsFromExpression(expr, functions); });
        ForEachChildBlock(stmt, [&](const std::vector<std::shared_ptr<Statement>> &body) { CollectFunctionsFromStatements(body, functions); });
    }
}

using InferenceFacts = std::unordered_map<FunctionDeclarationNode *, std::vector<TypeFact>>;

static void AddIdentifierUseFact(const std::shared_ptr<Expression> &expr, const std::string &argName, const std::string &type, TypeFact &fact) {
    auto ident = GetSimpleIdentifierName(expr);
    if (ident && *ident == argName)
        fact.Add(type);
}

static void CollectBodyUseFactsFromExpression(const std::shared_ptr<Expression> &expr, const std::string &argName, TypeFact &fact) {
    if (!expr)
        return;

    if (auto binary = std::dynamic_pointer_cast<BinaryExpressionNode>(expr)) {
        if (binary->op == "+" || binary->op == "-" || binary->op == "*" || binary->op == "/" || binary->op == "//" || binary->op == "%" || binary->op == "^") {
            AddIdentifierUseFact(binary->left, argName, "number", fact);
            AddIdentifierUseFact(binary->right, argName, "number", fact);
        } else if (binary->op == "..") {
            AddIdentifierUseFact(binary->left, argName, "string", fact);
            AddIdentifierUseFact(binary->right, argName, "string", fact);
        } else if (binary->op == "<" || binary->op == ">" || binary->op == "<=" || binary->op == ">=" || binary->op == "==" || binary->op == "~=") {
            AddIdentifierUseFact(binary->left, argName, InferExpressionType(binary->right).value_or("unknown"), fact);
            AddIdentifierUseFact(binary->right, argName, InferExpressionType(binary->left).value_or("unknown"), fact);
        }
    } else if (auto unary = std::dynamic_pointer_cast<UnaryExpressionNode>(expr)) {
        if (unary->op == "not ")
            AddIdentifierUseFact(unary->operand, argName, "boolean", fact);
        else if (unary->op == "-" || unary->op == "#")
            AddIdentifierUseFact(unary->operand, argName, "number", fact);
    } else if (auto index = std::dynamic_pointer_cast<IndexExpressionNode>(expr)) {
        AddIdentifierUseFact(index->left, argName, "table", fact);
    } else if (auto member = std::dynamic_pointer_cast<MemberExpressionNode>(expr)) {
        AddIdentifierUseFact(member->table, argName, "table", fact);
    } else if (auto nameCall = std::dynamic_pointer_cast<NameCallExpressionNode>(expr)) {
        AddIdentifierUseFact(nameCall->calledOn, argName, "table", fact);
    }
    ForEachSubExpression(expr, [&](const std::shared_ptr<Expression> &child) { CollectBodyUseFactsFromExpression(child, argName, fact); });
}

static void CollectBodyUseFactsFromStatements(const std::vector<std::shared_ptr<Statement>> &stmts, const std::string &argName, TypeFact &fact) {
    for (const auto &stmt : stmts) {
        if (std::dynamic_pointer_cast<FunctionDeclarationNode>(stmt))
            continue;
        if (auto ifStmt = std::dynamic_pointer_cast<IfStatementNode>(stmt))
            AddIdentifierUseFact(ifStmt->condition, argName, "boolean", fact);
        else if (auto whileStmt = std::dynamic_pointer_cast<WhileStatementNode>(stmt))
            AddIdentifierUseFact(whileStmt->condition, argName, "boolean", fact);
        else if (auto repeatStmt = std::dynamic_pointer_cast<RepeatStatementNode>(stmt))
            AddIdentifierUseFact(repeatStmt->condition, argName, "boolean", fact);
        ForEachStatementExpression(stmt, [&](const std::shared_ptr<Expression> &expr) { CollectBodyUseFactsFromExpression(expr, argName, fact); });
        ForEachChildBlock(stmt, [&](const std::vector<std::shared_ptr<Statement>> &body) { CollectBodyUseFactsFromStatements(body, argName, fact); });
    }
}

static std::optional<std::string> InferArgumentTypeFromBody(FunctionDeclarationNode *fn, size_t argIndex) {
    if (!fn->argumentsNames.contains(static_cast<int32_t>(argIndex)) || !fn->lpFunctionBody)
        return std::nullopt;
    auto argName = GetSimpleIdentifierName(fn->argumentsNames.at(static_cast<int32_t>(argIndex))->argumentName);
    if (!argName)
        return std::nullopt;
    TypeFact fact;
    CollectBodyUseFactsFromStatements(fn->lpFunctionBody->body, *argName, fact);
    return fact.Resolve();
}

static void CollectCallFactsFromExpression(const std::shared_ptr<Expression> &expr, const FunctionMap &functions, InferenceFacts &facts);
static void CollectCallFactsFromStatements(const std::vector<std::shared_ptr<Statement>> &stmts, const FunctionMap &functions, InferenceFacts &facts);

static void CollectCallFactsFromExpression(const std::shared_ptr<Expression> &expr, const FunctionMap &functions, InferenceFacts &facts) {
    if (!expr)
        return;

    if (expr->nodeKind == ASTNodeKind::CallExpression) {
        const auto call = std::static_pointer_cast<CallExpressionNode>(expr);
        auto calleeName = GetSimpleIdentifierName(call->callee);
        const auto found = calleeName ? functions.find(*calleeName) : functions.end();
        if (found != functions.end() && found->second.size() == 1) {
            auto *fn = found->second.front().get();
            auto &fnFacts = facts[fn];
            if (fnFacts.size() < static_cast<size_t>(fn->argumentCount))
                fnFacts.resize(fn->argumentCount);
            for (size_t i = 0; i < call->arguments.size() && i < fnFacts.size(); ++i)
                fnFacts[i].Add(InferExpressionType(call->arguments[i]));
        }
    }
    if (expr->nodeKind == ASTNodeKind::FunctionDeclarationNode) {
        const auto fn = std::static_pointer_cast<FunctionDeclarationNode>(expr);
        if (fn->lpFunctionBody)
            CollectCallFactsFromStatements(fn->lpFunctionBody->body, functions, facts);
        else
            ForEachSubExpression(expr, [&](const std::shared_ptr<Expression> &child) { CollectCallFactsFromExpression(child, functions, facts); });
    } else
        ForEachSubExpression(expr, [&](const std::shared_ptr<Expression> &child) { CollectCallFactsFromExpression(child, functions, facts); });
}

static void CollectCallFactsFromStatements(const std::vector<std::shared_ptr<Statement>> &stmts, const FunctionMap &functions, InferenceFacts &facts) {
    for (const auto &stmt : stmts) {
        if (stmt && stmt->nodeKind == ASTNodeKind::FunctionDeclarationNode) {
            const auto fn = std::static_pointer_cast<FunctionDeclarationNode>(stmt);
            CollectCallFactsFromExpression(fn, functions, facts);
            continue;
        }
        ForEachStatementExpression(stmt, [&](const std::shared_ptr<Expression> &expr) { CollectCallFactsFromExpression(expr, functions, facts); });
        ForEachChildBlock(stmt, [&](const std::vector<std::shared_ptr<Statement>> &body) { CollectCallFactsFromStatements(body, functions, facts); });
    }
}

static void AnnotateLocalDeclarations(std::vector<std::shared_ptr<Statement>> &stmts) {
    for (auto &stmt : stmts) {
        if (auto decl = std::dynamic_pointer_cast<VariableDeclarationNode>(stmt)) {
            auto type = InferExpressionType(decl->value);
            if (type && *type != "nil" && *type != "table")
                decl->type = MakeTypeAnnotation(*type);
        } else if (auto fn = std::dynamic_pointer_cast<FunctionDeclarationNode>(stmt); fn && fn->lpFunctionBody) {
            AnnotateLocalDeclarations(fn->lpFunctionBody->body);
        } else {
            ForEachChildBlock(stmt, AnnotateLocalDeclarations);
        }
    }
}

static std::optional<bool> EvaluateBooleanConstant(const std::shared_ptr<Expression> &expr) {
    if (auto boolean = AsLiteral<BooleanLiteralNode>(expr))
        return boolean->value;
    if (auto nil = AsLiteral<NilLiteralNode>(expr)) {
        (void)nil;
        return false;
    }
    if (auto unary = std::dynamic_pointer_cast<UnaryExpressionNode>(expr); unary && unary->op == "not ") {
        auto value = EvaluateBooleanConstant(unary->operand);
        if (value)
            return !*value;
    }
    if (auto binary = std::dynamic_pointer_cast<BinaryExpressionNode>(expr)) {
        const auto compare = [&](const auto left, const auto right) -> std::optional<bool> {
            if (binary->op == "==")
                return left == right;
            if (binary->op == "~=")
                return left != right;
            if (binary->op == "<")
                return left < right;
            if (binary->op == ">")
                return left > right;
            if (binary->op == "<=")
                return left <= right;
            if (binary->op == ">=")
                return left >= right;
            return std::nullopt;
        };
        if (const auto left = AsLiteral<NumberLiteralNode>(binary->left))
            if (const auto right = AsLiteral<NumberLiteralNode>(binary->right))
                return compare(left->value, right->value);
        if (const auto left = AsLiteral<IntegerLiteralNode>(binary->left))
            if (const auto right = AsLiteral<IntegerLiteralNode>(binary->right))
                return compare(left->value, right->value);
    }
    return std::nullopt;
}

static void OptimizeStatements(std::vector<std::shared_ptr<Statement>> &stmts) {
    for (size_t i = 0; i < stmts.size();) {
        if (auto fn = std::dynamic_pointer_cast<FunctionDeclarationNode>(stmts[i]); fn && fn->lpFunctionBody)
            OptimizeStatements(fn->lpFunctionBody->body);
        ForEachChildBlock(stmts[i], OptimizeStatements);
        if (auto ifStmt = std::dynamic_pointer_cast<IfStatementNode>(stmts[i])) {
            auto cond = EvaluateBooleanConstant(ifStmt->condition);
            if (cond) {
                std::vector<std::shared_ptr<Statement>> replacement;
                if (*cond && ifStmt->thenBranch)
                    replacement = ifStmt->thenBranch->body;
                else if (!*cond && ifStmt->elseBranch)
                    replacement = ifStmt->elseBranch->body;
                stmts.erase(stmts.begin() + static_cast<std::ptrdiff_t>(i));
                stmts.insert(stmts.begin() + static_cast<std::ptrdiff_t>(i), replacement.begin(), replacement.end());
                i += replacement.size();
                continue;
            }
        } else if (auto whileStmt = std::dynamic_pointer_cast<WhileStatementNode>(stmts[i])) {
            auto cond = EvaluateBooleanConstant(whileStmt->condition);
            if (cond && !*cond) {
                stmts.erase(stmts.begin() + static_cast<std::ptrdiff_t>(i));
                continue;
            }
        }
        ++i;
    }
}

static void ApplyFunctionArgumentFacts(const FunctionMap &functions, const InferenceFacts &facts) {
    for (const auto &[_, overloads] : functions) {
        for (const auto &fnPtr : overloads) {
            auto *fn = fnPtr.get();
            for (int32_t i = 0; i < fn->argumentCount; ++i) {
                if (!fn->argumentsNames.contains(i) || fn->argumentsNames.at(i)->type)
                    continue;
                std::optional<std::string> type;
                if (facts.contains(fn) && facts.at(fn).size() > static_cast<size_t>(i))
                    type = facts.at(fn)[i].Resolve();
                if (!type)
                    type = InferArgumentTypeFromBody(fn, i);
                if (!type)
                    type = "unknown";
                if (*type != "table")
                    fn->argumentsNames.at(i)->type = MakeTypeAnnotation(*type);
            }
        }
    }
}

static void InferTypes(ASTFunction &ast) {
    FunctionMap functions;
    CollectFunctionsFromStatements(ast.statements, functions);

    InferenceFacts facts;
    CollectCallFactsFromStatements(ast.statements, functions, facts);
    ApplyFunctionArgumentFacts(functions, facts);
    AnnotateLocalDeclarations(ast.statements);
}

static void OptimizeAST(ASTFunction &ast) { OptimizeStatements(ast.statements); }

DecompilationResult
Decompiler::CommonDecompilerEntry(const std::string &bytecode, Fission::InstructionDecoder *decoder, DecompilerFlags flags, uint32_t targetBytecodeId) {
    Fission::ScopedThrowingAssertHandler assertGuard;
    Fission::ScopedDecompileBudget budget(m_decompileBudget);
    const bool debugEnabled = (flags & DecompilerFlags::FissionDebugNotes) == DecompilerFlags::FissionDebugNotes;
    m_debugNotes.Reset(debugEnabled);
    controlFlowAnalyzer.SetDebugNotes(debugEnabled ? &m_debugNotes : nullptr);
    ssaBuilder.SetDebugNotes(debugEnabled ? &m_debugNotes : nullptr);
    astLifter.SetDebugNotes(debugEnabled ? &m_debugNotes : nullptr);
    m_debugNotes.Add(FissionDebugStage::Pipeline, "decompilation started for {} bytecode bytes", bytecode.size());

    struct StageStateRelease {
        ASTLifter &lifter;
        SourceGenerator &generator;
        ~StageStateRelease() {
            lifter.ReleaseRetainedState();
            generator.ReleaseRetainedState();
        }
    } releaseStageState{astLifter, sourceGenerator};

    if (decoder == nullptr) {
        DecompilationResult failure{"", "", "", DecompileResult::FailedToDecompile};
        m_debugNotes.Add(FissionDebugStage::Pipeline, "stopped before deserialization because decoder is null");
        failure.debugNotes = m_debugNotes.Render();
        return failure;
    }

    try {
        auto result = CommonDecompilerEntryImpl(bytecode, decoder, flags, targetBytecodeId);
        result.debugNotes = m_debugNotes.Render();
        return result;
    } catch (const std::exception &error) {
        DecompilationResult failure{};
        failure.resultCode = DecompileResult::FailedToDecompile;
        m_debugNotes.Add(FissionDebugStage::Pipeline, "aborted: {}", error.what());
        failure.debugNotes = m_debugNotes.Render();
#ifndef PRODUCTION_BUILD
        failure.decompilationOutput = std::string("--[[ Fission failed to decompile this chunk: ") + error.what() + " ]]";
#endif
        return failure;
    } catch (...) {
        DecompilationResult failure{"", "", "", DecompileResult::FailedToDecompile};
        m_debugNotes.Add(FissionDebugStage::Pipeline, "aborted with a non-standard exception");
        failure.debugNotes = m_debugNotes.Render();
        return failure;
    }
}

DecompilationResult
Decompiler::CommonDecompilerEntryImpl(const std::string &bytecode, Fission::InstructionDecoder *decoder, DecompilerFlags flags, uint32_t targetBytecodeId) {
    DEBUG_ASSERT(decoder != nullptr);
    DecompilationResult res{};
#ifndef PRODUCTION_BUILD
    if (!bytecode.empty() && bytecode.front() == '\0') {
        res.resultCode = DecompileResult::FailedToDeserialize;
        res.errorMessage = "Nothing to decompile, bytecode is a script error: " + bytecode.substr(1);
        m_debugNotes.Add(FissionDebugStage::Pipeline, "compiler input contains an error diagnostic instead of bytecode");
        return res;
    }
#endif
    const auto deserializeStart = std::chrono::steady_clock::now();
    auto deserializedBytecode = deserializer.Deserialize(bytecode);
    const auto deserializeEnd = std::chrono::steady_clock::now();
    if (!deserializedBytecode || deserializedBytecode->functions.empty()) {
        m_debugNotes.Add(FissionDebugStage::Pipeline, "deserializer produced no functions");
        return {"", "", "", DecompileResult::FailedToDeserialize};
    }
    m_debugNotes.Add(FissionDebugStage::Pipeline, "deserialized {} functions", deserializedBytecode->functions.size());

    if (targetBytecodeId != UINT32_MAX) {
        DeserializedFunction *target = nullptr;
        for (auto &function : deserializedBytecode->functions) {
            if (function.bytecodeId == targetBytecodeId) {
                target = &function;
                break;
            }
        }
        if (!target) {
            m_debugNotes.Add(FissionDebugStage::Pipeline, "requested function {} was not present", targetBytecodeId);
            return {"", "", "", DecompileResult::FailedToDeserialize};
        }
        deserializedBytecode->lpMainFunction = target;
    }

    auto bytecodeLifter = BytecodeLifter{decoder};
    const auto bytecodeLiftStart = std::chrono::steady_clock::now();
    auto liftedBytecode = bytecodeLifter.LiftDeserializedBytecode(*deserializedBytecode);
    const auto bytecodeLiftEnd = std::chrono::steady_clock::now();
    m_debugNotes.Add(
        FissionDebugStage::Pipeline, "bytecode lift produced {} root instructions and {} nested functions", liftedBytecode.instructions.size(),
        liftedBytecode.subfunctions.size()
    );
    const auto inlineSources = BuildInlineSourceMap(*deserializedBytecode, decoder, liftedBytecode);
    AssignInlineOrigins(liftedBytecode, *inlineSources);

    const auto controlFlowAnalyzeStart = std::chrono::steady_clock::now();
    const auto basicBlockIdentificationStart = std::chrono::steady_clock::now();
    auto controlFlowAnalyzedFunction = controlFlowAnalyzer.DetermineBasicBlocks(&liftedBytecode);
    const auto basicBlockIdentificationEnd = std::chrono::steady_clock::now();

    const auto optimizeGraphStart = std::chrono::steady_clock::now();
    controlFlowAnalyzer.OptimizeGraph(controlFlowAnalyzedFunction);
    const auto optimizeGraphEnd = std::chrono::steady_clock::now();

    // Dead code after an infinite loop must not contribute back-edges or exits to live loops.
    const auto unreachablePruningStart = std::chrono::steady_clock::now();
    controlFlowAnalyzer.PruneUnreachable(controlFlowAnalyzedFunction);
    const auto unreachablePruningEnd = std::chrono::steady_clock::now();

    const auto identifyLoopStructuresStart = std::chrono::steady_clock::now();
    controlFlowAnalyzer.IdentifyStructures(controlFlowAnalyzedFunction);
    const auto identifyLoopStructuresEnd = std::chrono::steady_clock::now();
    const auto controlFlowAnalyzeEnd = std::chrono::steady_clock::now();
    m_debugNotes.Add(FissionDebugStage::Pipeline, "CFA retained {} root blocks", controlFlowAnalyzedFunction.basicBlocks.size());

    const auto ssaStart = std::chrono::steady_clock::now();
    ssaBuilder.Build(controlFlowAnalyzedFunction);
    const auto ssaEnd = std::chrono::steady_clock::now();
    m_debugNotes.Add(FissionDebugStage::Pipeline, "SSA recorded {} root definitions", controlFlowAnalyzedFunction.definitionMap.size());

    const auto irOptimizationStart = std::chrono::steady_clock::now();
    if ((flags & DecompilerFlags::OptimizeIR) == DecompilerFlags::OptimizeIR) {
        while (Fission::ConstantPropagation{}.Run(controlFlowAnalyzedFunction).Changed()) {
            controlFlowAnalyzedFunction = controlFlowAnalyzer.DetermineBasicBlocks(&liftedBytecode);
            controlFlowAnalyzer.OptimizeGraph(controlFlowAnalyzedFunction);
            controlFlowAnalyzer.PruneUnreachable(controlFlowAnalyzedFunction);
            controlFlowAnalyzer.IdentifyStructures(controlFlowAnalyzedFunction);
            ssaBuilder.Build(controlFlowAnalyzedFunction);
        }
    }
    if ((flags & DecompilerFlags::RecoverInline) == DecompilerFlags::RecoverInline && RecoverInlinedCalls(controlFlowAnalyzedFunction, *inlineSources)) {
        controlFlowAnalyzedFunction = controlFlowAnalyzer.DetermineBasicBlocks(&liftedBytecode);
        controlFlowAnalyzer.OptimizeGraph(controlFlowAnalyzedFunction);
        controlFlowAnalyzer.PruneUnreachable(controlFlowAnalyzedFunction);
        controlFlowAnalyzer.IdentifyStructures(controlFlowAnalyzedFunction);
        ssaBuilder.Build(controlFlowAnalyzedFunction);
    }
    const auto irOptimizationEnd = std::chrono::steady_clock::now();

    const auto astStart = std::chrono::steady_clock::now();
    astLifter.SetInlineSources(inlineSources);
    auto liftedAST = astLifter.Lift(controlFlowAnalyzedFunction);
    AddDecompilerOptionsToHeader(liftedAST, flags);
    const size_t statementsBeforeRewrite = liftedAST.statements.size();

    const auto astRewriteStart = std::chrono::steady_clock::now();
    std::string rewriterTimings;
    const auto timeRewriter = [&](const char *name, auto &&run) {
        const auto start = std::chrono::steady_clock::now();
        run();
        if ((flags & DecompilerFlags::PrintTimingBreakdown) == DecompilerFlags::PrintTimingBreakdown)
            rewriterTimings += std::format("\t\t{}: {}\n", name, std::chrono::duration<float>(std::chrono::steady_clock::now() - start));
    };
    timeRewriter("Inline Region Marker", [&] { InlineRegionMarker{inlineSources}.Run(liftedAST.statements); });
    timeRewriter("Short-Circuit Chain Folder", [&] { ShortCircuitChainFolder{}.Run(liftedAST.statements); });
    // Hoisting must run while names still identify registers and before later passes reshape scopes.
    timeRewriter("Declaration Hoister 1", [&] { DeclarationHoister{}.Run(liftedAST.statements); });

    timeRewriter("Short-Circuit Folder", [&] { ShortCircuitFolder{}.Run(liftedAST.statements); });
    // Conditions feed the loop and branch shape decisions below, so normalize them first.
    timeRewriter("Condition Folder", [&] { ConditionFolder{}.Run(liftedAST.statements); });
    timeRewriter("While-True Repeat Rewriter", [&] { WhileTrueRepeatRewriter{}.Run(liftedAST.statements); });
    // Method reconstruction must precede dead-local elimination.
    timeRewriter("Class Method Rewriter", [&] { ClassMethodRewriter{}.Run(liftedAST.statements); });
    timeRewriter("Declaration Hoister 2", [&] { DeclarationHoister{}.Run(liftedAST.statements); });
    timeRewriter("Dead Local Eliminator 1", [&] { DeadLocalEliminator{}.Run(liftedAST.statements); });
    timeRewriter("Self-Assignment Eliminator", [&] { SelfAssignmentEliminator{}.Run(liftedAST.statements); });
    timeRewriter("If-Chain Simplifier", [&] { IfChainSimplifier{}.Run(liftedAST.statements); });
    // The if-chain pass flattens `if c then break else rest end` into a leading guard, so loop guards
    // are only foldable once it has run. The earlier run normalizes conditions for its branch decisions.
    timeRewriter("Condition Folder 2", [&] { ConditionFolder{}.Run(liftedAST.statements); });
    timeRewriter("Child Lookup Renamer", [&] { ChildLookupRenamer{}.Run(liftedAST.statements); });
    timeRewriter("Require Renamer", [&] { RequireRenamer{}.Run(liftedAST.statements); });
    timeRewriter("Getter Renamer", [&] { GetterRenamer{}.Run(liftedAST.statements); });
    timeRewriter("Attribute Renamer", [&] { AttributeRenamer{}.Run(liftedAST.statements); });
    timeRewriter("Property Renamer", [&] { PropertyRenamer{}.Run(liftedAST.statements); });
    timeRewriter("Constructor Result Renamer", [&] { ConstructorResultRenamer{}.Run(liftedAST.statements); });
    timeRewriter("Length Count Renamer", [&] { LengthCountRenamer{}.Run(liftedAST.statements); });
    timeRewriter("Pcall Result Renamer", [&] { PcallResultRenamer{}.Run(liftedAST.statements); });
    timeRewriter("Loop Variable Renamer", [&] { LoopVariableRenamer{}.Run(liftedAST.statements); });
    // Assignment-based naming is weakest and runs after source-based naming.
    timeRewriter("Reverse Field Renamer", [&] { ReverseFieldRenamer{}.Run(liftedAST.statements); });
    timeRewriter("Global Assignment Renamer", [&] { GlobalAssignmentRenamer{}.Run(liftedAST.statements); });
    // Fold branch assignments before scope blocks separate declarations from their diamonds.
    timeRewriter("If-Expression Folder", [&] { IfExpressionFolder{}.Run(liftedAST.statements); });
    // Value diamonds only become plain assignments after the if-expression fold, so the and-chain
    // terminal shape is complete here; dead-local elimination below then drops the emptied bindings.
    timeRewriter("And-Chain Folder", [&] { AndChainFolder{}.Run(liftedAST.statements); });
    timeRewriter("Dead Local Eliminator 2", [&] { DeadLocalEliminator{}.Run(liftedAST.statements); });

    // Scope blocks run last against final statement lifetimes.
    timeRewriter("Scope Block Introducer", [&] { ScopeBlockIntroducer{}.Run(liftedAST.statements); });
    timeRewriter("Declaration Hoister 3", [&] { DeclarationHoister{}.Run(liftedAST.statements); });
    const auto astRewriteEnd = std::chrono::steady_clock::now();
    m_debugNotes.Add(
        FissionDebugStage::Pipeline, "AST rewrites changed root statement count from {} to {}", statementsBeforeRewrite, liftedAST.statements.size()
    );

    if ((flags & DecompilerFlags::OptimizeIR) == DecompilerFlags::OptimizeIR)
        OptimizeAST(liftedAST);

    const auto typeInferenceStart = std::chrono::steady_clock::now();
    if ((flags & DecompilerFlags::InferTypes) == DecompilerFlags::InferTypes)
        InferTypes(liftedAST);
    const auto typeInferenceEnd = std::chrono::steady_clock::now();

    const auto robloxPropagationStart = std::chrono::steady_clock::now();
    const auto inferRobloxTypes = (flags & DecompilerFlags::InferRobloxTypes) == DecompilerFlags::InferRobloxTypes;
    const auto autoNameVariables = (flags & DecompilerFlags::AutoNameVariables) == DecompilerFlags::AutoNameVariables;
    if (inferRobloxTypes || autoNameVariables)
        RobloxTypeInferer{}.Infer(liftedAST, inferRobloxTypes, autoNameVariables);
    if (deserializedBytecode->lpMainFunction->flags & LPF_USES_EXPORT)
        ExportDeclarationRewriter::Run(liftedAST.statements);
    ScopeAwareRenamer::PruneStaleRenameComments(liftedAST.statements);
    ConstLocalMarker{}.Run(liftedAST.statements);
    const auto robloxPropagationEnd = std::chrono::steady_clock::now();

    RootNode root{liftedAST.statements};

    sourceGenerator.bOmitInformationalComments = (flags & DecompilerFlags::OmitFissionComments) == DecompilerFlags::OmitFissionComments;
    sourceGenerator.vectorConstructor = dynamic_cast<Fission::RobloxClientDecoder *>(decoder) ? "Vector3.new" : "vector.create";
    const auto sgenStart = std::chrono::steady_clock::now();
    auto generator = sourceGenerator.GenerateSource(&root);
    if (sourceGenerator.SawVectorConstant()) {
        std::string alias = "__fissionVectorCtor";
        while (generator.find(alias) != std::string::npos)
            alias += '_';
        generator = sourceGenerator.GenerateSource(&root, std::move(alias));
    }
    const auto sgenEnd = std::chrono::steady_clock::now();
    m_debugNotes.Add(FissionDebugStage::Pipeline, "source generation emitted {} bytes", generator.size());

    const auto printIR = (flags & DecompilerFlags::PrintIR) == DecompilerFlags::PrintIR;
    if (printIR) // debug echo only; unconditional writes to std::cout race across threads and spam embedders
        std::cout << "generated source code:\n" << generator << '\n';

    const auto writeIR = (flags & DecompilerFlags::WriteIRToFile) == DecompilerFlags::WriteIRToFile;
    const auto omitIR = (flags & DecompilerFlags::OmitIR) == DecompilerFlags::OmitIR;
    auto formattedIR = !omitIR || printIR || writeIR ? FormatAnalyzedIR(controlFlowAnalyzedFunction) : std::string{};
    if (printIR || writeIR) {
        if (writeIR)
            writefile(std::filesystem::path{"ir_out.txt"}, formattedIR);
    }

    const auto generateIRGraph = (flags & DecompilerFlags::GenerateIRGraph) == DecompilerFlags::GenerateIRGraph;
    const auto generateSSAGraph = (flags & DecompilerFlags::GenerateSSAIRGraph) == DecompilerFlags::GenerateSSAIRGraph;
    if (generateIRGraph || generateSSAGraph) {
        const auto dotGraph = visualizer.GenerateDotGraph(
            controlFlowAnalyzedFunction, generateIRGraph && generateSSAGraph ? GraphContent::Both
                                         : generateIRGraph == true           ? GraphContent::IROnly
                                                                             : GraphContent::SSAOnly
        );

        writefile("cfg.dot", dotGraph);
    }

    // Capture requested server artifacts without file I/O.
    if ((flags & DecompilerFlags::CaptureCFGGraph) == DecompilerFlags::CaptureCFGGraph) {
        const bool includeSSA = (flags & DecompilerFlags::FissionDebugNotes) == DecompilerFlags::FissionDebugNotes;
        res.cfgGraph = GraphVisualizer::GenerateDotGraph(controlFlowAnalyzedFunction, includeSSA ? GraphContent::SSAOnly : GraphContent::IROnly);
    }

    if ((flags & DecompilerFlags::CaptureAST) == DecompilerFlags::CaptureAST) {
        AstJsonSerializer astSerializer{};
        res.astJson = astSerializer.Serialize(&root);
    }

    if ((flags & DecompilerFlags::PrintTimingBreakdown) == DecompilerFlags::PrintTimingBreakdown) {
        res.timingStatistics = std::format(
            "Decompilation Breakdown:\n\t"
            "Deserializing Bytecode: {}\n\t"
            "Lifting into IR: {}\n\t"
            "Control Flow Analysis: {}\n\t"
            "\tDetermining Basic Blocks: {}\n\t"
            "\tGraph Optimization: {}\n\t"
            "\tBlock Pruning: {}\n\t"
            "\tStructure Identification: {}\n\t"
            "IR -> SSA Form: {}\n\t"
            "IR (SSA) -> AST: {}\n\t"
            "AST Rewriting: {}\n{}\t"
            "AST -> Source Code: {}\n\t"
            "IR Optimization: {}\n\t"
            "Type Propagation: {}\n\t"
            "Roblox TypeName/Name Propagation: {}",
            std::chrono::duration<float>(deserializeEnd - deserializeStart), std::chrono::duration<float>(bytecodeLiftEnd - bytecodeLiftStart),
            std::chrono::duration<float>(controlFlowAnalyzeEnd - controlFlowAnalyzeStart),
            std::chrono::duration<float>(basicBlockIdentificationEnd - basicBlockIdentificationStart),
            std::chrono::duration<float>(optimizeGraphEnd - optimizeGraphStart), std::chrono::duration<float>(unreachablePruningEnd - unreachablePruningStart),
            std::chrono::duration<float>(identifyLoopStructuresEnd - identifyLoopStructuresStart), std::chrono::duration<float>(ssaEnd - ssaStart),
            std::chrono::duration<float>(astRewriteStart - astStart), std::chrono::duration<float>(astRewriteEnd - astRewriteStart), rewriterTimings,
            std::chrono::duration<float>(sgenEnd - sgenStart), std::chrono::duration<float>(irOptimizationEnd - irOptimizationStart),
            std::chrono::duration<float>(typeInferenceEnd - typeInferenceStart), std::chrono::duration<float>(robloxPropagationEnd - robloxPropagationStart)
        );
    }

    res.irOutput = std::move(formattedIR);
    res.resultCode = DecompileResult::Success;
    res.decompilationOutput = std::move(generator);
    return res;
}

namespace {
    // Luau's parser recurses once per nesting level with large (especially debug) frames, so a few
    // hundred nested constructors overflow the calling thread before Luau's own recursion limit can
    // fire. Compile on a dedicated thread with room to spare; the decompile below keeps running on
    // the caller's stack, so a decompiler-side overflow still surfaces instead of hiding behind this
    // bigger one.
    constexpr size_t kLuauCompileStackSize = 8u * 1024u * 1024u;

    struct CompileArgs {
        const std::string *source;
        const Luau::CompileOptions *options;
        std::promise<std::string> *done;
    };

    void RunLuauCompile(CompileArgs *args) {
        try {
            args->done->set_value(Luau::compile(*args->source, *args->options));
        } catch (...) {
            args->done->set_exception(std::current_exception());
        }
    }

#ifdef _WIN32
    unsigned __stdcall CompileThreadMain(void *param) {
        RunLuauCompile(static_cast<CompileArgs *>(param));
        return 0;
    }
#else
    void *CompileThreadMain(void *param) {
        RunLuauCompile(static_cast<CompileArgs *>(param));
        return nullptr;
    }
#endif

    std::string CompileOnLargeStack(const std::string &source, const Luau::CompileOptions &options) {
        std::promise<std::string> done;
        CompileArgs args{&source, &options, &done};
        std::future<std::string> result = done.get_future();
#ifdef _WIN32
        // _beginthreadex (not CreateThread) so the CRT the parser allocates with is per-thread ready.
        const uintptr_t thread = _beginthreadex(nullptr, static_cast<unsigned>(kLuauCompileStackSize), &CompileThreadMain, &args, 0, nullptr);
        if (thread == 0)
            return Luau::compile(source, options); // same as before when no thread is available
        // NOLINTNEXTLINE(cppcoreguidelines-pro-type-reinterpret-cast): Win32 thread APIs traffic in HANDLE.
        auto handle = reinterpret_cast<HANDLE>(thread);
        WaitForSingleObject(handle, INFINITE);
        CloseHandle(handle);
#else
        pthread_attr_t attr{};
        pthread_t thread{};
        bool created = pthread_attr_init(&attr) == 0;
        if (created) {
            created = pthread_attr_setstacksize(&attr, kLuauCompileStackSize) == 0 && pthread_create(&thread, &attr, &CompileThreadMain, &args) == 0;
            pthread_attr_destroy(&attr);
        }
        if (!created)
            return Luau::compile(source, options); // same as before when no thread is available
        pthread_join(thread, nullptr);
#endif
        return result.get(); // rethrows a compile failure on the caller thread
    }
} // namespace

DecompilationResult Decompiler::DecompileTestCode(const std::string &testCode, const DecompilerFlags flags, const Luau::CompileOptions &compileOpts) {
    try {
        const auto compiledBytecode = CompileOnLargeStack(testCode, compileOpts);
        auto normalDecoder = Fission::InstructionDecoder{};
        return CommonDecompilerEntry(compiledBytecode, &normalDecoder, flags);
    } catch (...) {
        return {"", "", "", DecompileResult::FailedToDecompile};
    }
}

DecompilationResult Decompiler::DecompileTestCodeFromFile(const std::string &fileName, const DecompilerFlags flags, const Luau::CompileOptions &compileOpts) {
    const auto readFile = readfile(std::filesystem::path(fileName));
    if (!readFile)
        return {"", "", "", DecompileResult::FailedToReadFile};

    return DecompileTestCode(*readFile, flags, compileOpts);
}

DecompilationResult Decompiler::DecompileVanillaBytecode(const std::string &bytecode, DecompilerFlags flags) {
    auto normalDecoder = Fission::InstructionDecoder{};
    return CommonDecompilerEntry(bytecode, &normalDecoder, flags);
}

DecompilationResult Decompiler::DecompileVanillaFunction(const std::string &bytecode, uint32_t bytecodeId, DecompilerFlags flags) {
    auto normalDecoder = Fission::InstructionDecoder{};
    return CommonDecompilerEntry(bytecode, &normalDecoder, flags, bytecodeId);
}

DecompilationResult Decompiler::DecompileRobloxBytecode(const std::string &bytecode, DecompilerFlags flags) {
    auto robloxDecoder = Fission::RobloxClientDecoder{};
    return CommonDecompilerEntry(bytecode, &robloxDecoder, flags);
}

DecompilationResult Decompiler::DecompileRobloxBytecodeFromFile(const std::string &fileName, DecompilerFlags flags) {
    const auto readFile = readfile(std::filesystem::path(fileName), true);
    if (!readFile)
        return {"", "", "", DecompileResult::FailedToReadFile};

    return DecompileRobloxBytecode(*readFile, flags);
}

//
// Created by Dottik on 23/9/2026.
//

#include "ASTLifter.hpp"
#include "ASTLifterShared.hpp"
#include "FissionAllocator.hpp"
#include "FloatingPointClassify.hpp"
#include "SafetyGuard.hpp"

#include <algorithm>
#include <functional>
#include <ranges>
#include <unordered_map>
#include <unordered_set>

#ifndef NDEBUG
#if defined(__clang__)
#pragma clang optimize off
#endif
#endif

// Luau's builtin metadata (Compiler/src/Builtins.h is internal); the layout mirrors Luau's and resolves against Luau.Compiler.
namespace Luau::Compile {
    struct BuiltinInfo {
        int params;
        int results;
        unsigned int flags;
    };
    BuiltinInfo getBuiltinInfo(int bfid);
} // namespace Luau::Compile

// Length-boundary fidelity helper (defined below): construction history is observable via `#`
// on holey tables, so the lifter must preserve it there.
struct TableLengthWindow {
    bool isNewtable = false;
    int32_t hintHashRaw = -1;                 // NEWTABLE B operand (encoded hash size); -1 when not NEWTABLE
    int32_t hintArray = 0;                    // NEWTABLE AUX array size; 0 when not NEWTABLE
    int32_t sequentialArrayPred = 0;          // TableShape rule over direct numeric stores, in order
    size_t distinctDotKeys = 0;               // distinct string-constant keys of window SETTABLEKS stores
    bool possibleHole = false;                // nil-able index with a later non-nil index (absolute)
    bool bulkHole = false;                    // a later bulk SETLIST with an interior nil (relative positions)
    std::unordered_set<int32_t> storeIndices; // instruction indices of the window's stores
};
static TableLengthWindow AnalyzeTableLengthWindow(const AnalyzedFunction *function, const LiftedInstruction &inst, int32_t tableReg, int32_t tableVersion);

std::shared_ptr<Expression> ASTLifter::ConstantLiteral(int32_t index) const {
    const auto &k = ConstantAt(index);
    switch (k.kType) {
    case LUA_TNIL:
        return Fission::MakeShared<NilLiteralNode>();
    case LUA_TBOOLEAN:
        return Fission::MakeShared<BooleanLiteralNode>(std::get<bool>(k.constantData));
    case LUA_TNUMBER:
        return Fission::MakeShared<NumberLiteralNode>(std::get<double>(k.constantData));
    case LUA_TINTEGER:
        return Fission::MakeShared<IntegerLiteralNode>(std::get<int64_t>(k.constantData));
    case LUA_TSTRING:
        return Fission::MakeShared<StringLiteralNode>(std::get<std::string>(k.constantData));
    case LUA_TVECTOR:
        return LiftVectorConstant(k);
    default:
        return Fission::MakeShared<NilLiteralNode>();
    }
}

std::shared_ptr<Expression> ASTLifter::LiftExpression(const LiftedOperand &__operand, bool forceExpression) {
    // walk MOVE chains iteratively; deep copy fans would recurse one frame per hop
    LiftedOperand operand = __operand;
    while (true) {
        if (operand.type != LiftedOperandType::Register)
            break;
        if (const auto overridden = m_valueTermOverrides.find(SSARef{static_cast<uint8_t>(operand.value.reg), operand.ssaVersion});
            overridden != m_valueTermOverrides.end())
            return overridden->second;
        if (m_pinnedRegisters.contains({operand.value.reg, operand.ssaVersion}))
            return Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(ResolveVariableName(operand, false)));
        SSARef closureRef{static_cast<uint8_t>(operand.value.reg), operand.ssaVersion};
        if (m_inlineableClosures.contains(closureRef))
            break;
        const auto *moveDef = m_currentFunction->GetDefinition(operand);
        if (!moveDef || moveDef->operation != LiftedOperation::MOVE)
            break;
        if (m_emission.Emitted(moveDef->instructionIndex))
            break;
        if (!forceExpression && !ShouldInline(moveDef) && !m_deferToConditionInline.contains(moveDef))
            break;
        operand = moveDef->operands[1];
        // forcing materializes the copy, not the copied variable: its own def inlines only on its own terms
        forceExpression = false;
    }

    if (operand.type == LiftedOperandType::Register && m_pinnedRegisters.contains({operand.value.reg, operand.ssaVersion})) {
        return Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(ResolveVariableName(operand, false)));
    }

    // a closure parked for its single argument use renders once; erasing it keeps a second use from duplicating the literal
    if (operand.type == LiftedOperandType::Register) {
        SSARef ref{static_cast<uint8_t>(operand.value.reg), operand.ssaVersion};
        auto it = m_inlineableClosures.find(ref);
        if (it != m_inlineableClosures.end()) {
            auto closureNode = it->second;
            m_inlineableClosures.erase(it);
            return closureNode;
        }
    }

    if (operand.type == LiftedOperandType::ImmediateNil)
        return Fission::MakeShared<NilLiteralNode>();
    if (operand.type == LiftedOperandType::ImmediateBool)
        return Fission::MakeShared<BooleanLiteralNode>(operand.value.imm.b);
    if (operand.type == LiftedOperandType::ImmediateInteger)
        return Fission::MakeShared<NumberLiteralNode>(operand.value.imm.n);
    if (operand.type == LiftedOperandType::ImmediateConstant)
        return ConstantLiteral(operand.value.imm.k);

    const auto *def = m_currentFunction->GetDefinition(operand);

    if (def && m_emission.Emitted(def->instructionIndex)) {
        // a processed def was either declared (reference its name) or consumed by an inline; a tail-duplicated
        // region lifts it again, and only pure reads may be materialized twice
        const bool consumedByInline =
            m_emission.InlineConsumed(def->instructionIndex) && (def->operation == LiftedOperation::LOAD || def->operation == LiftedOperation::GETIMPORT ||
                                                                 def->operation == LiftedOperation::GETGLOBAL || def->operation == LiftedOperation::GETUPVAL);
        if (!consumedByInline)
            return Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(ResolveVariableName(operand, false)));
    }

    if (def && def->operation == LiftedOperation::GETVARARGS) {
        auto vararg = Fission::MakeShared<VarArgExpression>();
        vararg->bAdjustToOne = def->operands.size() > 1 && def->operands[1].value.imm.n == 2;
        return vararg;
    }

    if (!def || (!forceExpression && !ShouldInline(def) && !m_deferToConditionInline.contains(def))) {
        return Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(ResolveVariableName(operand, false)));
    }

    // a def feeding itself would recurse forever
    if (!m_liftingDefs.insert(def).second)
        throw Fission::DecompilerError("malformed bytecode: expression depends on itself (cycle). Cowardly refusing to decompile!");
    struct DefGuard {
        boost::unordered_flat_set<const LiftedInstruction *> &set;
        const LiftedInstruction *def;
        ~DefGuard() { set.erase(def); }
    } defGuard{m_liftingDefs, def};

    if (def->operation == LiftedOperation::LOADNJUMP && def->operands.size() >= 2 && def->operands[1].type == LiftedOperandType::ImmediateBool)
        return Fission::MakeShared<BooleanLiteralNode>(def->operands[1].value.imm.b);
    if (def->operation == LiftedOperation::LOAD) {
        if (def->operands[1].type == LiftedOperandType::ImmediateNil)
            return Fission::MakeShared<NilLiteralNode>();
        if (def->operands[1].type == LiftedOperandType::ImmediateBool)
            return Fission::MakeShared<BooleanLiteralNode>(def->operands[1].value.imm.b);
        if (def->operands[1].type == LiftedOperandType::ImmediateInteger)
            return Fission::MakeShared<NumberLiteralNode>(def->operands[1].value.imm.n);
        if (def->operands[1].type == LiftedOperandType::ImmediateConstant)
            return ConstantLiteral(def->operands[1].value.imm.k);
    }

    const auto unary = [](LiftedOperation operation) {
        return operation == LiftedOperation::NOT || operation == LiftedOperation::MINUS || operation == LiftedOperation::LENGTH;
    };
    const auto tableRead = [](LiftedOperation operation) {
        return operation == LiftedOperation::GETTABLE || operation == LiftedOperation::GETTABLEKS || operation == LiftedOperation::GETTABLEN;
    };
    const auto callCallee = [&](const LiftedInstruction *instruction) -> const LiftedOperand * {
        if (instruction->operation != LiftedOperation::CALL && instruction->operation != LiftedOperation::CALLFB &&
            instruction->operation != LiftedOperation::NAMECALL)
            return nullptr;
        const LiftedInstruction *site = instruction;
        if (instruction->operation != LiftedOperation::NAMECALL && instruction->instructionIndex >= 2) {
            const auto &previous = m_currentFunction->lpLiftedFunction->instructions[instruction->instructionIndex - 2];
            if (previous.operation == LiftedOperation::NAMECALL && !previous.operands.empty() && !instruction->operands.empty() &&
                previous.operands[0].value.reg == instruction->operands[0].value.reg)
                site = &previous;
        }
        const size_t source = site->operation == LiftedOperation::NAMECALL ? 1 : 0;
        return site->operands.size() > source && site->operands[source].type == LiftedOperandType::Register ? &site->operands[source] : nullptr;
    };
    if (BinaryOperatorSymbol(def->operation) || unary(def->operation) || tableRead(def->operation) || callCallee(def)) {
        struct Frame {
            const LiftedInstruction *instruction;
            uint8_t phase = 0;
            std::shared_ptr<Expression> left;
        };
        std::vector<Frame> frames{{def, 0, {}}};
        std::vector<std::shared_ptr<Expression>> values;
        const auto descend = [&](const LiftedOperand &operand, const LiftedInstruction *parent) {
            const LiftedInstruction *inner = nullptr;
            if (operand.type == LiftedOperandType::Register && !m_pinnedRegisters.contains({operand.value.reg, operand.ssaVersion}) &&
                !m_inlineableClosures.contains({static_cast<uint8_t>(operand.value.reg), operand.ssaVersion})) {
                inner = m_currentFunction->GetDefinition(operand);
                if (inner && (inner->instructionIndex >= parent->instructionIndex || m_emission.Emitted(inner->instructionIndex) || !ShouldInline(inner) ||
                              (!BinaryOperatorSymbol(inner->operation) && !unary(inner->operation) && !tableRead(inner->operation) && !callCallee(inner))))
                    inner = nullptr;
            }
            if (inner)
                frames.push_back({inner, 0, {}});
            else
                values.push_back(LiftExpression(operand));
        };
        while (!frames.empty()) {
            auto &frame = frames.back();
            const auto *current = frame.instruction;
            const char *binary = BinaryOperatorSymbol(current->operation);
            if (frame.phase == 0) {
                frame.phase = 1;
                if (const auto *callee = callCallee(current))
                    descend(*callee, current);
                else
                    descend(current->operands[1], current);
                continue;
            }
            if ((binary || current->operation == LiftedOperation::GETTABLE) && frame.phase == 1) {
                frame.left = std::move(values.back());
                values.pop_back();
                frame.phase = 2;
                if (binary && HasConstantRightOperand(current->operation))
                    values.push_back(ConstantLiteral(current->operands[2].value.imm.k));
                else
                    descend(current->operands[2], current);
                continue;
            }
            auto value = std::move(values.back());
            values.pop_back();
            if (binary)
                value = Fission::MakeShared<BinaryExpressionNode>(binary, frame.left, value);
            else if (current->operation == LiftedOperation::GETTABLE)
                value = Fission::MakeShared<IndexExpressionNode>(frame.left, value);
            else if (current->operation == LiftedOperation::GETTABLEKS) {
                const auto &key = ConstantAt(current->operands[2].value.imm.k);
                value = Fission::MakeShared<MemberExpressionNode>(value, std::get<std::string>(key.constantData));
            } else if (current->operation == LiftedOperation::GETTABLEN)
                value = Fission::MakeShared<IndexExpressionNode>(
                    value, Fission::MakeShared<NumberLiteralNode>(static_cast<double>(current->operands[2].value.imm.n) + 1.0)
                );
            else if (callCallee(current))
                value = LiftCall(*current, current->instructionIndex, true, std::move(value));
            else {
                const char *symbol = current->operation == LiftedOperation::NOT ? "not " : current->operation == LiftedOperation::MINUS ? "-" : "#";
                value = Fission::MakeShared<UnaryExpressionNode>(symbol, value);
            }
            frames.pop_back();
            values.push_back(std::move(value));
        }
        return values.back();
    }

    switch (def->operation) {

    case LiftedOperation::CONDVALUE: {
        if (def->operands.size() < 3)
            return Fission::MakeShared<BooleanLiteralNode>(false);
        const LiftedInstruction branch{
            static_cast<LiftedOperation>(def->operands[def->operands.size() - 2].value.imm.n), def->instructionIndex,
            std::vector<LiftedOperand>(def->operands.begin() + 1, def->operands.end() - 2)
        };
        auto condition = LiftCondition(&branch);
        return def->operands.back().value.imm.b ? condition : InvertCondition(condition);
    }

    case LiftedOperation::SUBRK:
    case LiftedOperation::DIVRK: {
        // `k - r` / `k / r`: the constant index sits in operand 1
        auto left = ConstantLiteral(def->operands[1].value.imm.k);
        auto right = LiftExpression(def->operands[2]);
        return Fission::MakeShared<BinaryExpressionNode>(def->operation == LiftedOperation::SUBRK ? "-" : "/", left, right);
    }
    case LiftedOperation::MOVE:
        return LiftExpression(def->operands[1], forceExpression);
    case LiftedOperation::GETVARARGS:
        return Fission::MakeShared<VarArgExpression>();

    case LiftedOperation::CONCAT: {
        int startReg = def->operands[1].value.reg;
        int endReg = def->operands[2].value.reg;
        std::vector<LiftedOperand> operands;

        bool implicitCoversAll = false;
        if (m_currentFunction->implicitUses.contains(def)) {
            const auto &vers = m_currentFunction->implicitUses.at(def);
            if (vers.size() == (size_t)(endReg - startReg + 1)) {
                implicitCoversAll = true;
                for (size_t i = 0; i < vers.size(); ++i) {
                    LiftedOperand op;
                    op.type = LiftedOperandType::Register;
                    op.value.reg = startReg + i;
                    op.ssaVersion = vers[i];
                    operands.push_back(op);
                }
            }
        }

        if (!implicitCoversAll) {
            operands.push_back(def->operands[1]);

            if (m_currentFunction->implicitUses.contains(def)) {
                const auto &vers = m_currentFunction->implicitUses.at(def);
                for (size_t i = 0; i < vers.size(); ++i) {
                    LiftedOperand op;
                    op.type = LiftedOperandType::Register;
                    op.value.reg = startReg + 1 + i;
                    op.ssaVersion = vers[i];
                    operands.push_back(op);
                }
            } else {
                for (int r = startReg + 1; r < endReg; ++r) {
                    LiftedOperand op;
                    op.type = LiftedOperandType::Register;
                    op.value.reg = r;
                    op.ssaVersion = -1;
                    operands.push_back(op);
                }
            }

            if (endReg > startReg) {
                operands.push_back(def->operands[2]);
            }
        }

        // one CONCAT over a range groups like the source it came from: `a .. (b .. c)`, `..` being right-associative
        std::vector<std::shared_ptr<Expression>> parts;
        parts.reserve(operands.size());
        for (const auto &op : operands)
            parts.push_back(LiftExpression(op));
        std::shared_ptr<Expression> expr = nullptr;
        for (auto part = parts.rbegin(); part != parts.rend(); ++part)
            expr = expr ? Fission::MakeShared<BinaryExpressionNode>("..", *part, expr) : *part;
        return expr ? expr : Fission::MakeShared<StringLiteralNode>("");
    }

    case LiftedOperation::DUPTABLE:
    case LiftedOperation::NEWTABLE:
        return LiftTableLiteral(*def);

    case LiftedOperation::CALL:
    case LiftedOperation::CALLFB:
    case LiftedOperation::NAMECALL:
        return LiftCall(*def, def->instructionIndex, true);

    case LiftedOperation::GETGLOBAL: {
        const auto &k = ConstantAt(def->operands[1].value.imm.k);
        return Fission::MakeShared<IdentifierExpressionNode>(GlobalIdentifier(std::get<std::string>(k.constantData)));
    }
    case LiftedOperation::GETUPVAL: {
        return Fission::MakeShared<IdentifierExpressionNode>(
            Fission::MakeShared<Identifier>(this->m_currentFunction->GetUpvalueName(def->operands[1].value.imm.n))
        );
    }
    case LiftedOperation::GETIMPORT: {
        uint32_t importData = def->operands[2].value.imm.u;
        int count = importData >> 30;
        int id0 = int(importData >> 20) & 1023;
        int id1 = int(importData >> 10) & 1023;
        int id2 = int(importData) & 1023;

        std::vector<std::string> parts;
        auto &constants = m_currentFunction->lpLiftedFunction->lpDeserialized->constants;
        if (count >= 1)
            parts.push_back(std::get<std::string>(constants.at(id0).constantData));
        if (count >= 2)
            parts.push_back(std::get<std::string>(constants.at(id1).constantData));
        if (count >= 3)
            parts.push_back(std::get<std::string>(constants.at(id2).constantData));

        if (parts.empty())
            return Fission::MakeShared<NilLiteralNode>();

        std::shared_ptr<Expression> curr = Fission::MakeShared<IdentifierExpressionNode>(GlobalIdentifier(parts[0]));
        for (size_t i = 1; i < parts.size(); ++i)
            curr = Fission::MakeShared<MemberExpressionNode>(curr, parts[i]);
        return curr;
    }
    default:
        return Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(ResolveVariableName(operand, false)));
    }
}

bool ASTLifter::IsMultretCall(const LiftedInstruction &callDef, int32_t callDefIndex) const {
    if (callDef.operation == LiftedOperation::NAMECALL)
        return true; // a method call is never a fast builtin -> always multret-capable
    if (callDef.operation != LiftedOperation::CALL && callDef.operation != LiftedOperation::CALLFB)
        return true;

    // a fast builtin's FASTCALL sits a few instructions before its CALL; an earlier call in between means a general call
    const auto &instrs = m_currentFunction->lpLiftedFunction->instructions;
    constexpr int32_t kScanWindow = 32;
    const int32_t lo = std::max(0, callDefIndex - kScanWindow);
    for (int32_t j = callDefIndex - 1; j >= lo; --j) {
        switch (instrs[j].operation) {
        case LiftedOperation::FASTPCALL:
            continue; // A selects pcall/xpcall, not a Luau builtin metadata id.
        case LiftedOperation::FASTCALL:
        case LiftedOperation::FASTCALL1:
        case LiftedOperation::FASTCALL2:
        case LiftedOperation::FASTCALL2K:
        case LiftedOperation::FASTCALL3:
            if (instrs[j].operands.empty())
                return true;
            // a builtin spreads unless it declares exactly one result (math.modf returns 2, select is variadic)
            return Luau::Compile::getBuiltinInfo(instrs[j].operands[0].value.imm.n).results != 1;
        case LiftedOperation::CALL:
        case LiftedOperation::CALLFB:
        case LiftedOperation::NAMECALL:
            return true;
        default:
            break;
        }
    }
    return true;
}

std::shared_ptr<Expression>
ASTLifter::LiftCall(const LiftedInstruction &inst, int32_t instructionIndex, bool isNested, std::shared_ptr<Expression> calleeOverride) {
    const auto resolveSite = [&](const LiftedInstruction *call, int32_t index) {
        while ((call->operation == LiftedOperation::CALL || call->operation == LiftedOperation::CALLFB) && index >= 2) {
            if (call->operands.empty())
                break;
            const auto &prev = m_currentFunction->lpLiftedFunction->instructions[index - 2];
            if (prev.operation != LiftedOperation::NAMECALL || prev.operands.empty() || prev.operands[0].value.reg != call->operands[0].value.reg)
                break;
            call = &prev;
            index -= 2;
        }
        return std::pair{call, index};
    };
    if (!calleeOverride) {
        std::vector<const LiftedInstruction *> chain;
        const LiftedInstruction *call = &inst;
        while (true) {
            const auto [site, _] = resolveSite(call, call->instructionIndex);
            const bool named = site->operation == LiftedOperation::NAMECALL;
            const size_t sourceIndex = named ? 1 : 0;
            if (site->operands.size() <= sourceIndex || site->operands[sourceIndex].type != LiftedOperandType::Register)
                break;
            const auto *source = m_currentFunction->GetDefinition(site->operands[sourceIndex]);
            if (!source || source->instructionIndex >= call->instructionIndex || m_emission.Emitted(source->instructionIndex) || !ShouldInline(source) ||
                (source->operation != LiftedOperation::CALL && source->operation != LiftedOperation::CALLFB && source->operation != LiftedOperation::NAMECALL))
                break;
            chain.push_back(call);
            call = source;
        }
        if (!chain.empty()) {
            auto value = LiftCall(*call, call->instructionIndex, true);
            for (auto it = chain.rbegin(); it != chain.rend(); ++it)
                value = LiftCall(**it, (*it)->instructionIndex, it + 1 == chain.rend() ? isNested : true, std::move(value));
            return value;
        }
    }
    const auto [curInst, curIdx] = resolveSite(&inst, instructionIndex);
    const LiftedInstruction &resolvedInst = *curInst;
    const int32_t resolvedIdx = curIdx;

    bool isNameCall = (resolvedInst.operation == LiftedOperation::NAMECALL);
    int32_t callInfoIndex = isNameCall ? resolvedIdx + 2 : resolvedIdx;

    if (static_cast<size_t>(callInfoIndex) >= m_currentFunction->lpLiftedFunction->instructions.size())
        return Fission::MakeShared<NilLiteralNode>();

    const auto &callInfoInst = m_currentFunction->lpLiftedFunction->instructions[callInfoIndex];
    if (callInfoInst.operands.empty() || resolvedInst.operands.size() < (isNameCall ? 2u : 1u))
        return Fission::MakeShared<NilLiteralNode>();
    int regFunc = callInfoInst.operands[0].value.reg;

    std::vector<std::shared_ptr<Expression>> args;
    std::shared_ptr<Expression> callee;
    bool isVararg = false;
    // a call in the final argument slot truncated to one value; rendered bare it would spread on recompile
    const LiftedInstruction *adjustArgCallDef = nullptr;

    if (calleeOverride)
        callee = std::move(calleeOverride);
    else if (isNameCall)
        callee = LiftExpression(resolvedInst.operands[1], false);
    else
        callee = LiftExpression(resolvedInst.operands[0], false);

    if (m_currentFunction->implicitUses.contains(&callInfoInst)) {
        const auto &argVersions = m_currentFunction->implicitUses.at(&callInfoInst);
        int startOffset = isNameCall ? 1 : 0;
        for (size_t k = startOffset; k < argVersions.size(); ++k) {
            LiftedOperand op;
            op.type = LiftedOperandType::Register;
            op.value.reg = regFunc + 1 + k;
            op.ssaVersion = argVersions[k];

            auto def = m_currentFunction->GetDefinition(op);
            if (def && !m_emission.Emitted(def->instructionIndex) &&
                (def->operation == LiftedOperation::CALL || def->operation == LiftedOperation::CALLFB || def->operation == LiftedOperation::NAMECALL)) {
                int32_t actualCallIdx = (def->operation == LiftedOperation::NAMECALL) ? def->instructionIndex + 2 : def->instructionIndex;
                const auto &defInstrs = m_currentFunction->lpLiftedFunction->instructions;
                if (actualCallIdx >= 0 && static_cast<size_t>(actualCallIdx) < defInstrs.size() && defInstrs[actualCallIdx].operands.size() > 2 &&
                    defInstrs[actualCallIdx].operands[2].value.imm.n == 0) {
                    m_emission.MarkEmitted(def->instructionIndex);
                    if (def->operation == LiftedOperation::NAMECALL) {
                        m_emission.MarkEmitted(def->instructionIndex + 1);
                        m_emission.MarkEmitted(def->instructionIndex + 2);
                    }
                    args.push_back(LiftCall(*def, def->instructionIndex, true));
                    adjustArgCallDef = nullptr; // spread tail
                    break;
                }
            }
            if (def && def->operation == LiftedOperation::GETVARARGS && !m_emission.Emitted(def->instructionIndex)) {
                isVararg = true;
                auto vararg = Fission::MakeShared<VarArgExpression>();
                vararg->bAdjustToOne = def->operands.size() > 1 && def->operands[1].value.imm.n == 2 && k + 1 == argVersions.size();
                args.push_back(vararg);
                adjustArgCallDef = nullptr;
                continue;
            }
            args.push_back(LiftExpression(op, false));
            if (def && (def->operation == LiftedOperation::CALL || def->operation == LiftedOperation::CALLFB || def->operation == LiftedOperation::NAMECALL)) {
                adjustArgCallDef = def;
            } else {
                adjustArgCallDef = nullptr;
            }
        }
    }

    int32_t prevIdx = resolvedIdx - 1;
    if (prevIdx >= 0) {
        const auto &prevInst = m_currentFunction->lpLiftedFunction->instructions[prevIdx];
        if ((prevInst.operation == LiftedOperation::CALL || prevInst.operation == LiftedOperation::CALLFB) && prevInst.operands.size() > 2 &&
            prevInst.operands[2].value.imm.n == 0) {
            if (!m_emission.Emitted(prevIdx)) {
                m_emission.MarkEmitted(prevIdx);
                args.push_back(LiftCall(prevInst, prevIdx, true));
                adjustArgCallDef = nullptr; // spread tail appended after the arg loop
            }
        }
    }

    // `f(a, (g()))`: single-return fast builtins never spread, so IsMultretCall spares them the parens
    if (adjustArgCallDef && !args.empty()) {
        if (auto c = std::dynamic_pointer_cast<CallExpressionNode>(args.back()))
            c->bAdjustToOne = true;
        else if (auto n = std::dynamic_pointer_cast<NameCallExpressionNode>(args.back()))
            n->bAdjustToOne = true;
    }

    std::vector<std::shared_ptr<Expression>> rets;
    if (isNameCall) {
        auto kIdx = resolvedInst.operands[2].value.imm.k;
        std::string method = std::get<std::string>(m_currentFunction->lpLiftedFunction->lpDeserialized->constants.at(kIdx).constantData);

        return Fission::MakeShared<NameCallExpressionNode>(
            callee, Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(method)), args, rets, isVararg, isNested
        );
    } else {
        return Fission::MakeShared<CallExpressionNode>(callee, args, rets, isVararg, isNested);
    }
}

static bool IsLegalLuauIdentifier(const std::string &str) {
    if (str.empty() || std::isdigit(static_cast<unsigned char>(str.front())))
        return false;
    if (!std::ranges::all_of(str, [](char c) {
            auto uc = static_cast<unsigned char>(c);
            return std::isalnum(uc) || uc == '_';
        }))
        return false;
    // a reserved keyword must be bracketed as a key (`["end"] = 1`)
    static const std::unordered_set<std::string> kReserved = {"and",   "break", "do",  "else", "elseif", "end",    "false", "for",  "function", "if",   "in",
                                                              "local", "nil",   "not", "or",   "repeat", "return", "then",  "true", "until",    "while"};
    return !kReserved.contains(str);
}

static std::shared_ptr<Expression> MakeTableKey(const std::string &keyStr) {
    if (IsLegalLuauIdentifier(keyStr))
        return Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(keyStr));
    return Fission::MakeShared<StringLiteralNode>(keyStr);
}

std::shared_ptr<Expression> ASTLifter::LiftSetListElement(const LiftedInstruction &setList, size_t k, bool forceComputed) {
    if (!m_currentFunction->implicitUses.contains(&setList))
        return Fission::MakeShared<NilLiteralNode>();
    const auto &versions = m_currentFunction->implicitUses.at(&setList);
    if (k >= versions.size())
        return Fission::MakeShared<NilLiteralNode>();

    const int startReg = setList.operands[1].value.reg;
    LiftedOperand itemOp{};
    itemOp.type = LiftedOperandType::Register;
    itemOp.value.reg = startReg + static_cast<int>(k);
    itemOp.ssaVersion = versions[k];

    std::shared_ptr<Expression> expr = nullptr;
    if (auto lpDef = m_currentFunction->GetDefinition(itemOp)) {
        if (lpDef->operation == LiftedOperation::LOAD) {
            expr = LiftExpression(itemOp, true);
            m_emission.MarkInlineConsumed(lpDef->instructionIndex);
        } else if (lpDef->operation == LiftedOperation::MOVE && !forceComputed && !ShouldInline(lpDef)) {
            expr = LiftExpression(itemOp, false);
        } else if (lpDef->operation == LiftedOperation::MOVE) {
            expr = LiftExpression(lpDef->operands[1], false);
            m_emission.MarkInlineConsumed(lpDef->instructionIndex);
        } else {
            // SETLIST counts its first element twice (operand + implicit use); an otherwise unused computed element
            // is force-inlined so it cannot leak as a local declared after the constructor
            const SSARef itemRef{static_cast<uint8_t>(itemOp.value.reg), itemOp.ssaVersion};
            const int selfUses = (itemOp.value.reg == startReg) ? 2 : 1;
            auto ucIt = m_currentFunction->useCounts.find(itemRef);
            const bool singleUse = ucIt == m_currentFunction->useCounts.end() || ucIt->second <= selfUses;
            // a nested constructor's use count is inflated by its own population; ShouldInline dedups it
            const bool inlineTable = (lpDef->operation == LiftedOperation::NEWTABLE || lpDef->operation == LiftedOperation::DUPTABLE) && ShouldInline(lpDef);
            const bool canForce = forceComputed && (lpDef->operation != LiftedOperation::PHI || !m_definedRegisters.contains(itemOp.value.reg));
            if (singleUse && forceComputed && !canForce && !ShouldInline(lpDef))
                ExplainKeep(lpDef, "constructor must reuse the materialized local", &setList);
            if ((singleUse && (canForce || ShouldInline(lpDef))) || inlineTable) {
                expr = LiftExpression(itemOp, true);
                m_emission.MarkInlineConsumed(lpDef->instructionIndex);
                ConsumeInlinedInputs(*lpDef);
            } else {
                expr = LiftExpression(itemOp, false);
            }
        }
    }

    // an unwritten register reads nil
    return expr ? expr : std::static_pointer_cast<Expression>(Fission::MakeShared<NilLiteralNode>());
}

bool ASTLifter::RenderClosureInPlace(const LiftedInstruction &closure, const std::shared_ptr<FunctionDeclarationNode> &function, bool anonymous) {
    const SSARef ref{static_cast<uint8_t>(closure.operands[0].value.reg), closure.operands[0].ssaVersion};
    if (const auto slots = m_closureSlots.find(ref); slots != m_closureSlots.end()) {
        function->bAnonymousInline = true;
        function->bIsLocalDeclaration = false;
        for (const auto &slot : slots->second)
            *slot = *function;
        m_closureSlots.erase(slots);
        return true;
    }
    // a constructor that inlines at its reader renders after this handler and takes the parked closure
    if (const auto *store = SoleUser(ref); store && StoreTargetsFreshTable(store)) {
        const bool list = store->operation == LiftedOperation::SETLIST;
        const auto *table = m_currentFunction->GetDefinition(store->operands[list ? 0 : 1]);
        if ((list || (store->operands[0].value.reg == ref.regIndex && store->operands[0].ssaVersion == ref.version)) && table && ShouldInline(table)) {
            function->bAnonymousInline = true;
            function->bIsLocalDeclaration = false;
            m_inlineableClosures[ref] = function;
            return true;
        }
    }
    if (!anonymous)
        return false;
    // `(function(...) ... end)(args)`: a nameless closure called where it is made
    if (const auto *call = SoleUser(ref); call && (call->operation == LiftedOperation::CALL || call->operation == LiftedOperation::CALLFB) &&
                                          call->operands[0].value.reg == ref.regIndex && call->operands[0].ssaVersion == ref.version &&
                                          BlockOf(call) == BlockOf(&closure)) {
        function->bAnonymousInline = true;
        function->bIsLocalDeclaration = false;
        m_inlineableClosures[ref] = function;
        return true;
    }
    // `t[k] = function() ... end`: a nameless closure stored right after its captures
    const auto readsRef = [&](const LiftedOperand &operand) {
        return operand.type == LiftedOperandType::Register && operand.value.reg == ref.regIndex && operand.ssaVersion == ref.version;
    };
    if (const auto *store = SoleUser(ref);
        store &&
        (store->operation == LiftedOperation::SETTABLE || store->operation == LiftedOperation::SETTABLEKS || store->operation == LiftedOperation::SETTABLEN) &&
        readsRef(store->operands[0]) && std::ranges::none_of(store->operands | std::views::drop(1), readsRef) && !BeginsDebugLocal(closure, ref.regIndex)) {
        const auto &instructions = m_currentFunction->lpLiftedFunction->instructions;
        bool adjacent = BlockOf(store) == BlockOf(&closure);
        for (auto k = static_cast<size_t>(closure.instructionIndex) + 1; adjacent && k < static_cast<size_t>(store->instructionIndex); ++k)
            adjacent = instructions[k].operation == LiftedOperation::CAPTURE || instructions[k].operation == LiftedOperation::NOP;
        if (adjacent) {
            function->bAnonymousInline = true;
            function->bIsLocalDeclaration = false;
            m_inlineableClosures[ref] = function;
            return true;
        }
    }
    // `return function() ... end`: a nameless closure whose one use is its own block's return
    const auto users = m_currentFunction->users.find(ref);
    if (users == m_currentFunction->users.end() || users->second.size() != 1 || users->second.front()->operation != LiftedOperation::RETURN ||
        BlockOf(users->second.front()) != BlockOf(&closure))
        return false;
    function->bAnonymousInline = true;
    function->bIsLocalDeclaration = false;
    m_inlineableClosures[ref] = function;
    return true;
}

std::shared_ptr<Expression> ASTLifter::LiftStoreTarget(const LiftedInstruction &store) {
    switch (store.operation) {
    case LiftedOperation::SETGLOBAL:
        return Fission::MakeShared<IdentifierExpressionNode>(GlobalIdentifier(std::get<std::string>(ConstantAt(store.operands[1].value.imm.k).constantData)));
    case LiftedOperation::SETUPVAL:
        return Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(m_currentFunction->GetUpvalueName(store.operands[1].value.imm.n)));
    case LiftedOperation::SETTABLEKS: {
        auto table = LiftExpression(store.operands[1]);
        const std::string &key = std::get<std::string>(ConstantAt(store.operands[2].value.imm.k).constantData);
        // A keyed store into a table the compiler predicted as hash-free (`local t = {}` with no
        // dot-assignments) stays in bracket form when the table can hold an interior hole: dot
        // form would predict a hash entry and, on recompilation, observe a different length
        // boundary. Hole-free tables keep dot form (and method sugar); their boundary is
        // history-insensitive. Bracket form is always hint-faithful here: with no prediction
        // (opt 0, or an untracked table) the hint stays hash-free either way.
        const auto &tableOperand = store.operands[1];
        const auto *tableDef = m_currentFunction->GetDefinition(tableOperand);
        bool bracketKey = false;
        if (tableDef && tableDef->operation == LiftedOperation::NEWTABLE && tableDef->operands.size() > 1 &&
            tableDef->operands[1].type == LiftedOperandType::ImmediateInteger && tableDef->operands[1].value.imm.n == 0) {
            const auto window = AnalyzeTableLengthWindow(m_currentFunction, *tableDef, tableOperand.value.reg, tableOperand.ssaVersion);
            bracketKey = window.possibleHole;
        }
        if (bracketKey)
            return Fission::MakeShared<IndexExpressionNode>(table, Fission::MakeShared<StringLiteralNode>(key));
        return Fission::MakeShared<MemberExpressionNode>(table, key);
    }
    case LiftedOperation::SETTABLEN: {
        // the immediate is index - 1
        auto table = LiftExpression(store.operands[1]);
        return Fission::MakeShared<IndexExpressionNode>(
            table, Fission::MakeShared<NumberLiteralNode>(static_cast<double>(store.operands[2].value.imm.n) + 1.0)
        );
    }
    default: {
        auto table = LiftExpression(store.operands[1]);
        return Fission::MakeShared<IndexExpressionNode>(table, LiftExpression(store.operands[2]));
    }
    }
}

std::shared_ptr<TableLiteralNode> ASTLifter::LiftTableLiteral(const LiftedInstruction &inst) {
    if (inst.operation == LiftedOperation::NEWTABLE) {
        std::vector<std::pair<const LiftedInstruction *, const LiftedInstruction *>> chain;
        const LiftedInstruction *current = &inst;
        const LiftedInstruction *emptyBottom = nullptr;
        bool complete = false;
        while (current->operation == LiftedOperation::NEWTABLE) {
            const auto &output = current->operands[0];
            const auto users = m_currentFunction->users.find({static_cast<uint8_t>(output.value.reg), output.ssaVersion});
            const LiftedInstruction *store = nullptr;
            bool conflict = false;
            if (users != m_currentFunction->users.end())
                for (const auto *user : users->second) {
                    const size_t target = user->operation == LiftedOperation::SETLIST ? 0 : 1;
                    if ((user->operation != LiftedOperation::SETLIST && user->operation != LiftedOperation::SETTABLE &&
                         user->operation != LiftedOperation::SETTABLEKS && user->operation != LiftedOperation::SETTABLEN) ||
                        user->operands.size() <= target || user->operands[target].type != LiftedOperandType::Register ||
                        user->operands[target].value.reg != output.value.reg || user->operands[target].ssaVersion != output.ssaVersion)
                        continue;
                    if (store && store != user) {
                        conflict = true;
                        break;
                    }
                    store = user;
                }
            if (conflict)
                break;
            if (!store) {
                // Nothing populates this table: an empty `{}` bottom closes an otherwise
                // single-element chain iteratively instead of recursing once per level
                // (native stack overflow past ~200 nested constructors in debug builds).
                if (!chain.empty()) {
                    emptyBottom = current;
                    complete = true;
                }
                break;
            }
            if (store->operation != LiftedOperation::SETLIST || store->operands.size() < 4 || store->operands[2].value.imm.n != 2 ||
                store->operands[3].value.imm.n != 1)
                break;
            const auto values = SetListElements(*store);
            if (values.size() != 1)
                break;
            chain.emplace_back(current, store);
            const auto *child = m_currentFunction->GetDefinition(values.front());
            if (!child || child->operation != LiftedOperation::NEWTABLE) {
                complete = true;
                break;
            }
            if (child->instructionIndex <= current->instructionIndex || child->instructionIndex >= store->instructionIndex || !ShouldInline(child))
                break;
            current = child;
        }
        if (complete && (chain.size() > 1 || emptyBottom)) {
            std::shared_ptr<Expression> value = emptyBottom ? Fission::MakeShared<TableLiteralNode>() : LiftSetListElement(*chain.back().second, 0, true);
            for (auto it = chain.rbegin(); it != chain.rend(); ++it) {
                value = Fission::MakeShared<TableLiteralNode>(std::vector<std::shared_ptr<Expression>>{value});
                m_emission.MarkEmitted(it->second->instructionIndex);
                if (it->first != &inst) {
                    m_emission.MarkInlineConsumed(it->first->instructionIndex);
                    ConsumeInlinedInputs(*it->first);
                }
            }
            if (emptyBottom) {
                m_emission.MarkInlineConsumed(emptyBottom->instructionIndex);
                ConsumeInlinedInputs(*emptyBottom);
            }
            return std::static_pointer_cast<TableLiteralNode>(value);
        }
    }
    const auto plan = PlanTableLiteral(inst, false);
    return plan ? RenderTableLiteral(inst, *plan) : Fission::MakeShared<TableLiteralNode>();
}

static std::unordered_set<std::string> TemplateKeys(const LiftedInstruction &inst, const std::vector<LuauConstant> &constants) {
    std::unordered_set<std::string> keys;
    if (inst.operation == LiftedOperation::DUPTABLE && inst.operands[1].value.imm.k >= 0 &&
        static_cast<size_t>(inst.operands[1].value.imm.k) < constants.size())
        if (const auto &constant = constants[inst.operands[1].value.imm.k]; constant.kType == LUA_TTABLE) {
            const auto &shape = constant.GetValue<LuauTable>();
            keys.insert(shape.keys.begin(), shape.keys.end());
        }
    return keys;
}

// True when `operand` is statically nil: an explicit nil immediate, a nil constant, or a
// LOAD/MOVE chain resolving to one. SSA versions pin values, so following the chain is sound.
static bool TableOperandIsNil(const AnalyzedFunction *function, const LiftedOperand &operand, int depth = 0) {
    if (depth > 16)
        return false;
    switch (operand.type) {
    case LiftedOperandType::ImmediateNil:
        return true;
    case LiftedOperandType::ImmediateConstant: {
        const auto &constants = function->lpLiftedFunction->lpDeserialized->constants;
        const auto index = operand.value.imm.k;
        // Class shapes reuse LUA_TNIL but are not nil values.
        return index >= 0 && static_cast<size_t>(index) < constants.size() && constants[index].kType == LUA_TNIL && !constants[index].IsClassShape();
    }
    case LiftedOperandType::Register: {
        const auto *def = function->GetDefinition(operand);
        if (!def || def->operands.size() < 2)
            return false;
        if (def->operation == LiftedOperation::LOAD || def->operation == LiftedOperation::MOVE)
            return TableOperandIsNil(function, def->operands[1], depth + 1);
        return false;
    }
    default:
        return false;
    }
}

// True when `operand` provably cannot hold nil at runtime: closures, fresh tables, non-nil
// immediates and constants, and LOAD/MOVE chains resolving to those. Anything else (calls,
// index and global reads, parameters, varargs, phi merges, short-circuit values) can be nil.
// An over-narrow answer only misses a rescue (status quo); an over-broad one only keeps a
// constructor (still faithful on dense tables), so this list stays tight on purpose.
static bool TableOperandIsProvenNonNil(const AnalyzedFunction *function, const LiftedOperand &operand, int depth = 0) {
    if (depth > 16)
        return false;
    switch (operand.type) {
    case LiftedOperandType::ImmediateNil:
        return false;
    case LiftedOperandType::ImmediateInteger:
    case LiftedOperandType::ImmediateBool:
    case LiftedOperandType::ImmediateAux:
        return true;
    case LiftedOperandType::ImmediateConstant: {
        const auto &constants = function->lpLiftedFunction->lpDeserialized->constants;
        const auto index = operand.value.imm.k;
        return index >= 0 && static_cast<size_t>(index) < constants.size() && constants[index].kType != LUA_TNIL;
    }
    case LiftedOperandType::Register: {
        const auto *def = function->GetDefinition(operand);
        if (!def || def->operands.empty())
            return false;
        switch (def->operation) {
        case LiftedOperation::NEWCLOSURE:
        case LiftedOperation::DUPCLOSURE:
        case LiftedOperation::NEWTABLE:
        case LiftedOperation::DUPTABLE:
            return true;
        case LiftedOperation::LOAD:
        case LiftedOperation::MOVE:
            if (def->operands.size() < 2)
                return false;
            return TableOperandIsProvenNonNil(function, def->operands[1], depth + 1);
        default:
            return false;
        }
    }
    default:
        return false;
    }
}

// 1-based array index written by an incremental store with a statically known numeric key.
static std::optional<int32_t> TableArrayStoreIndex(const AnalyzedFunction *function, const LiftedInstruction &store) {
    if (store.operation == LiftedOperation::SETTABLEN && store.operands.size() > 2)
        return store.operands[2].value.imm.n + 1;
    if (store.operation == LiftedOperation::SETTABLE && store.operands.size() > 2) {
        // O0 keeps numeric keys generic (`t[1] = x` via a constant load); only integral keys >= 1 address the array part.
        LiftedOperand key = store.operands[2];
        for (int depth = 0; depth < 16; ++depth) {
            if (key.type == LiftedOperandType::ImmediateInteger)
                return key.value.imm.n >= 1 ? std::optional<int32_t>(key.value.imm.n) : std::nullopt;
            if (key.type == LiftedOperandType::ImmediateConstant) {
                const auto &constants = function->lpLiftedFunction->lpDeserialized->constants;
                const auto index = key.value.imm.k;
                if (index < 0 || static_cast<size_t>(index) >= constants.size())
                    return std::nullopt;
                const auto &constant = constants[index];
                if (constant.kType != LUA_TNUMBER)
                    return std::nullopt;
                const double value = std::get<LuauNumber>(constant.constantData);
                // A NaN key addresses the hash part. Casting NaN to an integer is undefined behavior, and NaN
                // fails both range checks, so screen for finite keys first.
                if (!Fission::IsFiniteDouble(value) || value < 1.0 || value > 2147483647.0)
                    return std::nullopt;
                const auto asIndex = static_cast<int32_t>(value);
                if (static_cast<double>(asIndex) != value)
                    return std::nullopt;
                return asIndex;
            }
            if (key.type != LiftedOperandType::Register)
                return std::nullopt;
            const auto *def = function->GetDefinition(key);
            if (!def || def->operands.size() < 2 || (def->operation != LiftedOperation::LOAD && def->operation != LiftedOperation::MOVE))
                return std::nullopt;
            key = def->operands[1];
        }
    }
    return std::nullopt;
}

// Distinct dot-form key count within the NEWTABLE encoded-hash-size range (0 for v=0,
// ceil(log2(v))+1 otherwise): v=0 -> {0}, v=1 -> {1}, v>=2 -> (2^(e-2), 2^(e-1)].
static bool DotKeyCountMatchesHint(size_t dots, int32_t hintHashRaw) {
    if (hintHashRaw == 0)
        return dots == 0;
    if (hintHashRaw < 1 || hintHashRaw > 30)
        return true;
    const size_t low = hintHashRaw == 1 ? size_t{1} : (size_t{1} << (hintHashRaw - 2)) + 1;
    const size_t high = hintHashRaw == 1 ? size_t{1} : (size_t{1} << (hintHashRaw - 1));
    return dots >= low && dots <= high;
}

// Whether a holey window keeps its constructor: a bulk hole (explicit or nil-able), or a
// non-sequential bulk shape (explicit keys compiled as hash entries) that refolding alone
// cannot reproduce. Keeping the constructor is always faithful (dense tables agree across
// histories), so this may fire on merely possible holes.
static bool LengthRescueActive(const TableLengthWindow &window) {
    return window.possibleHole && (window.bulkHole || (window.isNewtable && window.hintHashRaw != 0 && window.hintArray != window.sequentialArrayPred));
}
static TableLengthWindow AnalyzeTableLengthWindow(const AnalyzedFunction *function, const LiftedInstruction &inst, int32_t tableReg, int32_t tableVersion) {
    TableLengthWindow window{};
    if (inst.operation == LiftedOperation::NEWTABLE && inst.operands.size() > 2 && inst.operands[1].type == LiftedOperandType::ImmediateInteger &&
        inst.operands[2].type == LiftedOperandType::ImmediateInteger) {
        window.isNewtable = true;
        window.hintHashRaw = inst.operands[1].value.imm.n;
        window.hintArray = inst.operands[2].value.imm.n;
    }
    const auto users = function->users.find({static_cast<uint8_t>(tableReg), tableVersion});
    if (users == function->users.end())
        return window;
    struct ArrayWrite {
        int32_t instructionIndex;
        int32_t arrayIndex;
        bool isNil;
        bool couldBeNil;
        bool countsForPrediction;
    };
    std::vector<ArrayWrite> writes;
    std::unordered_set<int32_t> dotKeys;
    for (const auto *user : users->second) {
        if (!user)
            continue;
        const size_t tableOperand = user->operation == LiftedOperation::SETLIST ? 0 : 1;
        if ((user->operation != LiftedOperation::SETLIST && user->operation != LiftedOperation::SETTABLE && user->operation != LiftedOperation::SETTABLEKS &&
             user->operation != LiftedOperation::SETTABLEN) ||
            user->operands.size() <= tableOperand || user->operands[tableOperand].type != LiftedOperandType::Register ||
            user->operands[tableOperand].value.reg != tableReg || user->operands[tableOperand].ssaVersion != tableVersion)
            continue;
        window.storeIndices.insert(user->instructionIndex);
        if (user->operation == LiftedOperation::SETTABLEKS && user->operands.size() > 2 && user->operands[2].type == LiftedOperandType::ImmediateConstant)
            dotKeys.insert(user->operands[2].value.imm.k);
        if (user->operation == LiftedOperation::SETLIST) {
            if (user->operands.size() < 4 || user->operands[3].type != LiftedOperandType::ImmediateInteger ||
                user->operands[1].type != LiftedOperandType::Register)
                continue;
            const auto versions = function->implicitUses.find(user);
            if (versions == function->implicitUses.end())
                continue;
            const int32_t startReg = user->operands[1].value.reg;
            // SETLIST indices come from the AUX start index, not the sequential rule
            int32_t elementIndex = user->operands[3].value.imm.n;
            if (user->instructionIndex > inst.instructionIndex) {
                bool seenNil = false;
                size_t position = 0;
                for (const int32_t version : versions->second) {
                    LiftedOperand element{};
                    element.type = LiftedOperandType::Register;
                    element.value.reg = startReg + static_cast<int32_t>(position++);
                    element.ssaVersion = version;
                    const bool isNil = TableOperandIsNil(function, element);
                    if (isNil)
                        seenNil = true;
                    // only a later non-nil-valued entry forms a second border with the hole
                    else if (seenNil)
                        window.bulkHole = true;
                }
            }
            size_t position = 0;
            for (const int32_t version : versions->second) {
                LiftedOperand element{};
                element.type = LiftedOperandType::Register;
                element.value.reg = startReg + static_cast<int32_t>(position++);
                element.ssaVersion = version;
                if (elementIndex >= 1) {
                    const bool isNil = TableOperandIsNil(function, element);
                    writes.push_back({user->instructionIndex, elementIndex, isNil, isNil || !TableOperandIsProvenNonNil(function, element), false});
                }
                ++elementIndex;
            }
            continue;
        }
        // Only direct numeric stores predict array size (TableShape sees constants, and only
        // IndexNumber lowers to SETTABLEN); resolved-through-register keys still leave holes.
        const bool directNumeric =
            user->operation == LiftedOperation::SETTABLEN && user->operands.size() > 2 && user->operands[2].type == LiftedOperandType::ImmediateInteger;
        const auto index = TableArrayStoreIndex(function, *user);
        if (!index || *index < 1 || user->operands.empty())
            continue;
        const bool isNil = TableOperandIsNil(function, user->operands[0]);
        writes.push_back({user->instructionIndex, *index, isNil, isNil || !TableOperandIsProvenNonNil(function, user->operands[0]), directNumeric});
    }
    std::ranges::sort(writes, {}, &ArrayWrite::instructionIndex);
    window.distinctDotKeys = dotKeys.size();
    std::unordered_map<int32_t, std::pair<bool, bool>> holeByIndex; // index -> {isNil, couldBeNil}
    for (const auto &write : writes) {
        if (write.countsForPrediction && write.arrayIndex == window.sequentialArrayPred + 1)
            window.sequentialArrayPred = write.arrayIndex;
        holeByIndex[write.arrayIndex] = {write.isNil, write.couldBeNil};
    }
    for (const auto &[index, hole] : holeByIndex) {
        if (!hole.second)
            continue;
        for (const auto &[other, later] : holeByIndex) {
            if (other > index && !later.first) {
                window.possibleHole = true;
                break;
            }
        }
    }
    return window;
}

std::optional<ASTLifter::TableLiteralPlan> ASTLifter::PlanTableLiteral(const LiftedInstruction &inst, bool assumeInlined) {
    const auto &constants = m_currentFunction->lpLiftedFunction->lpDeserialized->constants;
    if (inst.operation == LiftedOperation::DUPTABLE &&
        (inst.operands[1].value.imm.k < 0 || static_cast<size_t>(inst.operands[1].value.imm.k) >= constants.size()))
        return std::nullopt;
    TableLiteralPlan plan;
    const int32_t tableReg = inst.operands[0].value.reg;
    // a store to the same register at another version targets a different table
    const int32_t tableVersion = inst.operands[0].ssaVersion;
    const int tableBlock = BlockOf(&inst);
    size_t scanEnd = static_cast<size_t>(inst.instructionIndex) + 1;
    if (const auto users = m_currentFunction->users.find({static_cast<uint8_t>(tableReg), tableVersion}); users != m_currentFunction->users.end())
        for (const auto *user : users->second) {
            const size_t target = user->operation == LiftedOperation::SETLIST ? 0 : 1;
            if ((user->operation != LiftedOperation::SETLIST && user->operation != LiftedOperation::SETTABLE &&
                 user->operation != LiftedOperation::SETTABLEKS && user->operation != LiftedOperation::SETTABLEN) ||
                user->operands.size() <= target || user->operands[target].type != LiftedOperandType::Register || user->operands[target].value.reg != tableReg ||
                user->operands[target].ssaVersion != tableVersion)
                continue;
            scanEnd = (std::max)(scanEnd, static_cast<size_t>(user->instructionIndex) + 1);
        }
    bool &bFoundSetList = plan.foundSetList;

    // The scan below asks for the decision on every candidate in the window, and for the definitions
    // their values read. Resolve them as one batch: the current table frame is suspended once, not once
    // per store, so a constructor with many population stores is planned in one pass.
    {
        const auto &instructions = m_currentFunction->lpLiftedFunction->instructions;
        std::vector<const LiftedInstruction *> inlineDependencies;
        inlineDependencies.reserve(scanEnd - static_cast<size_t>(inst.instructionIndex));
        const auto addDefinition = [&](const LiftedOperand &operand) {
            if (operand.type != LiftedOperandType::Register)
                return;
            const auto *definition = m_currentFunction->GetDefinition(operand);
            if (definition && definition != &inst)
                inlineDependencies.push_back(definition);
        };
        for (size_t i = static_cast<size_t>(inst.instructionIndex) + 1; i < scanEnd && i < instructions.size(); ++i) {
            const auto &candidate = instructions[i];
            inlineDependencies.push_back(&candidate);
            for (const auto &operand : candidate.operands)
                addDefinition(operand);
            if (candidate.operation == LiftedOperation::SETLIST)
                for (const auto &element : SetListElements(candidate))
                    addDefinition(element);
        }
        ResolveInlineBatch(inlineDependencies);
    }

    std::unordered_set<SSARef, std::hash<SSARef>> closureVisited;
    std::function<bool(const LiftedOperand &)> dependsOnClosure = [&](const LiftedOperand &op) -> bool {
        if (op.type != LiftedOperandType::Register)
            return false;
        const SSARef key{static_cast<uint8_t>(op.value.reg), op.ssaVersion};
        if (!closureVisited.insert(key).second)
            return false;
        const auto *def = m_currentFunction->GetDefinition(op);
        if (!def)
            return false;
        if (def->operation == LiftedOperation::NEWCLOSURE || def->operation == LiftedOperation::DUPCLOSURE)
            return true;
        const size_t firstOperand = (def->operation == LiftedOperation::CALL || def->operation == LiftedOperation::CALLFB) ? 0 : 1;
        for (size_t i = firstOperand; i < def->operands.size(); ++i)
            if (dependsOnClosure(def->operands[i]))
                return true;
        return false;
    };

    std::unordered_set<SSARef, std::hash<SSARef>> diamondVisited;
    std::function<bool(const LiftedOperand &)> dependsOnMaterializedDiamond = [&](const LiftedOperand &op) -> bool {
        if (op.type != LiftedOperandType::Register || !diamondVisited.insert({static_cast<uint8_t>(op.value.reg), op.ssaVersion}).second)
            return false;
        const auto *def = m_currentFunction->GetDefinition(op);
        if (!def)
            return false;
        if (IsDiamondBoolLoad(op))
            return true;
        for (size_t oi = 1; oi < def->operands.size(); ++oi)
            if (dependsOnMaterializedDiamond(def->operands[oi]))
                return true;
        return false;
    };

    // a value reading the table under construction (`t[3] = t[1] + t[2]`) cannot move into its literal;
    // walks every def, since a separate local reading the table still cannot precede it
    std::unordered_map<SSARef, bool, std::hash<SSARef>> readsTableMemo;
    std::function<bool(const LiftedOperand &)> readsTableReg = [&](const LiftedOperand &op) -> bool {
        if (op.type != LiftedOperandType::Register)
            return false;
        if (op.value.reg == tableReg && op.ssaVersion == tableVersion)
            return true;
        const SSARef key{static_cast<uint8_t>(op.value.reg), op.ssaVersion};
        if (auto it = readsTableMemo.find(key); it != readsTableMemo.end())
            return it->second;
        readsTableMemo.emplace(key, false); // seed false first so a self-referential cycle terminates
        const auto *def = m_currentFunction->GetDefinition(op);
        bool result = false;
        if (def && (def->operation == LiftedOperation::NEWTABLE || def->operation == LiftedOperation::DUPTABLE)) {
            if (const auto users = m_currentFunction->users.find(key); users != m_currentFunction->users.end()) {
                for (const auto *user : users->second) {
                    if (!user)
                        continue;
                    if (user->operation == LiftedOperation::SETLIST && user->operands.size() > 1 && user->operands[0].value.reg == key.regIndex &&
                        user->operands[0].ssaVersion == key.version) {
                        result = std::ranges::any_of(SetListElements(*user), [&](const LiftedOperand &element) { return readsTableReg(element); });
                    } else if (
                        (user->operation == LiftedOperation::SETTABLE || user->operation == LiftedOperation::SETTABLEKS ||
                         user->operation == LiftedOperation::SETTABLEN) &&
                        user->operands.size() > 1 && user->operands[1].value.reg == key.regIndex && user->operands[1].ssaVersion == key.version
                    ) {
                        result = readsTableReg(user->operands[0]) || (user->operands.size() > 2 && readsTableReg(user->operands[2]));
                    }
                    if (result)
                        break;
                }
            }
        }
        if (def)
            for (size_t oi = 1; oi < def->operands.size(); ++oi)
                if (readsTableReg(def->operands[oi])) {
                    result = true;
                    break;
                }
        // a call reads its callee and arguments as implicit uses
        if (!result && def && (def->operation == LiftedOperation::CALL || def->operation == LiftedOperation::CALLFB) &&
            m_currentFunction->implicitUses.contains(def))
            result = readsTableReg(def->operands[0]) ||
                     std::ranges::any_of(CallArguments(*def), [&](const LiftedOperand &argument) { return readsTableReg(argument); });
        readsTableMemo[key] = result;
        return result;
    };

    // a local table renders at its NEWTABLE, before values declared after it; an inlined table renders at its
    // last use, where every contributor exists
    const int32_t tableIndex = inst.instructionIndex;
    plan.tableIsLocal = !assumeInlined && !ShouldInline(&inst);
    const bool tableIsLocal = plan.tableIsLocal;

    auto isLaterName = [&](const LiftedInstruction *def) -> bool { return BlockOf(def) == tableBlock && def->instructionIndex > tableIndex; };

    const auto templateKeys = TemplateKeys(inst, constants);
    // unoptimized code stores a template field through a key loaded into a register
    const auto templateKey = [&](const LiftedOperand &key) {
        const auto *def = key.type == LiftedOperandType::Register ? m_currentFunction->GetDefinition(key) : nullptr;
        if (!def || def->operation != LiftedOperation::LOAD || def->operands.size() < 2 || def->operands[1].type != LiftedOperandType::ImmediateConstant)
            return false;
        const auto *name = std::get_if<std::string>(&ConstantAt(def->operands[1].value.imm.k).constantData);
        return name && templateKeys.contains(*name);
    };

    // a closure built for this local table renders in its constructor; the closure's handler, which runs
    // after this declaration, fills the slot. It may not capture the table or a local declared after it.
    // Only a field the source constructor held qualifies: an all-record constructor is a DUPTABLE whose template
    // names the key; a mixed one has list items, flushed before its keyed items, and reserves exactly its keyed
    // fields in NEWTABLE's hash size; `local t = {}` has neither, its sizes predicted from later stores.
    // A later bulk SETLIST holding an interior nil hole forces the constructor to stay regardless of order:
    // splitting it into stores would observe a different length boundary, so a keyed closure scanned
    // before that SETLIST still parks in the constructor. A non-sequential bulk shape (explicit keys
    // compiled as hash entries) likewise pins the constructor: refolding is the only faithful form.
    const TableLengthWindow lengthWindow = AnalyzeTableLengthWindow(m_currentFunction, inst, tableReg, tableVersion);
    const bool lengthRescue = LengthRescueActive(lengthWindow);
    size_t keyedFields = 0;
    const int32_t hashSizeLog = inst.operation == LiftedOperation::NEWTABLE ? inst.operands[1].value.imm.n : 0;
    const size_t hashCapacity = hashSizeLog > 0 && hashSizeLog < 32 ? size_t{1} << (hashSizeLog - 1) : 0;
    // an inlined table renders at its reader, after the closure's handler, which parked the closure for it
    auto closureField = [&](const LiftedOperand &value) -> bool {
        if (value.type != LiftedOperandType::Register ||
            (!tableIsLocal && !assumeInlined && !m_inlineableClosures.contains({static_cast<uint8_t>(value.value.reg), value.ssaVersion})))
            return false;
        const auto *def = m_currentFunction->GetDefinition(value);
        const auto *store = SoleUser({static_cast<uint8_t>(value.value.reg), value.ssaVersion});
        if (!def || (def->operation != LiftedOperation::NEWCLOSURE && def->operation != LiftedOperation::DUPCLOSURE) || !isLaterName(def) || !store)
            return false;
        if (def->operation == LiftedOperation::DUPCLOSURE && def->operands.size() > 1) {
            const auto shared = m_sharedClosures.find(def->operands[1].value.imm.k);
            if (shared != m_sharedClosures.end() && shared->second.count > 1)
                return false;
        }
        const bool templateStore =
            inst.operation == LiftedOperation::DUPTABLE && store->operation == LiftedOperation::SETTABLE && templateKey(store->operands[2]);
        if (store->operation == LiftedOperation::SETTABLEKS) {
            if (inst.operation == LiftedOperation::DUPTABLE
                    ? !templateKeys.contains(std::get<std::string>(ConstantAt(store->operands[2].value.imm.k).constantData))
                    : (!bFoundSetList && !lengthRescue) || keyedFields >= hashCapacity)
                return false;
        } else if (!templateStore && store->operation != LiftedOperation::SETLIST && ((!bFoundSetList && !lengthRescue) || keyedFields >= hashCapacity)) {
            return false;
        }
        const auto &instructions = m_currentFunction->lpLiftedFunction->instructions;
        for (auto k = static_cast<size_t>(def->instructionIndex) + 1; k < instructions.size() && instructions[k].operation == LiftedOperation::CAPTURE; ++k) {
            const auto &capture = instructions[k];
            if (capture.operands.size() < 2 || capture.operands[0].value.imm.n > 1)
                continue;
            const auto &captured = capture.operands[1];
            if (captured.value.reg == tableReg && captured.ssaVersion == tableVersion)
                return false;
            if (const auto *capturedDef = m_currentFunction->GetDefinition(captured); capturedDef && isLaterName(capturedDef))
                return false;
        }
        return true;
    };
    // a local declared before this local table is named in its constructor as-is
    auto earlierLocal = [&](const LiftedOperand &value) {
        if (!tableIsLocal || value.type != LiftedOperandType::Register || IsDiamondBoolLoad(value))
            return false;
        const auto *def = m_currentFunction->GetDefinition(value);
        if (!def || ShouldInline(def) || isLaterName(def))
            return false;
        // a closure read more than once is declared by name; a single-use one renders in place
        return (def->operation != LiftedOperation::NEWCLOSURE && def->operation != LiftedOperation::DUPCLOSURE) || !m_currentFunction->IsSingleUse(value) ||
               !m_inlineableClosures.contains({static_cast<uint8_t>(value.value.reg), value.ssaVersion});
    };
    // a field folds only when its whole value inlines at the field site; a register it reads that stays a
    // statement would be named inside the constructor before its declaration
    std::unordered_map<SSARef, bool, std::hash<SSARef>> foldableMemo;
    std::function<bool(const LiftedOperand &)> valueFoldable = [&](const LiftedOperand &valOp) -> bool {
        if (valOp.type != LiftedOperandType::Register)
            return true;
        const auto *def = m_currentFunction->GetDefinition(valOp);
        if (!def)
            return true;
        const SSARef key{static_cast<uint8_t>(valOp.value.reg), valOp.ssaVersion};
        if (auto it = foldableMemo.find(key); it != foldableMemo.end())
            return it->second;
        foldableMemo.emplace(key, false); // seed false so a self-referential cycle terminates conservatively
        if (IsDiamondBoolLoad(valOp))
            return false;
        bool ok = ShouldInline(def);
        if (ok)
            for (size_t oi = 1; oi < def->operands.size(); ++oi)
                if (def->operands[oi].type == LiftedOperandType::Register && !valueFoldable(def->operands[oi]) && !earlierLocal(def->operands[oi])) {
                    ok = false;
                    break;
                }
        foldableMemo[key] = ok;
        return ok;
    };
    // does `op`, rendered by LiftExpression, name a statement-level value declared after this table?
    std::unordered_map<SSARef, bool, std::hash<SSARef>> laterMemo;
    std::function<bool(const LiftedOperand &)> readsLaterName = [&](const LiftedOperand &op) -> bool {
        if (op.type != LiftedOperandType::Register)
            return false;
        const auto *def = m_currentFunction->GetDefinition(op);
        if (!def)
            return false;
        const SSARef key{static_cast<uint8_t>(op.value.reg), op.ssaVersion};
        if (auto it = laterMemo.find(key); it != laterMemo.end())
            return it->second;
        laterMemo.emplace(key, false);
        bool res;
        if (ShouldInline(def)) {
            res = false;
            for (size_t oi = 1; oi < def->operands.size(); ++oi)
                if (def->operands[oi].type == LiftedOperandType::Register && readsLaterName(def->operands[oi])) {
                    res = true;
                    break;
                }
            if (!res && (def->operation == LiftedOperation::CALL || def->operation == LiftedOperation::CALLFB))
                res = readsLaterName(def->operands[0]) ||
                      std::ranges::any_of(CallArguments(*def), [&](const LiftedOperand &argument) { return readsLaterName(argument); });
            if (!res && (def->operation == LiftedOperation::NEWTABLE || def->operation == LiftedOperation::DUPTABLE))
                if (const auto users = m_currentFunction->users.find(key); users != m_currentFunction->users.end())
                    for (const auto *store : users->second) {
                        const bool list = store->operation == LiftedOperation::SETLIST;
                        const bool field = store->operation == LiftedOperation::SETTABLE || store->operation == LiftedOperation::SETTABLEKS ||
                                           store->operation == LiftedOperation::SETTABLEN;
                        const size_t table = list ? 0 : 1;
                        if ((!list && !field) || store->operands.size() <= table || store->operands[table].type != LiftedOperandType::Register ||
                            store->operands[table].value.reg != key.regIndex || store->operands[table].ssaVersion != key.version)
                            continue;
                        res = list ? std::ranges::any_of(SetListElements(*store), readsLaterName)
                                   : readsLaterName(store->operands[0]) ||
                                         (store->operation == LiftedOperation::SETTABLE && store->operands.size() > 2 && readsLaterName(store->operands[2]));
                        if (res)
                            break;
                    }
        } else {
            res = isLaterName(def);
        }
        laterMemo[key] = res;
        return res;
    };

    // mirrors LiftSetListElement's force-inline choice for one element
    auto elementForwardRefs = [&](int startReg, const LiftedOperand &element) -> bool {
        const int reg = element.value.reg;
        const auto *def = m_currentFunction->GetDefinition(element);
        if (!def)
            return false;
        if ((def->operation == LiftedOperation::NEWCLOSURE || def->operation == LiftedOperation::DUPCLOSURE) && isLaterName(def))
            return !closureField(element);
        if (def->operation == LiftedOperation::LOAD)
            return false;
        if (def->operation == LiftedOperation::MOVE)
            return readsLaterName(def->operands[1]);
        const int selfUses = (reg == startReg) ? 2 : 1;
        auto ucIt = m_currentFunction->useCounts.find({static_cast<uint8_t>(reg), element.ssaVersion});
        const bool singleUse = ucIt == m_currentFunction->useCounts.end() || ucIt->second <= selfUses;
        const bool inlineTable = (def->operation == LiftedOperation::NEWTABLE || def->operation == LiftedOperation::DUPTABLE) && ShouldInline(def);
        const bool canForce = def->operation != LiftedOperation::PHI || !m_definedRegisters.contains(reg);
        if (inlineTable || (singleUse && (canForce || ShouldInline(def)))) {
            for (size_t oi = 1; oi < def->operands.size(); ++oi)
                if (def->operands[oi].type == LiftedOperandType::Register && readsLaterName(def->operands[oi]))
                    return true;
            const bool call = def->operation == LiftedOperation::CALL || def->operation == LiftedOperation::CALLFB;
            return call && !def->operands.empty() &&
                   (readsLaterName(def->operands[0]) ||
                    std::ranges::any_of(CallArguments(*def), [&](const LiftedOperand &argument) { return readsLaterName(argument); }));
        }
        return isLaterName(def);
    };

    // A store into another table is an effect (and can raise) unless that table is a nested
    // constructor built inside this fold window.
    auto storesIntoForeignTable = [&](const LiftedInstruction &candidate, size_t tableOperand) {
        if (candidate.operands.size() <= tableOperand || candidate.operands[tableOperand].value.reg == tableReg)
            return false;
        const auto *target = m_currentFunction->GetDefinition(candidate.operands[tableOperand]);
        return !target || (target->operation != LiftedOperation::NEWTABLE && target->operation != LiftedOperation::DUPTABLE) ||
               target->instructionIndex <= inst.instructionIndex;
    };

    // An effect between the table and a store may only be skipped when it is rendered inside this constructor:
    // its value reaches a store into this table, possibly through a nested constructor built after it.
    auto feedsThisTable = [&](const LiftedInstruction &value) -> const LiftedInstruction * {
        const auto &instructions = m_currentFunction->lpLiftedFunction->instructions;
        const LiftedInstruction *current = &value;
        if (current->operation == LiftedOperation::NAMECALL || current->operation == LiftedOperation::NAMECALLUDATA)
            for (auto next = static_cast<size_t>(current->instructionIndex) + 1; next < instructions.size(); ++next)
                if (instructions[next].operation != LiftedOperation::NOP) {
                    current = &instructions[next];
                    break;
                }
        const auto isStore = [](const LiftedInstruction &candidate) {
            return candidate.operation == LiftedOperation::SETLIST || candidate.operation == LiftedOperation::SETTABLE ||
                   candidate.operation == LiftedOperation::SETTABLEKS || candidate.operation == LiftedOperation::SETTABLEN;
        };
        for (int depth = 0; depth < 32; ++depth) {
            std::vector<SSARef> refs;
            if (const auto defs = m_defsByInstruction.find(current); defs != m_defsByInstruction.end())
                refs = defs->second;
            else if (!current->operands.empty() && current->operands[0].type == LiftedOperandType::Register)
                refs.push_back({static_cast<uint8_t>(current->operands[0].value.reg), current->operands[0].ssaVersion});
            // every value it defines must go to one consumer; a table's own population stores do not count
            const LiftedInstruction *user = nullptr;
            for (const auto &ref : refs) {
                const auto users = m_currentFunction->users.find(ref);
                if (users == m_currentFunction->users.end())
                    continue;
                for (const auto *candidate : users->second) {
                    const size_t tableIndex = candidate->operation == LiftedOperation::SETLIST ? 0 : 1;
                    if (isStore(*candidate) && candidate->operands.size() > tableIndex && candidate->operands[tableIndex].value.reg == ref.regIndex &&
                        candidate->operands[tableIndex].ssaVersion == ref.version)
                        continue;
                    if (user && user != candidate)
                        return nullptr;
                    user = candidate;
                }
            }
            if (!user || user->instructionIndex <= current->instructionIndex)
                return nullptr;
            const bool store = isStore(*user);
            if (!store) {
                current = user;
                continue;
            }
            if (user->operands.size() < 2)
                return nullptr;
            const auto &table = user->operands[user->operation == LiftedOperation::SETLIST ? 0 : 1];
            if (table.value.reg == tableReg && table.ssaVersion == tableVersion)
                return user;
            const auto *nested = m_currentFunction->GetDefinition(table);
            if (!nested || (nested->operation != LiftedOperation::NEWTABLE && nested->operation != LiftedOperation::DUPTABLE) ||
                nested->instructionIndex <= inst.instructionIndex)
                return nullptr;
            current = nested;
        }
        return nullptr;
    };

    // an effect skipped because a later store carries it into the constructor: (its index, that store's index)
    std::vector<std::pair<size_t, int32_t>> carried;
    const auto scan = [&] {
        for (size_t i = inst.instructionIndex + 1; i < scanEnd; ++i) {
            const auto &candidate = m_currentFunction->lpLiftedFunction->instructions[i];
            const bool store = candidate.operation == LiftedOperation::SETLIST || candidate.operation == LiftedOperation::SETTABLE ||
                               candidate.operation == LiftedOperation::SETTABLEKS || candidate.operation == LiftedOperation::SETTABLEN;
            const size_t tableOperand = candidate.operation == LiftedOperation::SETLIST ? 0 : 1;
            const bool ownStore = store && candidate.operands.size() > tableOperand && candidate.operands[tableOperand].type == LiftedOperandType::Register &&
                                  candidate.operands[tableOperand].value.reg == tableReg && candidate.operands[tableOperand].ssaVersion == tableVersion;
            if (!ownStore) {
                const auto readsOwnTable = [&](const LiftedOperand &op) {
                    return op.type == LiftedOperandType::Register && op.value.reg == tableReg && op.ssaVersion == tableVersion;
                };
                bool readsTable = false;
                for (size_t oi = 0; oi < candidate.operands.size(); ++oi) {
                    const auto access = SSABuilder::GetRegisterAccess(candidate, oi);
                    if ((access == AccessType::Read || access == AccessType::ReadWrite) && readsOwnTable(candidate.operands[oi])) {
                        readsTable = true;
                        break;
                    }
                }
                if (!readsTable && (candidate.operation == LiftedOperation::CALL || candidate.operation == LiftedOperation::CALLFB))
                    readsTable = std::ranges::any_of(CallArguments(candidate), readsOwnTable);
                if (readsTable)
                    break;
            }
            if ((candidate.operation == LiftedOperation::SETLIST && storesIntoForeignTable(candidate, 0)) ||
                ((candidate.operation == LiftedOperation::SETTABLE || candidate.operation == LiftedOperation::SETTABLEKS ||
                  candidate.operation == LiftedOperation::SETTABLEN) &&
                 storesIntoForeignTable(candidate, 1)))
                break;
            if (inst.operation == LiftedOperation::DUPTABLE) {
                if (tableBlock < 0 || i > static_cast<size_t>(m_currentFunction->basicBlocks[tableBlock].lpTail->instructionIndex))
                    break;
                const bool fieldStore = (candidate.operation == LiftedOperation::SETTABLEKS ||
                                         (candidate.operation == LiftedOperation::SETTABLE && templateKey(candidate.operands[2]))) &&
                                        candidate.operands[1].value.reg == tableReg && candidate.operands[1].ssaVersion == tableVersion;
                const bool closure = (candidate.operation == LiftedOperation::NEWCLOSURE || candidate.operation == LiftedOperation::DUPCLOSURE) &&
                                     closureField(candidate.operands[0]);
                const size_t storedOperand = candidate.operation == LiftedOperation::SETLIST ? 0 : 1;
                const bool nestedStore = (candidate.operation == LiftedOperation::SETLIST || candidate.operation == LiftedOperation::SETTABLE ||
                                          candidate.operation == LiftedOperation::SETTABLEKS || candidate.operation == LiftedOperation::SETTABLEN) &&
                                         candidate.operands.size() > storedOperand && candidate.operands[storedOperand].value.reg != tableReg;
                if (!fieldStore && !closure && !nestedStore && candidate.operation != LiftedOperation::NOP && candidate.operation != LiftedOperation::CAPTURE &&
                    !IsFastCall(candidate.operation)) {
                    if (!ShouldInline(&candidate))
                        break;
                    bool readsTable = false;
                    for (size_t operand = 1; operand < candidate.operands.size(); ++operand)
                        if (candidate.operands[operand].type == LiftedOperandType::Register && candidate.operands[operand].value.reg == tableReg &&
                            candidate.operands[operand].ssaVersion == tableVersion)
                            readsTable = true;
                    if (readsTable)
                        break;
                }
            }

            if (candidate.operation == LiftedOperation::JUMP || candidate.operation == LiftedOperation::JUMPIF ||
                candidate.operation == LiftedOperation::JUMPIFNOT || candidate.operation == LiftedOperation::JUMPIFEQ ||
                candidate.operation == LiftedOperation::JUMPIFNOTEQ || candidate.operation == LiftedOperation::JUMPIFLE ||
                candidate.operation == LiftedOperation::JUMPIFNOTLE || candidate.operation == LiftedOperation::JUMPIFLT ||
                candidate.operation == LiftedOperation::JUMPIFNOTLT || candidate.operation == LiftedOperation::JUMPXEQK ||
                candidate.operation == LiftedOperation::RETURN || candidate.operation == LiftedOperation::BREAK ||
                candidate.operation == LiftedOperation::FORNPREP || candidate.operation == LiftedOperation::FORNLOOP ||
                candidate.operation == LiftedOperation::FORGLOOP || candidate.operation == LiftedOperation::FORGPREP ||
                candidate.operation == LiftedOperation::FORGPREP_INEXT || candidate.operation == LiftedOperation::FORGPREP_NEXT)
                break;

            if (candidate.operation == LiftedOperation::SETLIST) {
                if (candidate.operands[0].value.reg == tableReg && candidate.operands[0].ssaVersion != tableVersion)
                    break;
                if (candidate.operands[0].value.reg == tableReg) {
                    std::vector<bool> slots;
                    if (const auto setListElements = SetListElements(candidate); !setListElements.empty()) {
                        const int startReg = candidate.operands[1].value.reg;
                        // a local table renders before later-declared values; elements naming them, or collapsed
                        // comparisons, stay `t[i] = elem` statements after the constructor
                        if (tableIsLocal && std::ranges::any_of(setListElements, [&](const LiftedOperand &element) {
                                diamondVisited.clear();
                                return elementForwardRefs(startReg, element) || dependsOnMaterializedDiamond(element);
                            }))
                            break;
                        for (const auto &element : setListElements)
                            slots.push_back(closureField(element));
                    }
                    bFoundSetList = true;
                    plan.stores.push_back({candidate.instructionIndex, std::move(slots)});
                    // a multi-value tail must stay last: a field rendered after it cuts it to one value
                    if (candidate.operands.size() > 2 && candidate.operands[2].value.imm.n == 0)
                        return;
                }
            } else if (candidate.operation == LiftedOperation::SETTABLEKS) {
                if (candidate.operands[1].value.reg == tableReg && candidate.operands[1].ssaVersion != tableVersion)
                    break;
                if (candidate.operands[1].value.reg == tableReg) {
                    // A store folded after the bulk part of a hash-free holey bulk table changes
                    // the shape prediction (and the layout); the bulk stays folded, the tail
                    // renders as statements with the original history. Keyed stores the source
                    // constructor held (hash-predicted) keep folding.
                    if (bFoundSetList && lengthWindow.isNewtable && lengthWindow.hintHashRaw == 0 && lengthWindow.bulkHole)
                        break;
                    const bool closure = closureField(candidate.operands[0]);
                    if (!closure && (readsTableReg(candidate.operands[0]) || !(valueFoldable(candidate.operands[0]) || earlierLocal(candidate.operands[0])) ||
                                     (tableIsLocal && readsLaterName(candidate.operands[0]))))
                        break;
                    plan.stores.push_back({candidate.instructionIndex, {closure}});
                    ++keyedFields;
                }
            } else if (candidate.operation == LiftedOperation::SETTABLEN) {
                if (candidate.operands[1].value.reg == tableReg && candidate.operands[1].ssaVersion != tableVersion)
                    break;
                if (candidate.operands[1].value.reg == tableReg) {
                    if (bFoundSetList && lengthWindow.isNewtable && lengthWindow.hintHashRaw == 0 && lengthWindow.bulkHole)
                        break;
                    const bool closure = closureField(candidate.operands[0]);
                    if (!closure && (readsTableReg(candidate.operands[0]) || !(valueFoldable(candidate.operands[0]) || earlierLocal(candidate.operands[0])) ||
                                     (tableIsLocal && readsLaterName(candidate.operands[0]))))
                        break;
                    plan.stores.push_back({candidate.instructionIndex, {closure}});
                    ++keyedFields;
                }
            } else if (candidate.operation == LiftedOperation::SETTABLE) {
                if (candidate.operands[1].value.reg == tableReg && candidate.operands[1].ssaVersion != tableVersion)
                    break;
                if (candidate.operands[1].value.reg == tableReg) {
                    if (bFoundSetList && lengthWindow.isNewtable && lengthWindow.hintHashRaw == 0 && lengthWindow.bulkHole)
                        break;
                    if (m_setListKeySnapshots.contains(&candidate))
                        break;
                    const bool closure = closureField(candidate.operands[0]);
                    const bool keyClosure = tableIsLocal && closureField(candidate.operands[2]);
                    if ((!closure && readsTableReg(candidate.operands[0])) || (!keyClosure && readsTableReg(candidate.operands[2])))
                        break;
                    if (tableIsLocal && ((!closure && readsLaterName(candidate.operands[0])) || (!keyClosure && readsLaterName(candidate.operands[2]))))
                        break;
                    diamondVisited.clear();
                    if (!closure && dependsOnMaterializedDiamond(candidate.operands[0]))
                        break;
                    diamondVisited.clear();
                    if (!keyClosure && dependsOnMaterializedDiamond(candidate.operands[2]))
                        break;
                    if (!closure && !valueFoldable(candidate.operands[0]) && !earlierLocal(candidate.operands[0]))
                        break;
                    // a closure key outside its slot is declared by its own statement after the constructor
                    closureVisited.clear();
                    if (!keyClosure && dependsOnClosure(candidate.operands[2]))
                        break;
                    plan.stores.push_back({candidate.instructionIndex, {closure, keyClosure}});
                    ++keyedFields;
                }
            } else if (CanOperationRaise(candidate.operation) || StaysAsStatement(&candidate)) {
                const auto *store = feedsThisTable(candidate);
                if (!store)
                    break;
                carried.emplace_back(i, store->instructionIndex);
            }
        }
    };
    // the carrying store must fold too, or the effect would land after the stores folded past it
    for (;;) {
        plan.stores.clear();
        bFoundSetList = false;
        keyedFields = 0;
        carried.clear();
        scan();
        const auto stranded = std::ranges::find_if(carried, [&](const auto &effect) {
            return std::ranges::none_of(plan.stores, [&](const auto &store) { return store.index == effect.second; });
        });
        if (stranded == carried.end()) {
            // Merging incremental stores into a bulk constructor changes the length boundary Luau
            // observes for a table with an interior hole (`#t` depends on construction history, not
            // just content). A plan without any bulk SETLIST folds pure stores, so decline it when
            // the window is stores-origin (the hint array matches the sequential prediction, or the
            // table carries no usable hint) and the fold would change history: any partial fold, or
            // a full fold whose dot keys the hint never predicted. Bulk-origin plans (a SETLIST, or
            // explicit keys compiled as hash entries) keep their history either way.
            if (!bFoundSetList && lengthWindow.possibleHole &&
                (!lengthWindow.isNewtable ||
                 (lengthWindow.hintArray == lengthWindow.sequentialArrayPred
                      ? (std::ranges::any_of(
                             lengthWindow.storeIndices,
                             [&](int32_t index) { return std::ranges::none_of(plan.stores, [&](const auto &store) { return store.index == index; }); }
                         ) ||
                         !DotKeyCountMatchesHint(lengthWindow.distinctDotKeys, lengthWindow.hintHashRaw))
                      : (lengthWindow.hintHashRaw == 0)))) {
                plan.stores.clear();
            }
            return plan;
        }
        scanEnd = stranded->first;
    }
}

std::shared_ptr<TableLiteralNode> ASTLifter::RenderTableLiteral(const LiftedInstruction &inst, const TableLiteralPlan &plan) {
    const auto &constants = m_currentFunction->lpLiftedFunction->lpDeserialized->constants;
    const auto &instructions = m_currentFunction->lpLiftedFunction->instructions;
    std::vector<std::shared_ptr<Expression>> elements;
    // a template holding constant values lists every record field in source order; the others arrive as stores
    std::unordered_map<std::string, std::shared_ptr<BinaryExpressionNode>> templateSlots;
    if (inst.operation == LiftedOperation::DUPTABLE)
        if (const auto &constant = constants[inst.operands[1].value.imm.k]; constant.kType == LUA_TTABLE) {
            const auto &tableData = constant.GetValue<LuauTable>();
            for (size_t i = 0; i < tableData.keys.size() && i < tableData.valueConstantIndices.size(); i++) {
                const auto valIdx = tableData.valueConstantIndices[i];
                const bool hasValue = valIdx >= 0 && static_cast<size_t>(valIdx) < constants.size();
                auto entry = Fission::MakeShared<BinaryExpressionNode>(
                    "=", MakeTableKey(tableData.keys[i]), hasValue ? ConstantLiteral(valIdx) : Fission::MakeShared<NilLiteralNode>()
                );
                if (!hasValue)
                    templateSlots.try_emplace(tableData.keys[i], entry);
                elements.push_back(std::move(entry));
            }
        }
    const size_t templateEntries = elements.size();

    // A rescued plan preserves a General-flavored bulk shape: without any bulk SETLIST of its
    // own, string keys render bracketed so the recompile keeps them out of the record count
    // (which would reallocate the array part and move the length boundary). Templates and
    // bulk-positional plans keep their existing forms.
    const auto renderWindow = AnalyzeTableLengthWindow(m_currentFunction, inst, inst.operands[0].value.reg, inst.operands[0].ssaVersion);
    const bool generalKeys =
        inst.operation == LiftedOperation::NEWTABLE && LengthRescueActive(renderWindow) &&
        std::ranges::none_of(plan.stores, [&](const auto &store) { return instructions[store.index].operation == LiftedOperation::SETLIST; });
    const auto tableKey = [&](const std::string &key) -> std::shared_ptr<Expression> {
        if (generalKeys)
            return Fission::MakeShared<StringLiteralNode>(key);
        return MakeTableKey(key);
    };

    const auto value = [&](const LiftedOperand &operand, bool closureSlot) -> std::shared_ptr<Expression> {
        if (!closureSlot || !plan.tableIsLocal)
            return LiftExpression(operand);
        auto slot = Fission::MakeShared<FunctionDeclarationNode>(
            "", 0, std::unordered_map<int32_t, std::shared_ptr<FunctionArgumentExpression>>{}, false, nullptr, false
        );
        m_closureSlots[SSARef{static_cast<uint8_t>(operand.value.reg), operand.ssaVersion}].push_back(slot);
        return slot;
    };
    for (const auto &store : plan.stores) {
        const auto &candidate = instructions[store.index];
        if (candidate.operation == LiftedOperation::SETLIST) {
            const auto setListElements = SetListElements(candidate);
            for (size_t k = 0; k < setListElements.size(); k++)
                elements.push_back(store.closureSlots[k] ? value(setListElements[k], true) : LiftSetListElement(candidate, k, true));
            // a fixed-count SETLIST truncated its last element to one value: `{a, (g())}`
            if (!setListElements.empty() && candidate.operands.size() > 2 && candidate.operands[2].value.imm.n != 0 && !elements.empty()) {
                const auto *ldef = m_currentFunction->GetDefinition(setListElements.back());
                if (ldef &&
                    (ldef->operation == LiftedOperation::CALL || ldef->operation == LiftedOperation::CALLFB || ldef->operation == LiftedOperation::NAMECALL) &&
                    IsMultretCall(*ldef, ldef->instructionIndex)) {
                    if (auto c = std::dynamic_pointer_cast<CallExpressionNode>(elements.back()))
                        c->bAdjustToOne = true;
                    else if (auto n = std::dynamic_pointer_cast<NameCallExpressionNode>(elements.back()))
                        n->bAdjustToOne = true;
                }
            }
        } else if (candidate.operation == LiftedOperation::SETTABLEKS) {
            const auto &k = ConstantAt(candidate.operands[2].value.imm.k);
            elements.push_back(
                Fission::MakeShared<BinaryExpressionNode>(
                    "=", tableKey(std::get<std::string>(k.constantData)), value(candidate.operands[0], store.closureSlots[0])
                )
            );
            ConsumeInlinedDefs(candidate.operands[0]);
        } else if (candidate.operation == LiftedOperation::SETTABLEN) {
            // the immediate is index - 1
            const int idx = candidate.operands[2].value.imm.n + 1;
            elements.push_back(
                Fission::MakeShared<BinaryExpressionNode>(
                    "=", Fission::MakeShared<MemberExpressionNode>(Fission::MakeShared<NumberLiteralNode>(idx)),
                    value(candidate.operands[0], store.closureSlots[0])
                )
            );
            ConsumeInlinedDefs(candidate.operands[0]);
        } else if (candidate.operation == LiftedOperation::SETTABLE) {
            auto keyExpr = value(candidate.operands[2], store.closureSlots[1]);
            auto valExpr = value(candidate.operands[0], store.closureSlots[0]);
            elements.push_back(Fission::MakeShared<TableBinaryExpressionNode>("=", keyExpr, valExpr));
            ConsumeInlinedDefs(candidate.operands[0]);
            ConsumeInlinedDefs(candidate.operands[2]);
        }
    }

    const bool bFoundSetList = plan.foundSetList;
    const auto templateKeys = TemplateKeys(inst, constants);
    if (bFoundSetList || !elements.empty())
        for (const auto &store : plan.stores)
            m_emission.MarkEmitted(store.index);
    // a template names only record fields; beside list items a record field and a bracketed string key compile alike
    for (auto &element : elements)
        if (const auto keyed = std::dynamic_pointer_cast<TableBinaryExpressionNode>(element))
            if (const auto str = AsLiteral<StringLiteralNode>(keyed->left); str && (bFoundSetList || templateKeys.contains(str->value)))
                element = Fission::MakeShared<BinaryExpressionNode>("=", tableKey(str->value), keyed->right);
    const auto literal = [](const std::shared_ptr<Expression> &value) {
        return AsLiteral<NilLiteralNode>(value) || AsLiteral<BooleanLiteralNode>(value) || AsLiteral<NumberLiteralNode>(value) ||
               AsLiteral<StringLiteralNode>(value);
    };
    // a value moved up into its slot would run before an earlier value that stays behind
    bool pinned = false;
    for (size_t i = templateEntries; i < elements.size();) {
        const auto keyed = std::dynamic_pointer_cast<BinaryExpressionNode>(elements[i]);
        std::string key;
        if (const auto id = keyed ? std::dynamic_pointer_cast<IdentifierExpressionNode>(keyed->left) : nullptr; id && id->identifier)
            key = id->identifier->name;
        else if (const auto str = keyed ? AsLiteral<StringLiteralNode>(keyed->left) : nullptr)
            key = str->value;
        const auto slot = key.empty() ? templateSlots.end() : templateSlots.find(key);
        if (slot == templateSlots.end() || (pinned && !literal(keyed->right))) {
            pinned = pinned || !literal(keyed ? keyed->right : elements[i]);
            ++i;
            continue;
        }
        slot->second->right = keyed->right;
        templateSlots.erase(slot);
        elements.erase(elements.begin() + static_cast<std::ptrdiff_t>(i));
    }

    return elements.empty() ? Fission::MakeShared<TableLiteralNode>() : Fission::MakeShared<TableLiteralNode>(elements);
}

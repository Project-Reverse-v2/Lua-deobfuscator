#include "BytecodeLifter.hpp"

#include "Deserializer.hpp"
#include "SafetyGuard.hpp"

#include <libassert/assert.hpp>
#include <sstream>
#include <unordered_set>

std::string GetLuauBuiltinName(LuauBuiltinFunction id) {
    switch (id) {
    case LBF_NONE:
        return "none";
    case LBF_ASSERT:
        return "assert";
    case LBF_MATH_ABS:
        return "math.abs";
    case LBF_MATH_ACOS:
        return "math.acos";
    case LBF_MATH_ASIN:
        return "math.asin";
    case LBF_MATH_ATAN2:
        return "math.atan2";
    case LBF_MATH_ATAN:
        return "math.atan";
    case LBF_MATH_CEIL:
        return "math.ceil";
    case LBF_MATH_COSH:
        return "math.cosh";
    case LBF_MATH_COS:
        return "math.cos";
    case LBF_MATH_DEG:
        return "math.deg";
    case LBF_MATH_EXP:
        return "math.exp";
    case LBF_MATH_FLOOR:
        return "math.floor";
    case LBF_MATH_FMOD:
        return "math.fmod";
    case LBF_MATH_FREXP:
        return "math.frexp";
    case LBF_MATH_LDEXP:
        return "math.ldexp";
    case LBF_MATH_LOG10:
        return "math.log10";
    case LBF_MATH_LOG:
        return "math.log";
    case LBF_MATH_MAX:
        return "math.max";
    case LBF_MATH_MIN:
        return "math.min";
    case LBF_MATH_MODF:
        return "math.modf";
    case LBF_MATH_POW:
        return "math.pow";
    case LBF_MATH_RAD:
        return "math.rad";
    case LBF_MATH_SINH:
        return "math.sinh";
    case LBF_MATH_SIN:
        return "math.sin";
    case LBF_MATH_SQRT:
        return "math.sqrt";
    case LBF_MATH_TANH:
        return "math.tanh";
    case LBF_MATH_TAN:
        return "math.tan";
    case LBF_BIT32_ARSHIFT:
        return "bit32.arshift";
    case LBF_BIT32_BAND:
        return "bit32.band";
    case LBF_BIT32_BNOT:
        return "bit32.bnot";
    case LBF_BIT32_BOR:
        return "bit32.bor";
    case LBF_BIT32_BXOR:
        return "bit32.bxor";
    case LBF_BIT32_BTEST:
        return "bit32.btest";
    case LBF_BIT32_EXTRACT:
        return "bit32.extract";
    case LBF_BIT32_LROTATE:
        return "bit32.lrotate";
    case LBF_BIT32_LSHIFT:
        return "bit32.lshift";
    case LBF_BIT32_REPLACE:
        return "bit32.replace";
    case LBF_BIT32_RROTATE:
        return "bit32.rrotate";
    case LBF_BIT32_RSHIFT:
        return "bit32.rshift";
    case LBF_TYPE:
        return "type";
    case LBF_STRING_BYTE:
        return "string.byte";
    case LBF_STRING_CHAR:
        return "string.char";
    case LBF_STRING_LEN:
        return "string.len";
    case LBF_TYPEOF:
        return "typeof";
    case LBF_STRING_SUB:
        return "string.sub";
    case LBF_MATH_CLAMP:
        return "math.clamp";
    case LBF_MATH_SIGN:
        return "math.sign";
    case LBF_MATH_ROUND:
        return "math.round";
    case LBF_RAWSET:
        return "rawset";
    case LBF_RAWGET:
        return "rawget";
    case LBF_RAWEQUAL:
        return "rawequal";
    case LBF_TABLE_INSERT:
        return "table.insert";
    case LBF_TABLE_UNPACK:
        return "table.unpack";
    case LBF_VECTOR:
        return "Vector3.new";
    case LBF_BIT32_COUNTLZ:
        return "bit32.countlz";
    case LBF_BIT32_COUNTRZ:
        return "bit32.countrz";
    case LBF_SELECT_VARARG:
        return "select";
    case LBF_RAWLEN:
        return "rawlen";
    case LBF_BIT32_EXTRACTK:
        return "bit32.extract"; // extractk maps to extract
    case LBF_GETMETATABLE:
        return "getmetatable";
    case LBF_SETMETATABLE:
        return "setmetatable";
    case LBF_TONUMBER:
        return "tonumber";
    case LBF_TOSTRING:
        return "tostring";
    case LBF_BIT32_BYTESWAP:
        return "bit32.byteswap";
    case LBF_BUFFER_READI8:
        return "buffer.readi8";
    case LBF_BUFFER_READU8:
        return "buffer.readu8";
    case LBF_BUFFER_WRITEU8:
        return "buffer.writeu8";
    case LBF_BUFFER_READI16:
        return "buffer.readi16";
    case LBF_BUFFER_READU16:
        return "buffer.readu16";
    case LBF_BUFFER_WRITEU16:
        return "buffer.writeu16";
    case LBF_BUFFER_READI32:
        return "buffer.readi32";
    case LBF_BUFFER_READU32:
        return "buffer.readu32";
    case LBF_BUFFER_WRITEU32:
        return "buffer.writeu32";
    case LBF_BUFFER_READF32:
        return "buffer.readf32";
    case LBF_BUFFER_WRITEF32:
        return "buffer.writef32";
    case LBF_BUFFER_READF64:
        return "buffer.readf64";
    case LBF_BUFFER_WRITEF64:
        return "buffer.writef64";
    case LBF_VECTOR_MAGNITUDE:
        return "vector.magnitude";
    case LBF_VECTOR_NORMALIZE:
        return "vector.normalize";
    case LBF_VECTOR_CROSS:
        return "vector.cross";
    case LBF_VECTOR_DOT:
        return "vector.dot";
    case LBF_VECTOR_FLOOR:
        return "vector.floor";
    case LBF_VECTOR_CEIL:
        return "vector.ceil";
    case LBF_VECTOR_ABS:
        return "vector.abs";
    case LBF_VECTOR_SIGN:
        return "vector.sign";
    case LBF_VECTOR_CLAMP:
        return "vector.clamp";
    case LBF_VECTOR_MIN:
        return "vector.min";
    case LBF_VECTOR_MAX:
        return "vector.max";
    case LBF_MATH_LERP:
        return "math.lerp";
    case LBF_VECTOR_LERP:
        return "vector.lerp";
    case LBF_MATH_ISNAN:
        return "math.isnan";
    case LBF_MATH_ISINF:
        return "math.isinf";
    case LBF_MATH_ISFINITE:
        return "math.isfinite";
    case LBF_BUFFER_READINTEGER:
        return "buffer.readinteger";
    case LBF_BUFFER_WRITEINTEGER:
        return "buffer.writeinteger";
    case LBF_INTEGER_CREATE:
        return "integer.create";
    case LBF_INTEGER_TONUMBER:
        return "integer.tonumber";
    case LBF_INTEGER_NEG:
        return "integer.neg";
    case LBF_INTEGER_ADD:
        return "integer.add";
    case LBF_INTEGER_SUB:
        return "integer.sub";
    case LBF_INTEGER_MUL:
        return "integer.mul";
    case LBF_INTEGER_DIV:
        return "integer.div";
    case LBF_INTEGER_MIN:
        return "integer.min";
    case LBF_INTEGER_MAX:
        return "integer.max";
    case LBF_INTEGER_REM:
        return "integer.rem";
    case LBF_INTEGER_IDIV:
        return "integer.idiv";
    case LBF_INTEGER_UDIV:
        return "integer.udiv";
    case LBF_INTEGER_UREM:
        return "integer.urem";
    case LBF_INTEGER_MOD:
        return "integer.mod";
    case LBF_INTEGER_CLAMP:
        return "integer.clamp";
    case LBF_INTEGER_BAND:
        return "integer.band";
    case LBF_INTEGER_BOR:
        return "integer.bor";
    case LBF_INTEGER_BNOT:
        return "integer.bnot";
    case LBF_INTEGER_BXOR:
        return "integer.bxor";
    case LBF_INTEGER_LT:
        return "integer.lt";
    case LBF_INTEGER_LE:
        return "integer.le";
    case LBF_INTEGER_ULT:
        return "integer.ult";
    case LBF_INTEGER_ULE:
        return "integer.ule";
    case LBF_INTEGER_GT:
        return "integer.gt";
    case LBF_INTEGER_GE:
        return "integer.ge";
    case LBF_INTEGER_UGT:
        return "integer.ugt";
    case LBF_INTEGER_UGE:
        return "integer.uge";
    case LBF_INTEGER_LSHIFT:
        return "integer.lshift";
    case LBF_INTEGER_RSHIFT:
        return "integer.rshift";
    case LBF_INTEGER_ARSHIFT:
        return "integer.arshift";
    case LBF_INTEGER_LROTATE:
        return "integer.lrotate";
    case LBF_INTEGER_RROTATE:
        return "integer.rrotate";
    case LBF_INTEGER_EXTRACT:
        return "integer.extract";
    case LBF_INTEGER_BTEST:
        return "integer.btest";
    case LBF_INTEGER_COUNTRZ:
        return "integer.countrz";
    case LBF_INTEGER_COUNTLZ:
        return "integer.countlz";
    case LBF_INTEGER_BSWAP:
        return "integer.bswap";

    default:
        return std::format("Unknown_BFID_{}", static_cast<int>(id));
    }
}

uint32_t BytecodeLifter::ReadAuxWord(const DeserializedFunction *function, size_t instructionIndex) {
    if (instructionIndex + 1 >= function->instructions.size()) {
        const auto opCode = LUAU_INSN_OP(function->instructions[instructionIndex].instruction);
        throw Fission::DecompilerError(
            std::format("malformed bytecode: opcode {} at instruction {} is missing its AUX word", static_cast<int>(opCode), instructionIndex)
        );
    }

    return function->instructions[instructionIndex + 1].instruction;
}

LiftedFunction BytecodeLifter::LiftFunctionBytecodeInternal(const DeserializedFunction *function, bool bIsMain) {
    DEBUG_ASSERT(function != nullptr);
    LiftedFunction liftedFunction{};
    liftedFunction.numparams = function->numparams;
    liftedFunction.lpDeserialized = const_cast<DeserializedFunction *>(function);

    if (function->debugName)
        liftedFunction.name = *function->debugName;
    else {
        if (bIsMain)
            liftedFunction.name = "_start";
        else
            liftedFunction.name = std::format("f{}", function->bytecodeId);
    }

    liftedFunction.instructions.reserve(function->instructions.size()); // on average, 1 Fission IR instruction = 1 Luau bytecode instruction

    for (size_t currentIndex = 0; currentIndex < function->instructions.size();) {
        Fission::CheckDecompileDeadline();
        const auto &instruction = LuauInstruction{lpDecoder->DecodeInstruction(function->instructions.at(currentIndex).instruction)};
        const uint8_t opCode = (uint8_t)instruction.GetOpCode();

        {
            if (opCode >= LOP__COUNT)
                throw Fission::DecompilerError("malformed bytecode: opcode is over LOP__COUNT! Cannot lift to Fission IR.");

            const int jumpTarget = Luau::getJumpTarget(instruction.instruction, static_cast<uint32_t>(currentIndex));
            if (jumpTarget != -1 && (jumpTarget < 0 || static_cast<size_t>(jumpTarget) >= function->instructions.size()))
                throw Fission::DecompilerError(
                    "malformed bytecode: instruction would jump too far ahead/back on the instruction stream. This could mean a jump is corrupted and control "
                    "flow "
                    "analysis would fail. Refusing to decompile."
                );
        }

        switch (opCode) {
        case LOP_NOP:
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP);
            break;
        case LOP_BREAK:
            liftedFunction.instructions.emplace_back(LiftedOperation::BREAK);
            break;
        case LOP_LOADNIL: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::LOAD);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateNil;
            break;
        }
        case LOP_LOADB: {
            const auto jumpOffset = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            auto &instr = liftedFunction.instructions.emplace_back(jumpOffset != 0 ? LiftedOperation::LOADNJUMP : LiftedOperation::LOAD);
            instr.operands.resize(jumpOffset != 0 ? 3 : 2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateBool;
            instr.operands[1].value.imm.b = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            if (jumpOffset != 0) {
                instr.operands[2].type = LiftedOperandType::ImmediateInteger;
                instr.operands[2].value.imm.n = jumpOffset + 1; // LOADB skips C instructions after itself
            }
            break;
        }
        case LOP_LOADN: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::LOAD);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD();
            break;
        }
        case LOP_LOADKX:
        case LOP_LOADK: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::LOAD);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateConstant;
            if (opCode == LOP_LOADK) {
                instr.operands[1].value.imm.k = instruction.GetD();
            } else {
                instr.operands[1].value.imm.k = ReadAuxWord(function, currentIndex);
            }

            std::stringstream finalComment;
            auto &k0 = function->constants.at(instr.operands[1].value.imm.k);

            switch (k0.kType) {
            case LUA_TSTRING:
                finalComment << "INFO: Loading Constant '" << std::get<std::string>(k0.constantData) << "'.";
                break;
            case LUA_TNUMBER:
                finalComment << "INFO: Loading Constant '" << std::get<LuauNumber>(k0.constantData) << "'.";
                break;
            case LUA_TINTEGER:
                finalComment << "INFO: Loading Constant '" << std::get<LuauInteger>(k0.constantData) << "i'.";
                break;
            case LUA_TVECTOR: {
                const auto &vec = std::get<LuauVectorConstant>(k0.constantData);
                std::visit(
                    [&](const auto &components) {
                        finalComment << "INFO: Loads Vector3 with components; x = " << components[0] << " y = " << components[1] << " z = " << components[2]
                                     << " w = " << components[3];
                    },
                    vec.components
                );
                break;
            }
            case LUA_TTABLE: {
                finalComment << "INFO: Loads Table Preset.";
                break;
            }
            default: {
                finalComment << "WARNING: Obtaining a non-representable constant which has not been handled. This should never happen unless the bytecode is "
                                "absolutely toasted or the kTable is corrupted";
                break;
            }
            }

            instr.instructionRemarks = finalComment.str();
            // emplace_back can invalidate instruction references.
            if (opCode == LOP_LOADKX)
                liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                    "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_MOVE: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::MOVE);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            break;
        }
        case LOP_GETGLOBAL: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::GETGLOBAL);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateConstant;
            instr.operands[1].value.imm.k = ReadAuxWord(function, currentIndex);

            std::stringstream finalComment;
            auto &k0 = function->constants.at(instr.operands[1].value.imm.k);

            if (k0.kType == LUA_TSTRING) {
                finalComment << "INFO: Obtaining Global " << std::get<std::string>(k0.constantData);
            } else {
                finalComment << "WARNING: Obtaining a non-representable global. This should never happen unless the bytecode is absolutely toasted or the "
                                "kTable is corrupted";
            }
            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_SETGLOBAL: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::SETGLOBAL);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateConstant;
            instr.operands[1].value.imm.k = ReadAuxWord(function, currentIndex);

            std::stringstream finalComment;
            auto &k0 = function->constants.at(instr.operands[1].value.imm.k);

            if (k0.kType == LUA_TSTRING) {
                finalComment << "INFO: Setting Global " << std::get<std::string>(k0.constantData);
            } else {
                finalComment << "WARNING: Setting a non-representable global. This should never happen unless the bytecode is absolutely toasted or the kTable "
                                "is corrupted";
            }

            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_GETUPVAL: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::GETUPVAL);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);

            instr.instructionRemarks =
                std::format("INFO: Loading upvalue at index {} of the function into R{}.", instr.operands[1].value.imm.n, instr.operands[0].value.reg);
            break;
        }
        case LOP_SETUPVAL: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::SETUPVAL);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            break;
        }
        case LOP_GETIMPORT: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::GETIMPORT);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateConstant; // destination to ktable if loaded properly
            instr.operands[1].value.imm.k = instruction.GetD();
            instr.operands[2].type = LiftedOperandType::ImmediateAux; // index chain
            instr.operands[2].value.imm.u = ReadAuxWord(function, currentIndex);

            // taken from luaV_getimport, thank you Luau, why the fuck isn't this in a fucking macro?
            int id0 = int(instr.operands[2].value.imm.u >> 20) & 1023;
            int id1 = int(instr.operands[2].value.imm.u >> 10) & 1023;
            int id2 = int(instr.operands[2].value.imm.u) & 1023;

            int indexCount = instr.operands[2].value.imm.u >> 30;
            // the compiler's getImportId encodes a path length of 1..3 in the top two bits; luaV_getimport
            // asserts count > 0. a zero count would make the AUX slot disappear from the lifted stream and
            // desynchronise every following instruction index.
            if (indexCount == 0)
                throw Fission::DecompilerError("malformed bytecode: GETIMPORT AUX encodes an empty import path");

            std::stringstream finalComment;
            finalComment << "INFO: Index Chain '";
            if (indexCount-- > 0) {
                auto &k0 = function->constants.at(id0);
                if (k0.kType == LUA_TSTRING)
                    finalComment << std::get<std::string>(k0.constantData);
            }
            if (indexCount-- > 0) {
                auto &k1 = function->constants.at(id1);
                if (k1.kType == LUA_TSTRING)
                    finalComment << "." << std::get<std::string>(k1.constantData);
            }
            if (indexCount-- > 0) {
                auto &k2 = function->constants.at(id2);
                if (k2.kType == LUA_TSTRING)
                    finalComment << "." << std::get<std::string>(k2.constantData);
            }

            finalComment << "'";

            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_GETTABLE: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::GETTABLE);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::Register;
            instr.operands[2].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            instr.instructionRemarks = std::format(
                "INFO: Getting the index (which is present at R{}) of a table at R{} into R{}", instr.operands[2].value.reg, instr.operands[1].value.reg,
                instr.operands[0].value.reg
            );
            break;
        }
        case LOP_SETTABLE: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::SETTABLE);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::Register;
            instr.operands[2].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);

            std::string additionalRemark = "";
            if (instr.operands[0].value.reg == instr.operands[1].value.reg)
                additionalRemark = ". Instruction self references table and value. Potential polymorphic pattern";
            instr.instructionRemarks = std::format(
                "INFO: Setting the index (which is present at R{}) of a table at R{} to R{}{}", instr.operands[2].value.reg, instr.operands[1].value.reg,
                instr.operands[0].value.reg, additionalRemark
            );
            break;
        }
        case LOP_GETTABLEKS: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::GETTABLEKS);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = ReadAuxWord(function, currentIndex);

            std::stringstream finalComment;
            auto &k0 = function->constants.at(instr.operands[2].value.imm.k);

            if (k0.kType == LUA_TSTRING) {
                finalComment << "INFO: Getting the index '" << std::get<std::string>(k0.constantData) << "' of a table at R"
                             << static_cast<int32_t>(instr.operands[1].value.reg) << " into R" << static_cast<int32_t>(instr.operands[0].value.reg);
            } else {
                finalComment << "WARNING: Getting a table index which cannot be represented. This should never happen unless the bytecode is absolutely "
                                "toasted or the kTable is corrupted";
            }

            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_SETTABLEKS: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::SETTABLEKS);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = ReadAuxWord(function, currentIndex);

            std::stringstream finalComment;
            auto &k0 = function->constants.at(instr.operands[2].value.imm.k);

            if (k0.kType == LUA_TSTRING) {
                std::string additionalRemark = "";
                if (instr.operands[0].value.reg == instr.operands[1].value.reg)
                    additionalRemark = ". Instruction self references table and value. Potential polymorphic pattern";

                finalComment << "INFO: Setting the index '" << std::get<std::string>(k0.constantData) << "' of a table at R"
                             << static_cast<int32_t>(instr.operands[1].value.reg) << " to the value in R" << static_cast<int32_t>(instr.operands[0].value.reg)
                             << additionalRemark;
            } else {
                finalComment << "WARNING: The index of the table cannot be represented. This should never happen unless the bytecode is absolutely toasted or "
                                "the kTable is corrupted";
            }

            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_GETTABLEN: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::GETTABLEN);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            instr.instructionRemarks = std::format(
                "INFO: Get the value of the numeric index '{}' of the table present at R{} and save it to R{}", instr.operands[2].value.imm.n + 1,
                instr.operands[1].value.reg, instr.operands[0].value.reg
            );
            break;
        }
        case LOP_SETTABLEN: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::SETTABLEN);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            instr.instructionRemarks = std::format(
                "INFO: Set the value of the numeric index '{}' of the table present at R{} to the value of R{}", instr.operands[2].value.imm.n + 1,
                instr.operands[1].value.reg, instr.operands[0].value.reg
            );
            break;
        }
        case LOP_NEWCLOSURE: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::NEWCLOSURE);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateConstant;
            instr.operands[1].value.imm.k = instruction.GetD();
            break;
        }
        case LOP_NAMECALL: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::NAMECALL);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = ReadAuxWord(function, currentIndex);

            std::stringstream finalComment;
            const auto &constant = function->constants.at(instr.operands[2].value.imm.k);

            if (constant.kType == LUA_TSTRING) {
                finalComment << "INFO: Setting up namecall: '" << std::get<std::string>(constant.constantData) << "'";
            } else {
                finalComment << "WARNING: The constant used in this namecall cannnot be represented.";
            }

            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_CALL: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::CALL);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);

            bool bIsVarargCall = instr.operands[1].value.imm.n == 0;
            bool bIsVarargReturn = instr.operands[2].value.imm.n == 0;

            std::string argsText;
            if (bIsVarargCall) {
                argsText = std::format("variadic arguments from register {} up to the top of the luau stack", instr.operands[1].value.imm.n);
            } else {
                if (instr.operands[1].value.imm.n - 1 > 1)
                    argsText = std::format(
                        "{} arguments (R{} to R{})", instr.operands[1].value.imm.n - 1, instr.operands[0].value.reg + 1,
                        instr.operands[0].value.reg + (instr.operands[1].value.imm.n - 1) // args are after the function, just like lua_call/lua_pcall in C.
                    );
                else if (instr.operands[1].value.imm.n - 1 == 1) {
                    argsText = std::format(
                        "1 argument (R{})",
                        instr.operands[0].value.reg + 1 // args are after the function, just like lua_call/lua_pcall in C.
                    );
                } else {
                    argsText = "no arguments";
                }
            }

            std::string retsText;
            if (bIsVarargReturn) {
                retsText = "a variadic return";
            } else {
                if (instr.operands[2].value.imm.n - 1 == 0) {
                    retsText = std::format("no arguments as a return");
                } else {
                    if (instr.operands[2].value.imm.n - 1 == 1) {
                        retsText = std::format(
                            "1 argument as a return (R{})", instr.operands[0].value.reg // rets replace the call on stack, like lua call and pcall rets on C.
                        );
                    } else {
                        retsText = std::format(
                            "{} arguments as a return (stored from R{} to R{})", instr.operands[2].value.imm.n - 1, instr.operands[0].value.reg,
                            instr.operands[0].value.reg +
                                (instr.operands[2].value.imm.n - 1) // rets replace the call on stack, like lua call and pcall rets on C.
                        );
                    }
                }
            }

            instr.instructionRemarks = std::format("INFO: Calling function at R{} with {}, expecting {}.", instr.operands[0].value.reg, argsText, retsText);

            break;
        }
        case LOP_RETURN: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::RETURN);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            break;
        }
        case LOP_JUMPX:
        case LOP_JUMPBACK:
        case LOP_JUMP: {
            if ((opCode != LOP_JUMPX && instruction.GetD() == 0) || instruction.GetE() == 0) {
                auto &ins = liftedFunction.instructions.emplace_back(LiftedOperation::NOP);
                ins.instructionRemarks = "WARNING: Op Code simplified, ignored by interpreter (JUMPX/JUMPBACK/JUMP)";
                break;
            }

            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::JUMP);
            instr.operands.resize(1);
            instr.operands[0].type = LiftedOperandType::ImmediateInteger;
            if (opCode == LOP_JUMPX) {
                instr.operands[0].value.imm.n = instruction.GetE();
            } else {
                instr.operands[0].value.imm.n = instruction.GetD();
            }
            instr.operands[0].value.imm.n++; // JUMP(X/BACK) instructions needs to jump one further, else we have to compensate at analysis time.
            instr.instructionRemarks = std::format("INFO: Jump PC to {}", currentIndex + instr.operands[0].value.imm.n);

            if (opCode == LOP_JUMPBACK) { // Jump back leaks information that the next instruction following it is actually the beginning of a loop. Jumpback
                                          // signifies the end of the loop. Thanks compiler.
                instr.operands.resize(2);
                instr.operands[1].type = LiftedOperandType::ImmediateBool;
                instr.operands[1].value.imm.b = true;
            }

            break;
        }
        case LOP_JUMPIF:
        case LOP_JUMPIFNOT: {
            if (instruction.GetD() == 0) {
                auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::NOP);
                instr.instructionRemarks = "WARNING: Op Code simplified, ignored by interpreter (JUMPIF/JUMPIFNOT)";
                break;
            }
            auto &instr = liftedFunction.instructions.emplace_back(opCode == LOP_JUMPIF ? LiftedOperation::JUMPIF : LiftedOperation::JUMPIFNOT);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD();

            break;
        }
        case LOP_JUMPIFEQ:
        case LOP_JUMPIFLE:
        case LOP_JUMPIFLT:
        case LOP_JUMPIFNOTEQ:
        case LOP_JUMPIFNOTLE:
        case LOP_JUMPIFNOTLT: {
            LiftedOperation liftedOpCode;
            switch (opCode) {
            case LOP_JUMPIFEQ:
                liftedOpCode = LiftedOperation::JUMPIFEQ;
                break;
            case LOP_JUMPIFLE:
                liftedOpCode = LiftedOperation::JUMPIFLE;
                break;
            case LOP_JUMPIFLT:
                liftedOpCode = LiftedOperation::JUMPIFLT;
                break;
            case LOP_JUMPIFNOTEQ:
                liftedOpCode = LiftedOperation::JUMPIFNOTEQ;
                break;
            case LOP_JUMPIFNOTLE:
                liftedOpCode = LiftedOperation::JUMPIFNOTLE;
                break;
            case LOP_JUMPIFNOTLT:
                liftedOpCode = LiftedOperation::JUMPIFNOTLT;
                break;

            default:
                ASSERT(false, "how?");
            }

            // D==1 means the branch jumps to the immediately-following instruction; a no-op branch
            // (`if a < b then continue end` at a loop-body end, `if a < b then end`). The branch is dead,
            // but unlike JUMPIF/JUMPIFNOT (a pure truthiness test) these comparison ops STILL evaluate
            // `a <op> b` in the VM, which raises on incompatible types (`"" < f` -> "attempt to compare
            // string < function"). NOPing them dropped that throw. Lift the comparison normally; its two
            // targets resolve to the same next block, and the AST lifter renders `if <cond> then end`
            // (IsTriviallyDeadIf keeps it; only pure-read conditions are dropped), preserving the effect.
            auto &instr = liftedFunction.instructions.emplace_back(liftedOpCode);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD();
            instr.operands[2].type = LiftedOperandType::Register;
            instr.operands[2].value.reg = ReadAuxWord(function, currentIndex);
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_ADD:
        case LOP_SUB:
        case LOP_MUL:
        case LOP_DIV:
        case LOP_MOD:
        case LOP_POW: {
            LiftedOperation liftedOpCode;
            switch (opCode) {
            case LOP_ADD:
                liftedOpCode = LiftedOperation::ADD;
                break;
            case LOP_SUB:
                liftedOpCode = LiftedOperation::SUB;
                break;
            case LOP_MUL:
                liftedOpCode = LiftedOperation::MUL;
                break;
            case LOP_DIV:
                liftedOpCode = LiftedOperation::DIV;
                break;
            case LOP_MOD:
                liftedOpCode = LiftedOperation::MOD;
                break;
            case LOP_POW:
                liftedOpCode = LiftedOperation::POW;
                break;

            default:
                ASSERT(false, "how?");
            }

            auto &instr = liftedFunction.instructions.emplace_back(liftedOpCode);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::Register;
            instr.operands[2].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            break;
        }
        case LOP_ADDK:
        case LOP_SUBK:
        case LOP_MULK:
        case LOP_DIVK:
        case LOP_MODK:
        case LOP_POWK: {
            LiftedOperation liftedOpCode;
            switch (opCode) {
            case LOP_ADDK:
                liftedOpCode = LiftedOperation::ADDK;
                break;
            case LOP_SUBK:
                liftedOpCode = LiftedOperation::SUBK;
                break;
            case LOP_MULK:
                liftedOpCode = LiftedOperation::MULK;
                break;
            case LOP_DIVK:
                liftedOpCode = LiftedOperation::DIVK;
                break;
            case LOP_MODK:
                liftedOpCode = LiftedOperation::MODK;
                break;
            case LOP_POWK:
                liftedOpCode = LiftedOperation::POWK;
                break;

            default:
                ASSERT(false, "how?");
            }

            auto &instr = liftedFunction.instructions.emplace_back(liftedOpCode);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            break;
        }
        case LOP_AND:
        case LOP_OR: {
            auto &instr = liftedFunction.instructions.emplace_back(opCode == LOP_AND ? LiftedOperation::AND : LiftedOperation::OR);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::Register;
            instr.operands[2].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            break;
        }
        case LOP_ANDK:
        case LOP_ORK: {
            auto &instr = liftedFunction.instructions.emplace_back(opCode == LOP_ANDK ? LiftedOperation::ANDK : LiftedOperation::ORK);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            break;
        }
        case LOP_CONCAT: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::CONCAT);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::Register;
            instr.operands[2].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            break;
        }
        case LOP_NOT:
        case LOP_MINUS:
        case LOP_LENGTH: {
            LiftedOperation liftedOpCode;
            switch (opCode) {
            case LOP_NOT:
                liftedOpCode = LiftedOperation::NOT;
                break;
            case LOP_MINUS:
                liftedOpCode = LiftedOperation::MINUS;
                break;
            case LOP_LENGTH:
                liftedOpCode = LiftedOperation::LENGTH;
                break;

            default:
                ASSERT(false, "how?");
            }

            auto &instr = liftedFunction.instructions.emplace_back(liftedOpCode);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            break;
        }
        case LOP_NEWTABLE: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::NEWTABLE);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = ReadAuxWord(function, currentIndex);
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_DUPTABLE: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::DUPTABLE);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateConstant;
            instr.operands[1].value.imm.k = instruction.GetD();
            break;
        }
        case LOP_SETLIST: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::SETLIST);
            instr.operands.resize(4);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            instr.operands[3].type = LiftedOperandType::ImmediateInteger;
            instr.operands[3].value.imm.n = ReadAuxWord(function, currentIndex);
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_FORNPREP: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FORNPREP);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD();
            break;
        }
        case LOP_FORNLOOP: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FORNLOOP);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD();
            instr.operands[2].type = LiftedOperandType::Register;
            instr.operands[2].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A) + 2; // control variable.
            break;
        }
        case LOP_FORGLOOP: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FORGLOOP);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD();
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = ReadAuxWord(function, currentIndex);
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_FORGPREP_INEXT: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FORGPREP_INEXT);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD();
            break;
        }
        case LOP_FASTCALL3: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FASTCALL3);
            instr.operands.resize(5);
            instr.operands[0].type = LiftedOperandType::ImmediateInteger;
            instr.operands[0].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            const auto aux = ReadAuxWord(function, currentIndex);
            instr.operands[3].type = LiftedOperandType::Register;
            instr.operands[3].value.reg = LUAU_INSN_AUX_A(aux);
            instr.operands[4].type = LiftedOperandType::Register;
            instr.operands[4].value.reg = LUAU_INSN_AUX_B(aux);

            instr.instructionRemarks =
                std::format("INFO: Perform FastCall3 of '{}'", GetLuauBuiltinName(static_cast<LuauBuiltinFunction>(instr.operands[0].value.imm.n)));
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_FORGPREP_NEXT: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FORGPREP_NEXT);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD();
            break;
        }
        case LOP_GETVARARGS: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::GETVARARGS);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            break;
        }
        case LOP_DUPCLOSURE: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::DUPCLOSURE);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateConstant;
            instr.operands[1].value.imm.k = instruction.GetD();
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = std::get<LuauProto>(function->constants.at(instruction.GetD()).constantData)->bytecodeId; // Bytecode Identifier

            instr.instructionRemarks = std::format(
                "INFO: Attempt to create a duplicate of the closure at K{} (bytecode id of {}, with name '{}').", instruction.GetD(),
                instr.operands[2].value.imm.n,
                std::get<LuauProto>(function->constants.at(instruction.GetD()).constantData)->debugName.value_or("anonymous closure")
            );
            break;
        }
        case LOP_PREPVARARGS: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::PREPVARARGS);
            instr.operands.resize(1);
            instr.operands[0].type = LiftedOperandType::ImmediateInteger;
            instr.operands[0].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            break;
        }
        case LOP_FASTCALL: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FASTCALL);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::ImmediateInteger;
            instr.operands[0].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);

            instr.instructionRemarks =
                std::format("INFO: Perform FastCall of '{}'", GetLuauBuiltinName(static_cast<LuauBuiltinFunction>(instr.operands[0].value.imm.n)));
            break;
        }
        case LOP_FASTPCALL: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FASTPCALL);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::ImmediateInteger;
            instr.operands[0].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            instr.instructionRemarks = std::format(
                "INFO: Perform fast protected {} with {} explicit arguments.", instr.operands[0].value.imm.n == 0 ? "pcall" : "xpcall",
                instr.operands[1].value.imm.n
            );
            break;
        }
        case LOP_COVERAGE: {
            auto &ins = liftedFunction.instructions.emplace_back(LiftedOperation::NOP); // Unlikely to be seen in the wild, but we need it
            ins.instructionRemarks = "WARNING: Op Code simplified, ignored by interpreter (COVERAGE)";
            break;
        }
        case LOP_CAPTURE: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::CAPTURE);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::ImmediateInteger;
            instr.operands[0].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            break;
        }
        case LOP_SUBRK:
        case LOP_DIVRK: {
            auto &instr = liftedFunction.instructions.emplace_back(opCode == LOP_SUBRK ? LiftedOperation::SUBRK : LiftedOperation::DIVRK);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateConstant;
            instr.operands[1].value.imm.k = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::Register;
            instr.operands[2].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            break;
        }
        case LOP_FASTCALL1: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FASTCALL1);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::ImmediateInteger;
            instr.operands[0].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);

            instr.instructionRemarks =
                std::format("INFO: Perform FastCall1 of '{}'", GetLuauBuiltinName(static_cast<LuauBuiltinFunction>(instr.operands[0].value.imm.n)));
            break;
        }
        case LOP_FASTCALL2: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FASTCALL2);
            instr.operands.resize(4);
            instr.operands[0].type = LiftedOperandType::ImmediateInteger;
            instr.operands[0].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            instr.operands[3].type = LiftedOperandType::Register;
            instr.operands[3].value.reg = LUAU_INSN_AUX_A(ReadAuxWord(function, currentIndex));

            instr.instructionRemarks =
                std::format("INFO: Perform FastCall2 of '{}'", GetLuauBuiltinName(static_cast<LuauBuiltinFunction>(instr.operands[0].value.imm.n)));
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_FASTCALL2K: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FASTCALL2K);
            instr.operands.resize(4);
            instr.operands[0].type = LiftedOperandType::ImmediateInteger;
            instr.operands[0].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            instr.operands[3].type = LiftedOperandType::ImmediateConstant;
            instr.operands[3].value.imm.k = ReadAuxWord(function, currentIndex);

            instr.instructionRemarks =
                std::format("INFO: Perform FastCall2K of '{}'", GetLuauBuiltinName(static_cast<LuauBuiltinFunction>(instr.operands[0].value.imm.n)));
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_FORGPREP: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::FORGPREP);
            instr.operands.resize(2);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD();
            break;
        }
        case LOP_IDIV: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::IDIV);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::Register;
            instr.operands[2].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            break;
        }
        case LOP_IDIVK: {
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::IDIVK);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            break;
        }
        case LOP_JUMPXEQKNIL:
        case LOP_JUMPXEQKB: {
            // if (instruction.GetD() == 1u) {
            //     // instruction doesn't contribute to CFlow, eliminate straight up.
            //     auto &ins = liftedFunction.instructions.emplace_back(LiftedOperation::NOP);
            //     liftedFunction.instructions.emplace_back(LiftedOperation::NOP);
            //     ins.instructionRemarks = "WARNING: Op Code simplified, the jump target pointed to pc++ (JUMPXEQXX)";
            //     break;
            // }
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::JUMPXEQK);
            instr.operands.resize(4);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetD() + 1;

            const auto aux = ReadAuxWord(function, currentIndex);
            auto constantAsString = std::string("");

            if (opCode == LOP_JUMPXEQKB) {
                instr.operands[2].type = LiftedOperandType::ImmediateBool;
                instr.operands[2].value.imm.b = LUAU_INSN_AUX_KB(aux) != 0;
                constantAsString = std::format("{}", instr.operands[2].value.imm.b);
            } else {
                instr.operands[2].type = LiftedOperandType::ImmediateNil;
                constantAsString = "nil";
            }
            instr.operands[3].type = LiftedOperandType::ImmediateBool; // NOT flag
            instr.operands[3].value.imm.b = LUAU_INSN_AUX_NOT(aux) != 0;

            auto jumpTarget = instr.operands[1].value.imm.n + currentIndex;
            auto targetRegister = instr.operands[0].value.reg;
            auto equal = instr.operands[3].value.imm.b ? " not" : "";

            instr.instructionRemarks =
                std::format("INFO: Jump PC to {} if the value at register {} is{} equal to '{}'.", jumpTarget, targetRegister, equal, constantAsString);
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }

        case LOP_JUMPXEQKN:
        case LOP_JUMPXEQKS: {
            // if (instruction.GetD() == 1u) {
            //     // instruction doesn't contribute to CFlow, eliminate straight up.
            //     auto &ins = liftedFunction.instructions.emplace_back(LiftedOperation::NOP);
            //     liftedFunction.instructions.emplace_back(LiftedOperation::NOP);
            //     ins.instructionRemarks = "WARNING: Op Code simplified, the jump target pointed to pc++ (JUMPXEQXX)";
            //     break;
            // }
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::JUMPXEQK);
            instr.operands.resize(4);
            instr.operands[0].type = LiftedOperandType::Register; // src
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger; // jmp off
            instr.operands[1].value.imm.n = instruction.GetD() + 1;
            const auto aux = ReadAuxWord(function, currentIndex);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant; // ktable idx
            instr.operands[2].value.imm.k = LUAU_INSN_AUX_KV(aux);
            instr.operands[3].type = LiftedOperandType::ImmediateBool; // NOT flag
            instr.operands[3].value.imm.b = LUAU_INSN_AUX_NOT(aux) != 0;

            auto jumpTarget = instr.operands[1].value.imm.n + currentIndex;
            auto targetRegister = instr.operands[0].value.reg;
            auto equal = instr.operands[3].value.imm.b ? " not" : "";
            auto constantAsString = std::string("");

            auto k0 = function->constants.at(instr.operands[2].value.imm.k);

            switch (k0.kType) {
            case LUA_TSTRING:
                constantAsString = std::format("{}", std::get<std::string>(k0.constantData));
                break;
            case LUA_TNUMBER:
                constantAsString = std::format("{}", std::get<LuauNumber>(k0.constantData));
                break;
            default:;
                constantAsString = "well. This is weird. This instruction is referencing a constant that it shouldn't! Malformed Bytecode!";
                break;
            }

            instr.instructionRemarks = std::format(
                "INFO: Jump PC to {} if the value at register {} is{} equal to the number/string '{}'.", jumpTarget, targetRegister, equal, constantAsString
            );

            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }

        case LOP_CLOSEUPVALS: {
            auto &ins = liftedFunction.instructions.emplace_back(LiftedOperation::NOP);
            ins.instructionRemarks = std::format(
                "WARNING: Op Code simplified, it was previously CLOSEUPVALS, but in decompilation, this doesn't really provide significant information. This "
                "opcode migrates upvalues from the function's uv list to the heap from register R{} downward.",
                instruction.GetABCOperand(LuauInstruction::LuauOperand::A)
            );
            liftedFunction.upvalueCloses.emplace_back(
                static_cast<int32_t>(liftedFunction.instructions.size() - 1), static_cast<uint8_t>(instruction.GetABCOperand(LuauInstruction::LuauOperand::A))
            );
            break;
        }

        case LOP_GETUDATAKS: {
            // Mirror of GETTABLEKS for atom-based userdata field access. AUX low 16 bits = constant string index.
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::GETTABLEKS);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = ReadAuxWord(function, currentIndex) & 0xFFFF;

            std::stringstream finalComment;
            auto &k0 = function->constants.at(instr.operands[2].value.imm.k);
            if (k0.kType == LUA_TSTRING) {
                finalComment << "INFO: Userdata-accelerated GET of field '" << std::get<std::string>(k0.constantData) << "' from R"
                             << static_cast<int32_t>(instr.operands[1].value.reg) << " into R" << static_cast<int32_t>(instr.operands[0].value.reg);
            } else {
                finalComment << "WARNING: Userdata-accelerated GET with non-string key constant.";
            }
            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_SETUDATAKS: {
            // Mirror of SETTABLEKS for atom-based userdata field write. AUX low 16 bits = constant string index.
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::SETTABLEKS);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = ReadAuxWord(function, currentIndex) & 0xFFFF;

            std::stringstream finalComment;
            auto &k0 = function->constants.at(instr.operands[2].value.imm.k);
            if (k0.kType == LUA_TSTRING) {
                finalComment << "INFO: Userdata-accelerated SET of field '" << std::get<std::string>(k0.constantData) << "' on R"
                             << static_cast<int32_t>(instr.operands[1].value.reg) << " to R" << static_cast<int32_t>(instr.operands[0].value.reg);
            } else {
                finalComment << "WARNING: Userdata-accelerated SET with non-string key constant.";
            }
            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_NAMECALLUDATA: {
            // Mirror of NAMECALL for atom-based userdata method dispatch.
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::NAMECALL);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = ReadAuxWord(function, currentIndex) & 0xFFFF;

            std::stringstream finalComment;
            auto &k0 = function->constants.at(instr.operands[2].value.imm.k);
            if (k0.kType == LUA_TSTRING) {
                finalComment << "INFO: Userdata-accelerated namecall: '" << std::get<std::string>(k0.constantData) << "'";
            } else {
                finalComment << "WARNING: Userdata-accelerated namecall with non-string method key.";
            }
            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_NEWCLASSMEMBER: {
            // V10. A = class register, C = initial value register (currently always a function), AUX = constant string member name.
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::NEWCLASSMEMBER);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::Register;
            instr.operands[1].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            instr.operands[2].type = LiftedOperandType::ImmediateConstant;
            instr.operands[2].value.imm.k = ReadAuxWord(function, currentIndex);

            std::stringstream finalComment;
            auto &k0 = function->constants.at(instr.operands[2].value.imm.k);
            if (k0.kType == LUA_TSTRING) {
                finalComment << "INFO: Register class member '" << std::get<std::string>(k0.constantData) << "' on class at R"
                             << static_cast<int32_t>(instr.operands[0].value.reg) << " using value at R" << static_cast<int32_t>(instr.operands[1].value.reg);
            } else {
                finalComment << "WARNING: NEWCLASSMEMBER with non-string member name.";
            }
            instr.instructionRemarks = finalComment.str();
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_NEWCLASS: {
            // V100: A = class, B = superclass or 0xFF, C bit 0 = open, AUX = class shape.
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::NEWCLASS);
            instr.operands.resize(4);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            const auto super = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            if (super == 0xFF) {
                instr.operands[1].type = LiftedOperandType::ImmediateNil;
            } else {
                instr.operands[1].type = LiftedOperandType::Register;
                instr.operands[1].value.reg = super;
            }
            instr.operands[2].type = LiftedOperandType::ImmediateBool;
            instr.operands[2].value.imm.b = (instruction.GetABCOperand(LuauInstruction::LuauOperand::C) & 1u) != 0;
            instr.operands[3].type = LiftedOperandType::ImmediateConstant;
            instr.operands[3].value.imm.k = ReadAuxWord(function, currentIndex);

            const auto &shape = function->constants.at(instr.operands[3].value.imm.k);
            if (!shape.IsClassShape())
                throw Fission::DecompilerError("malformed NEWCLASS: AUX is not a class-shape constant");
            instr.instructionRemarks = std::format(
                "INFO: Reify class '{}'{}.", std::get<LuauClassShape>(shape.constantData).className, instr.operands[2].value.imm.b ? " (open)" : ""
            );
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_CALLFB: {
            // V11. Identical call semantics to LOP_CALL (A = callee register, B = arg count + 1, C = result
            // count + 1); the AUX word carries a runtime feedback slot id that is irrelevant to
            // decompilation. Downstream (CFA/SSA/AST) treats CALLFB exactly like CALL.
            auto &instr = liftedFunction.instructions.emplace_back(LiftedOperation::CALLFB);
            instr.operands.resize(3);
            instr.operands[0].type = LiftedOperandType::Register;
            instr.operands[0].value.reg = instruction.GetABCOperand(LuauInstruction::LuauOperand::A);
            instr.operands[1].type = LiftedOperandType::ImmediateInteger;
            instr.operands[1].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::B);
            instr.operands[2].type = LiftedOperandType::ImmediateInteger;
            instr.operands[2].value.imm.n = instruction.GetABCOperand(LuauInstruction::LuauOperand::C);
            instr.instructionRemarks = std::format("INFO: Calling function at R{} (with runtime feedback collection).", instr.operands[0].value.reg);
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_CMPPROTO: {
            // V11 native-codegen closure-specialization guard: "if R(A) holds a closure of proto AUX, fall
            // through; else jump to the generic path." It is never emitted by Luau::compile (only appears
            // inside CodeGen's internal bytecode graph), and has no Luau source form. Rendering it as a
            // branch would need a condition expression that does not exist, so we elide it: emit a NOP that
            // follows the specialized (proto-matches) fallthrough. The jump to the generic deopt path is
            // dropped; that path is semantically redundant with the specialized one.
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "WARNING: native-codegen proto guard (CMPPROTO) elided; following the specialized path.";
            liftedFunction.instructions.emplace_back(LiftedOperation::NOP).instructionRemarks =
                "INFO: padding due to the original instruction requiring an auxiliary.";
            break;
        }
        case LOP_NATIVECALL: {
            auto &ins = liftedFunction.instructions.emplace_back(LiftedOperation::NOP);
            ins.instructionRemarks = "WARNING: Op Code simplified (NATIVECALL). Pseudo-instruction, never emitted by the bytecode compiler.";
            break;
        }

        default:
            if (opCode < LOP_NOP || opCode > LOP__COUNT)
                ASSERT(false, "malformed instruction, potentially mis-sized?", (LuauOpcode)opCode);

            ASSERT(false, "unhandled opcode.", (LuauOpcode)opCode);
            break;
        }

        currentIndex += instruction.GetOpCodeSize();
    }

    // every referenced register must address the stack; a register past maxstacksize (directly or via a
    // call/return count) would index the per-register SSA arrays out of bounds later. drop the sample.
    const long maxReg = function->maxstacksize; // arrays are sized maxstacksize+1
    const auto requireReg = [&](long r) {
        if (r < 0 || r > maxReg)
            throw Fission::DecompilerError("malformed bytecode: register access outside the function's stack space");
    };
    for (const auto &inst : liftedFunction.instructions) {
        // CAPTURE's source is mode-dependent (register for VAL/REF, upvalue index for UPVAL); validated in the switch.
        if (inst.operation != LiftedOperation::CAPTURE)
            for (const auto &op : inst.operands) {
                if (op.type == LiftedOperandType::Register)
                    requireReg(op.value.reg);
                // ImmediateConstant operands aren't all pool indices (NEWCLOSURE proto, GETIMPORT id); checked at use.
            }

        // implicit register ranges, mirroring SSABuilder's rename (base + count/immediate). validate the max reached.
        switch (inst.operation) {
        case LiftedOperation::CALL:
        case LiftedOperation::CALLFB: {
            if (inst.operands.size() < 3)
                break;
            const long base = inst.operands[0].value.reg;
            const long nparams = inst.operands[1].value.imm.n; // 0 == multret args (bounded by live regs)
            if (nparams != 0)
                requireReg(base + (nparams - 1)); // args occupy base+1..base+(nparams-1)
            const long retCount = inst.operands[2].value.imm.n;
            const long effRet = (retCount == 0) ? 1 : (retCount - 1); // retCount==1 => 0 results => no return regs
            if (effRet > 0)
                requireReg(base + effRet - 1); // returns land in base..base+effRet-1
            break;
        }
        case LiftedOperation::NAMECALL: {
            if (!inst.operands.empty())
                requireReg(inst.operands[0].value.reg + 1); // implicit self at base+1
            break;
        }
        case LiftedOperation::RETURN: {
            if (inst.operands.size() < 2)
                break;
            const long base = inst.operands[0].value.reg;
            const long count = inst.operands[1].value.imm.n - 1; // -1 (imm 0) == multret (bounded)
            if (count > 0)
                requireReg(base + count - 1);
            break;
        }
        case LiftedOperation::SETLIST: {
            if (inst.operands.size() < 3)
                break;
            const long base = inst.operands[1].value.reg;
            const long count = inst.operands[2].value.imm.n;
            const long eff = (count == 0) ? 1 : (count - 1);
            if (eff > 0)
                requireReg(base + eff - 1);
            break;
        }
        case LiftedOperation::GETVARARGS: {
            if (inst.operands.size() < 2)
                break;
            const long base = inst.operands[0].value.reg;
            const long count = inst.operands[1].value.imm.n;
            const long eff = (count == 0) ? 1 : (count - 1);
            if (eff > 0)
                requireReg(base + eff - 1);
            break;
        }
        case LiftedOperation::FORNPREP:
        case LiftedOperation::FORGPREP:
        case LiftedOperation::FORGPREP_INEXT:
        case LiftedOperation::FORGPREP_NEXT: {
            if (!inst.operands.empty())
                requireReg(inst.operands[0].value.reg + 2); // base, base+1, base+2
            break;
        }
        case LiftedOperation::FORGLOOP: {
            if (inst.operands.size() < 3)
                break;
            const long base = inst.operands[0].value.reg;
            const long numVars = inst.operands[2].value.imm.n & 0xFF;
            requireReg(base + 2);
            if (numVars > 0)
                requireReg(base + 3 + (numVars - 1)); // loop variables at base+3..
            break;
        }
        case LiftedOperation::NEWCLOSURE: {
            // operand[1] is a child-proto (subfunction) index; the AST lifter dereferences it unchecked.
            if (inst.operands.size() > 1) {
                const long idx = inst.operands[1].value.imm.k;
                if (idx < 0 || static_cast<size_t>(idx) >= function->subfunctions.size())
                    throw Fission::DecompilerError("malformed bytecode: NEWCLOSURE subfunction index out of range");
            }
            break;
        }
        case LiftedOperation::CAPTURE: {
            // operand[0] = type (0=VAL, 1=REF, 2=UPVAL); only VAL/REF source is a register (UPVAL is an upvalue index).
            if (inst.operands.size() >= 2 && inst.operands[0].value.imm.n != 2)
                requireReg(inst.operands[1].value.reg);
            break;
        }
        default:
            break;
        }
    }

    // Validate every lifted jump/branch target against the EXACT offset the control-flow analyzer will
    // use (ControlFlowAnalyzer::GetJumpOffset), which reads the lifted operands rather than the raw
    // instruction. The CFA does `lpTail + offset` and indexes the instruction stream by it; an offset
    // landing outside the stream (corrupt jump displacement) would read out of bounds there. The lifted
    // stream is 1:1 with the raw one, so a target is the instruction's own index plus that offset.
    const long liftedCount = static_cast<long>(liftedFunction.instructions.size());
    // FORNPREP offsets name the FORNLOOP so the latch stands in for the exit. When the compiler threads
    // the exit elsewhere, that shorthand lands one instruction early; use the VM target instead.
    for (long i = 0; i < liftedCount; ++i) {
        auto &inst = liftedFunction.instructions[i];
        if (inst.operation != LiftedOperation::FORNPREP || inst.operands.size() < 2)
            continue;
        const long target = i + inst.operands[1].value.imm.n;
        if (target < 0 || target >= liftedCount)
            continue;
        const auto &latch = liftedFunction.instructions[target];
        if (latch.operation != LiftedOperation::FORNLOOP || latch.operands.empty() || latch.operands[0].value.reg != inst.operands[0].value.reg)
            ++inst.operands[1].value.imm.n;
    }
    for (long i = 0; i < liftedCount; ++i) {
        const auto &inst = liftedFunction.instructions[i];
        const auto &ops = inst.operands;
        long offset = 0;
        bool isJump = true;
        switch (inst.operation) {
        case LiftedOperation::JUMP:
            offset = ops.size() > 0 ? ops[0].value.imm.n : 0;
            break;
        case LiftedOperation::LOADNJUMP:
            offset = ops.size() > 2 ? ops[2].value.imm.n : 0;
            break;
        case LiftedOperation::FORNPREP:
        case LiftedOperation::FORNLOOP:
        case LiftedOperation::FORGLOOP:
        case LiftedOperation::JUMPXEQK:
        case LiftedOperation::CMPPROTO:
            offset = ops.size() > 1 ? ops[1].value.imm.n : 0;
            break;
        case LiftedOperation::FORGPREP:
        case LiftedOperation::FORGPREP_INEXT:
        case LiftedOperation::FORGPREP_NEXT:
        case LiftedOperation::JUMPIF:
        case LiftedOperation::JUMPIFNOT:
        case LiftedOperation::JUMPIFEQ:
        case LiftedOperation::JUMPIFNOTEQ:
        case LiftedOperation::JUMPIFLE:
        case LiftedOperation::JUMPIFNOTLE:
        case LiftedOperation::JUMPIFLT:
        case LiftedOperation::JUMPIFNOTLT:
            offset = ops.size() > 1 ? ops[1].value.imm.n + 1 : 0;
            break;
        default:
            isJump = false;
            break;
        }
        if (isJump) {
            const long target = i + offset;
            if (target < 0 || target >= liftedCount)
                throw Fission::DecompilerError("malformed bytecode: jump target outside the instruction stream");
        }
    }

    // every raw slot (including AUX words) must have exactly one lifted slot; downstream stages map
    // instructionIndex back into the raw stream and assume this 1:1 correspondence.
    if (liftedFunction.instructions.size() != function->instructions.size())
        throw Fission::DecompilerError("malformed bytecode: lifted instruction count does not match the raw instruction stream");

    for (size_t currentIndex = 0; currentIndex < function->instructions.size(); currentIndex++) {
        liftedFunction.instructions.at(currentIndex).instructionIndex = (int32_t)currentIndex;
    }

    return liftedFunction;
}

LiftedFunction BytecodeLifter::LiftDeserializedBytecode(const DeserializedBytecode &bytecode) {
    struct Frame {
        LiftedFunction lifted;
        size_t nextChild;
    };
    std::vector<Frame> stack;
    std::unordered_set<const DeserializedFunction *> onPath;
    const auto push = [&](const DeserializedFunction *function, bool bIsMain) {
        if (!onPath.insert(function).second)
            throw Fission::DecompilerError("malformed bytecode: function references itself (cycle). Cowardly refusing to decompile!");
        stack.push_back({LiftFunctionBytecodeInternal(function, bIsMain), 0});
    };

    push(bytecode.lpMainFunction, true);
    for (;;) {
        Fission::CheckDecompileDeadline();
        auto &top = stack.back();
        const auto &children = top.lifted.lpDeserialized->subfunctions;
        if (top.nextChild < children.size()) {
            push(children[top.nextChild++], false);
            continue;
        }
        LiftedFunction done = std::move(top.lifted);
        onPath.erase(done.lpDeserialized);
        stack.pop_back();
        if (stack.empty())
            return done;
        stack.back().lifted.subfunctions.push_back(std::move(done));
    }
}

std::string_view OperationToString(LiftedOperation operation) {
    switch (operation) {
    case LiftedOperation::NOP:
        return "NOP";
    case LiftedOperation::BREAK:
        return "DEBUGBREAK";
    case LiftedOperation::LOAD:
        return "LOAD";
    case LiftedOperation::LOADNJUMP:
        return "LOAD_AND_JUMP";
    case LiftedOperation::MOVE:
        return "MOVE";
    case LiftedOperation::GETGLOBAL:
        return "GETGLOBAL";
    case LiftedOperation::SETGLOBAL:
        return "SETGLOBAL";
    case LiftedOperation::GETUPVAL:
        return "GETUPVAL";
    case LiftedOperation::SETUPVAL:
        return "SETUPVAL";
    case LiftedOperation::GETIMPORT:
        return "GETIMPORT";
    case LiftedOperation::GETTABLE:
        return "GETTABLE";
    case LiftedOperation::SETTABLE:
        return "SETTABLE";
    case LiftedOperation::GETTABLEKS:
        return "GETTABLEKS";
    case LiftedOperation::SETTABLEKS:
        return "SETTABLEKS";
    case LiftedOperation::GETTABLEN:
        return "GETTABLEN";
    case LiftedOperation::SETTABLEN:
        return "SETTABLEN";
    case LiftedOperation::NEWTABLE:
        return "NEWTABLE";
    case LiftedOperation::DUPTABLE:
        return "DUPTABLE";
    case LiftedOperation::SETLIST:
        return "SETLIST";
    case LiftedOperation::NEWCLOSURE:
        return "NEWCLOSURE";
    case LiftedOperation::DUPCLOSURE:
        return "DUPCLOSURE";
    case LiftedOperation::NAMECALL:
        return "NAMECALL";
    case LiftedOperation::CALL:
        return "CALL";
    case LiftedOperation::RETURN:
        return "RETURN";
    case LiftedOperation::GETVARARGS:
        return "GETVARARGS";
    case LiftedOperation::PREPVARARGS:
        return "PREPVARARGS";
    case LiftedOperation::CAPTURE:
        return "CAPTURE";
    case LiftedOperation::FASTCALL:
        return "FASTCALL";
    case LiftedOperation::FASTPCALL:
        return "FASTPCALL";
    case LiftedOperation::FASTCALL1:
        return "FASTCALL1";
    case LiftedOperation::FASTCALL2:
        return "FASTCALL2";
    case LiftedOperation::FASTCALL2K:
        return "FASTCALL2K";
    case LiftedOperation::FASTCALL3:
        return "FASTCALL3";
    case LiftedOperation::JUMP:
        return "JUMP";
    case LiftedOperation::JUMPIF:
        return "JUMPIF";
    case LiftedOperation::JUMPIFNOT:
        return "JUMPIFNOT";
    case LiftedOperation::JUMPIFEQ:
        return "JUMPIFEQ";
    case LiftedOperation::JUMPIFLE:
        return "JUMPIFLE";
    case LiftedOperation::JUMPIFLT:
        return "JUMPIFLT";
    case LiftedOperation::JUMPIFNOTEQ:
        return "JUMPIFNOTEQ";
    case LiftedOperation::JUMPIFNOTLE:
        return "JUMPIFNOTLE";
    case LiftedOperation::JUMPIFNOTLT:
        return "JUMPIFNOTLT";
    case LiftedOperation::FORNPREP:
        return "FORNPREP";
    case LiftedOperation::FORNLOOP:
        return "FORNLOOP";
    case LiftedOperation::FORGLOOP:
        return "FORGLOOP";
    case LiftedOperation::FORGPREP:
        return "FORGPREP";
    case LiftedOperation::FORGPREP_INEXT:
        return "FORGPREP_INEXT";
    case LiftedOperation::FORGPREP_NEXT:
        return "FORGPREP_NEXT";
    case LiftedOperation::ADD:
        return "ADD";
    case LiftedOperation::SUB:
        return "SUB";
    case LiftedOperation::MUL:
        return "MUL";
    case LiftedOperation::DIV:
        return "DIV";
    case LiftedOperation::IDIV:
        return "IDIV";
    case LiftedOperation::MOD:
        return "MOD";
    case LiftedOperation::POW:
        return "POW";
    case LiftedOperation::ADDK:
        return "ADDK";
    case LiftedOperation::SUBK:
        return "SUBK";
    case LiftedOperation::MULK:
        return "MULK";
    case LiftedOperation::DIVK:
        return "DIVK";
    case LiftedOperation::IDIVK:
        return "IDIVK";
    case LiftedOperation::MODK:
        return "MODK";
    case LiftedOperation::POWK:
        return "POWK";
    case LiftedOperation::SUBRK:
        return "SUBRK";
    case LiftedOperation::DIVRK:
        return "DIVRK";
    case LiftedOperation::AND:
        return "AND";
    case LiftedOperation::OR:
        return "OR";
    case LiftedOperation::ANDK:
        return "ANDK";
    case LiftedOperation::ORK:
        return "ORK";
    case LiftedOperation::CONCAT:
        return "CONCAT";
    case LiftedOperation::NOT:
        return "NOT";
    case LiftedOperation::MINUS:
        return "MINUS";
    case LiftedOperation::LENGTH:
        return "LENGTH";
    case LiftedOperation::JUMPXEQK:
        return "JMPXIFKEQ";
    case LiftedOperation::GETUDATAKS:
        return "GETUDATAKS";
    case LiftedOperation::SETUDATAKS:
        return "SETUDATAKS";
    case LiftedOperation::NAMECALLUDATA:
        return "NAMECALLUDATA";
    case LiftedOperation::NEWCLASSMEMBER:
        return "NEWCLASSMEMBER";
    case LiftedOperation::CALLFB:
        return "CALLFB";
    case LiftedOperation::CMPPROTO:
        return "CMPPROTO";
    case LiftedOperation::NEWCLASS:
        return "NEWCLASS";
    case LiftedOperation::CONDVALUE:
        return "CONDVALUE";
    case LiftedOperation::PHI:
        return "PHI";
    default:
        ASSERT(false, "unhandled operation. No string representation available, so we panic.");
        return "UNKNOWN";
    }
}

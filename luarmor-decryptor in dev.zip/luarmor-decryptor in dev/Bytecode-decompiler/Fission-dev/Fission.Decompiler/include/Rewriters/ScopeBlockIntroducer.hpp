// Scopes non-crossing register-reuse phases in `do ... end` blocks using a linear bottom-up walk.

#pragma once
#include "AbstractSyntaxTree/ASTNode.hpp"
#include "AbstractSyntaxTree/Nodes/CommentNode.hpp"
#include "AbstractSyntaxTree/Traversal.hpp"
#include "FissionAllocator.hpp"
#include "SafetyGuard.hpp"

#include <algorithm>
#include <memory>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

class ScopeBlockIntroducer {
  public:
    void Run(std::vector<std::shared_ptr<Statement>> &statements) {
        std::unordered_set<std::string> sink;
        ProcessList(statements, sink);
    }

  private:
    // Scope each child list before splitting this list at local redefinitions.
    void ProcessList(
        std::vector<std::shared_ptr<Statement>> &stmts, std::unordered_set<std::string> &refsOut, const std::unordered_set<std::string> *liveOut = nullptr,
        std::unordered_set<std::string> *capturesOut = nullptr
    ) {
        const size_t n = stmts.size();
        if (n == 0)
            return;

        std::vector<std::unordered_set<std::string>> refs(n);
        std::vector<std::unordered_set<std::string>> captures(n);
        std::vector<std::string> declName(n);
        bool bailMulti = false;
        for (size_t i = 0; i < n; ++i) {
            Fission::CheckDecompileDeadline();
            bool multi = false;
            declName[i] = DeclaredLocalName(stmts[i], multi);
            if (multi)
                bailMulti = true; // a statement binding >1 local: phase scoping unsupported, leave as-is
            ProcessStatement(stmts[i], refs[i], captures[i]);
            if (capturesOut)
                capturesOut->insert(captures[i].begin(), captures[i].end());
        }
        if (bailMulti) {
            for (auto &r : refs)
                for (const auto &nm : r)
                    refsOut.insert(nm);
            return;
        }

        auto bubble = [&]() {
            for (auto &r : refs)
                for (const auto &nm : r)
                    refsOut.insert(nm);
        };

        // Cut before every redefinition (a `local X` whose name was already declared earlier in this
        // list), pulling the next phase's leading comments along.
        std::vector<size_t> cuts;
        {
            std::unordered_set<std::string> seen;
            size_t segStart = 0;
            for (size_t i = 0; i < n; ++i) {
                if (!declName[i].empty() && seen.count(declName[i]) != 0) {
                    size_t cut = i;
                    while (cut > segStart && std::dynamic_pointer_cast<CommentNode>(stmts[cut - 1]) != nullptr)
                        --cut;
                    if (cut > segStart) {
                        cuts.push_back(cut);
                        segStart = cut;
                    }
                }
                if (!declName[i].empty())
                    seen.insert(declName[i]);
            }
        }
        if (cuts.empty()) {
            bubble();
            return;
        }

        // Per-lifetime last use, keyed by declaration index. A use at i extends the lifetime of the
        // latest declaration of that name at or before i, so a binding is NOT considered live past a
        // later redefinition of the same name (uses after the redefinition belong to the new binding).
        // A declaration's own bound name is excluded from its ref-set by ProcessStatement, so a
        // redefinition whose RHS does not read the old binding does not block its own cut.
        std::unordered_map<std::string, size_t> currentDecl;
        std::vector<size_t> lifeLastUse(n);
        std::vector<size_t> previousDeclaration(n, n);
        for (size_t i = 0; i < n; ++i) {
            for (const auto &nm : refs[i]) {
                auto it = currentDecl.find(nm);
                if (it != currentDecl.end())
                    lifeLastUse[it->second] = i;
            }
            if (!declName[i].empty()) {
                const auto [current, inserted] = currentDecl.try_emplace(declName[i], i);
                if (!inserted) {
                    previousDeclaration[i] = current->second;
                    current->second = i;
                }
            }
        }
        if (liveOut)
            for (const auto &nm : *liveOut)
                if (auto it = currentDecl.find(nm); it != currentDecl.end())
                    lifeLastUse[it->second] = n;

        const auto originalCuts = cuts;
        for (size_t s = 0; s < cuts.size(); ++s) {
            const size_t previous = s == 0 ? 0 : originalCuts[s - 1];
            const size_t next = s + 1 < originalCuts.size() ? originalCuts[s + 1] : n;
            for (size_t i = previous; i < originalCuts[s]; ++i) {
                if (!declName[i].empty() && lifeLastUse[i] >= originalCuts[s] && lifeLastUse[i] < next)
                    cuts[s] = (std::min)(cuts[s], i);
            }
        }
        std::sort(cuts.begin(), cuts.end());
        cuts.erase(std::unique(cuts.begin(), cuts.end()), cuts.end());

        std::vector<size_t> bounds;
        bounds.reserve(cuts.size() + 2);
        bounds.push_back(0);
        for (size_t c : cuts)
            bounds.push_back(c);
        bounds.push_back(n);
        const size_t segCount = bounds.size() - 1;

        // segEndAt[i] = end (exclusive) of the segment containing i.
        std::vector<size_t> segEndAt(n, n);
        for (size_t s = 0; s < segCount; ++s)
            for (size_t i = bounds[s]; i < bounds[s + 1]; ++i)
                segEndAt[i] = bounds[s + 1];

        // crossing[d]: the lifetime declared at d is used at or after its segment's end (a do-block
        // around that segment would scope it away). A lifetime with no use is dead -> non-crossing.
        std::vector<bool> crossing(n, false);
        for (size_t i = 0; i < n; ++i) {
            if (declName[i].empty())
                continue;
            crossing[i] = lifeLastUse[i] >= segEndAt[i];
        }

        for (size_t i = n; i-- > 0;) {
            if (declName[i].empty() || !crossing[i] || previousDeclaration[i] == n || !CanDemoteLocal(stmts[i]))
                continue;
            const bool initializerCapturesPrevious = captures[i].contains(declName[i]) && !std::dynamic_pointer_cast<FunctionDeclarationNode>(stmts[i]);
            const bool previousFunctionCapturesSelf =
                captures[previousDeclaration[i]].contains(declName[i]) && std::dynamic_pointer_cast<FunctionDeclarationNode>(stmts[previousDeclaration[i]]);
            if (initializerCapturesPrevious || previousFunctionCapturesSelf ||
                std::any_of(captures.begin() + previousDeclaration[i] + 1, captures.begin() + i, [&](const auto &names) {
                    return names.contains(declName[i]);
                }))
                continue;
            crossing[previousDeclaration[i]] = true;
            DemoteLocal(stmts[i]);
            declName[i].clear();
            crossing[i] = false;
        }

        std::vector<bool> wrapped(segCount, false);
        for (size_t s = 0; s < segCount; ++s) {
            bool hasLocal = false;
            bool hasCrossing = false;
            for (size_t i = bounds[s]; i < bounds[s + 1]; ++i) {
                hasLocal |= !declName[i].empty();
                hasCrossing |= !declName[i].empty() && crossing[i];
            }
            wrapped[s] = hasLocal && !hasCrossing;
        }

        std::vector<std::shared_ptr<Statement>> rebuilt;
        for (size_t s = 0; s < segCount; ++s) {
            std::vector<std::shared_ptr<Statement>> seg;
            for (size_t i = bounds[s]; i < bounds[s + 1]; ++i)
                seg.push_back(stmts[i]);
            if (seg.empty())
                continue;
            if (wrapped[s]) {
                // keep leading comments (e.g. the function-info block) outside the do-block
                size_t lead = 0;
                while (lead < seg.size() && std::dynamic_pointer_cast<CommentNode>(seg[lead]) != nullptr)
                    ++lead;
                for (size_t k = 0; k < lead; ++k)
                    rebuilt.push_back(seg[k]);
                if (lead < seg.size()) {
                    auto block = Fission::MakeShared<BlockStatementNode>();
                    block->bEmitAsDoBlock = true;
                    block->body.assign(seg.begin() + lead, seg.end());
                    rebuilt.push_back(block);
                }
            } else {
                rebuilt.insert(rebuilt.end(), seg.begin(), seg.end());
            }
        }
        stmts = std::move(rebuilt);

        bubble();
    }

    // Single local name a statement binds as a fresh local (the redefinition trigger), or "".
    // The lifter emits `local` from four node kinds: VariableDeclaration, a local FunctionDeclaration,
    // and a Call / NameCall whose result is bound (rets + bIsLocalDeclaration). Sets `multi` when a
    // statement binds more than one local (or via a non-identifier target); multi-name phase scoping
    // is unsupported, so the caller leaves the whole list untouched.
    static std::string DeclaredLocalName(const std::shared_ptr<Statement> &stmt, bool &multi) {
        multi = false;
        if (auto decl = std::dynamic_pointer_cast<VariableDeclarationNode>(stmt)) {
            if (auto id = std::dynamic_pointer_cast<IdentifierExpressionNode>(decl->identifier); id && id->identifier)
                return id->identifier->name;
            return "";
        }
        if (auto fn = std::dynamic_pointer_cast<FunctionDeclarationNode>(stmt); fn && fn->bIsLocalDeclaration && !fn->bAnonymousInline)
            return fn->functionName;
        // call-result local, e.g. `local v = o:m()`; usually an ExpressionStatement wrapping the call.
        if (auto inner = LocalDeclCall(stmt)) {
            if (auto c = std::dynamic_pointer_cast<CallExpressionNode>(inner))
                return SingleRetName(c->rets, multi);
            if (auto nc = std::dynamic_pointer_cast<NameCallExpressionNode>(inner))
                return SingleRetName(nc->rets, multi);
        }
        return "";
    }

    static bool CanDemoteLocal(const std::shared_ptr<Statement> &stmt) {
        if (auto declaration = std::dynamic_pointer_cast<VariableDeclarationNode>(stmt))
            return declaration->value != nullptr;
        if (auto fn = std::dynamic_pointer_cast<FunctionDeclarationNode>(stmt))
            return fn->bIsLocalDeclaration && !fn->bAnonymousInline;
        return LocalDeclCall(stmt) != nullptr;
    }

    static void DemoteLocal(std::shared_ptr<Statement> &stmt) {
        if (auto declaration = std::dynamic_pointer_cast<VariableDeclarationNode>(stmt)) {
            stmt = Fission::MakeShared<AssignmentStatementNode>(declaration->identifier, declaration->value);
            return;
        }
        if (auto fn = std::dynamic_pointer_cast<FunctionDeclarationNode>(stmt)) {
            fn->bIsLocalDeclaration = false;
            return;
        }
        if (auto call = std::dynamic_pointer_cast<CallExpressionNode>(LocalDeclCall(stmt)))
            call->bIsLocalDeclaration = false;
        else if (auto nameCall = std::dynamic_pointer_cast<NameCallExpressionNode>(LocalDeclCall(stmt)))
            nameCall->bIsLocalDeclaration = false;
    }

    // The underlying Call/NameCall of a call-result local declaration (`local rets = f()`), whether it
    // sits directly in the list or inside an ExpressionStatement; nullptr if the statement is not one.
    static std::shared_ptr<Expression> LocalDeclCall(const std::shared_ptr<Statement> &stmt) {
        std::shared_ptr<Expression> e;
        if (auto es = std::dynamic_pointer_cast<ExpressionStatementNode>(stmt))
            e = es->expression;
        else
            e = std::dynamic_pointer_cast<Expression>(stmt);
        if (auto c = std::dynamic_pointer_cast<CallExpressionNode>(e); c && c->bIsLocalDeclaration && !c->rets.empty())
            return c;
        if (auto nc = std::dynamic_pointer_cast<NameCallExpressionNode>(e); nc && nc->bIsLocalDeclaration && !nc->rets.empty())
            return nc;
        return nullptr;
    }

    static std::string SingleRetName(const std::vector<std::shared_ptr<Expression>> &rets, bool &multi) {
        if (rets.size() != 1) {
            multi = true; // `local a, b = f()`; unsupported
            return "";
        }
        auto id = std::dynamic_pointer_cast<IdentifierExpressionNode>(rets[0]);
        if (!id || !id->identifier) {
            multi = true; // non-identifier bind target; bail conservatively
            return "";
        }
        return id->identifier->name;
    }

    // Collect the names a statement REFERENCES (uses/writes), recursing into nested blocks and inline
    // closures (which are scoped in passing). A declaration's own bound name is excluded so it does
    // not count as a use of itself.
    void ProcessStatement(const std::shared_ptr<Statement> &stmt, std::unordered_set<std::string> &refs, std::unordered_set<std::string> &captures) {
        if (!stmt)
            return;
        if (auto decl = std::dynamic_pointer_cast<VariableDeclarationNode>(stmt)) {
            ScanExpr(decl->value, refs, captures); // RHS only; the bound LHS name is the declaration, not a use
            return;
        }
        if (auto fn = std::dynamic_pointer_cast<FunctionDeclarationNode>(stmt)) {
            captures.insert(fn->capturedNames.begin(), fn->capturedNames.end());
            if (fn->lpFunctionBody)
                ProcessList(fn->lpFunctionBody->body, refs);
            return;
        }
        if (auto es = std::dynamic_pointer_cast<ExpressionStatementNode>(stmt)) {
            ScanCallOrExpr(es->expression, refs, captures);
            return;
        }
        if (std::dynamic_pointer_cast<CallExpressionNode>(stmt) || std::dynamic_pointer_cast<NameCallExpressionNode>(stmt)) {
            ScanCallOrExpr(std::dynamic_pointer_cast<Expression>(stmt), refs, captures);
            return;
        }
        if (auto expr = std::dynamic_pointer_cast<Expression>(stmt)) {
            ScanExpr(expr, refs, captures);
            return;
        }
        // an assignment's bare-identifier LHS write to a scoped-away local is unsafe, so targets count as uses
        const auto repeat = std::dynamic_pointer_cast<RepeatStatementNode>(stmt);
        std::unordered_set<std::string> conditionRefs;
        ForEachStatementExpression(stmt, [&](const std::shared_ptr<Expression> &e) { ScanExpr(e, repeat ? conditionRefs : refs, captures); });
        refs.insert(conditionRefs.begin(), conditionRefs.end());
        ForEachChildBlock(stmt, [&](std::vector<std::shared_ptr<Statement>> &body) { ProcessList(body, refs, repeat ? &conditionRefs : nullptr, &captures); });
    }

    // Scan a call used as a statement: callee/args are uses; rets are uses only when the call is NOT
    // a local declaration (a local decl's rets are the bound names). Falls back to a plain expression
    // scan when `e` is not a call.
    void ScanCallOrExpr(const std::shared_ptr<Expression> &e, std::unordered_set<std::string> &refs, std::unordered_set<std::string> &captures) {
        if (auto c = std::dynamic_pointer_cast<CallExpressionNode>(e)) {
            ScanExpr(c->callee, refs, captures);
            for (const auto &a : c->arguments)
                ScanExpr(a, refs, captures);
            if (!c->bIsLocalDeclaration)
                for (const auto &r : c->rets)
                    ScanExpr(r, refs, captures);
            return;
        }
        if (auto nc = std::dynamic_pointer_cast<NameCallExpressionNode>(e)) {
            ScanExpr(nc->calledOn, refs, captures);
            for (const auto &a : nc->arguments)
                ScanExpr(a, refs, captures);
            if (!nc->bIsLocalDeclaration)
                for (const auto &r : nc->rets)
                    ScanExpr(r, refs, captures);
            return;
        }
        ScanExpr(e, refs, captures);
    }

    void ScanExpr(const std::shared_ptr<Expression> &expr, std::unordered_set<std::string> &refs, std::unordered_set<std::string> &captures) {
        if (!expr)
            return;
        if (expr->nodeKind == ASTNodeKind::IdentifierExpression) {
            const auto id = std::static_pointer_cast<IdentifierExpressionNode>(expr);
            if (id->identifier)
                refs.insert(id->identifier->name);
            return;
        }
        if (expr->nodeKind == ASTNodeKind::FunctionDeclarationNode) {
            const auto fn = std::static_pointer_cast<FunctionDeclarationNode>(expr);
            captures.insert(fn->capturedNames.begin(), fn->capturedNames.end());
            if (fn->lpFunctionBody)
                ProcessList(fn->lpFunctionBody->body, refs); // scope inside inline closures too
            return;
        }
        ForEachSubExpression(expr, [&](const std::shared_ptr<Expression> &child) { ScanExpr(child, refs, captures); });
    }
};

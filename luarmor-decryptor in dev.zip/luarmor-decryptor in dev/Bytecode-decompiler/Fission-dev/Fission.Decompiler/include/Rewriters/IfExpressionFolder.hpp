// Folds pure branch assignments to one target into a Luau if-expression.

#pragma once
#include "AbstractSyntaxTree/ASTNode.hpp"
#include "AbstractSyntaxTree/Traversal.hpp"
#include "FissionAllocator.hpp"
#include "Rewriters/ScopeAwareRenamer.hpp"
#include "SafetyGuard.hpp"

#include <algorithm>
#include <memory>
#include <string>
#include <unordered_set>
#include <vector>

class IfExpressionFolder {
  public:
    void Run(std::vector<std::shared_ptr<Statement>> &statements) { FoldFunction(statements); }

  private:
    static std::shared_ptr<Expression> Negate(const std::shared_ptr<Expression> &condition) {
        if (const auto inverse = std::dynamic_pointer_cast<UnaryExpressionNode>(condition); inverse && inverse->op == "not ")
            return inverse->operand;
        if (const auto compare = std::dynamic_pointer_cast<BinaryExpressionNode>(condition); compare && (compare->op == "==" || compare->op == "~="))
            return Fission::MakeShared<BinaryExpressionNode>(compare->op == "==" ? "~=" : "==", compare->left, compare->right);
        return Fission::MakeShared<UnaryExpressionNode>("not ", condition);
    }

    static bool EndsInBareReturn(const std::shared_ptr<BlockStatementNode> &arm) {
        const auto ret = arm && !arm->body.empty() ? std::dynamic_pointer_cast<ReturnStatementNode>(arm->body.back()) : nullptr;
        return ret && ret->returnValues.empty();
    }

    // Luau copies the function's closing `return` into the arms of its last if; falling off the end says the same.
    static void DropTailReturns(std::vector<std::shared_ptr<Statement>> &body) {
        const auto branch = body.empty() ? nullptr : std::dynamic_pointer_cast<IfStatementNode>(body.back());
        if (!branch)
            return;
        if (branch->elseBranch && branch->elseBranch->body.size() == 1 && EndsInBareReturn(branch->elseBranch))
            branch->elseBranch.reset();
        if (branch->elseBranch && branch->thenBranch && branch->thenBranch->body.size() == 1 && EndsInBareReturn(branch->thenBranch)) {
            branch->condition = Negate(branch->condition);
            branch->thenBranch = std::move(branch->elseBranch);
        }
        for (const auto &arm : {branch->thenBranch, branch->elseBranch}) {
            if (!arm)
                continue;
            if (arm->body.size() > 1 && EndsInBareReturn(arm))
                arm->body.pop_back();
            DropTailReturns(arm->body);
        }
    }

    // `if a then A; return end; if b then B else C end` closing a function is one chain: `if a then A elseif b ...`
    static void MergeTailGuards(std::vector<std::shared_ptr<Statement>> &body) {
        while (body.size() >= 2) {
            const auto chain = std::dynamic_pointer_cast<IfStatementNode>(body.back());
            const auto guard = std::dynamic_pointer_cast<IfStatementNode>(body[body.size() - 2]);
            if (!chain || !guard || guard->elseBranch || !guard->thenBranch || guard->thenBranch->body.size() < 2 || !EndsInBareReturn(guard->thenBranch))
                return;
            guard->thenBranch->body.pop_back();
            guard->elseBranch = Fission::MakeShared<BlockStatementNode>();
            guard->elseBranch->body.push_back(chain);
            body.pop_back();
        }
    }

    void FoldFunction(std::vector<std::shared_ptr<Statement>> &body) {
        Fold(body);
        if (!body.empty())
            if (auto ret = std::dynamic_pointer_cast<ReturnStatementNode>(body.back()); ret && ret->returnValues.empty())
                body.pop_back();
        DropTailReturns(body);
        MergeTailGuards(body);
        for (size_t i = body.size(); i > 0; --i) {
            auto guard = std::dynamic_pointer_cast<IfStatementNode>(body[i - 1]);
            if (!guard || guard->elseBranch || !guard->thenBranch || guard->thenBranch->body.size() != 1 || i + 1 != body.size() ||
                !std::dynamic_pointer_cast<ExpressionStatementNode>(body.back()))
                continue;
            auto ret = std::dynamic_pointer_cast<ReturnStatementNode>(guard->thenBranch->body.front());
            if (!ret || !ret->returnValues.empty())
                continue;
            if (auto inverse = std::dynamic_pointer_cast<UnaryExpressionNode>(guard->condition); inverse && inverse->op == "not ")
                guard->condition = inverse->operand;
            else
                guard->condition = Fission::MakeShared<UnaryExpressionNode>("not ", guard->condition);
            guard->thenBranch->body.assign(body.begin() + static_cast<std::ptrdiff_t>(i), body.end());
            body.erase(body.begin() + static_cast<std::ptrdiff_t>(i), body.end());
            break;
        }
    }

    // `<ident> = <expr>` -> capture name + value.
    static bool AsSimpleAssign(const std::shared_ptr<Statement> &s, std::string &name, std::shared_ptr<Expression> &value) {
        auto asn = std::dynamic_pointer_cast<AssignmentStatementNode>(s);
        if (!asn)
            return false;
        auto id = std::dynamic_pointer_cast<IdentifierExpressionNode>(asn->left);
        if (!id || !id->identifier)
            return false;
        name = id->identifier->name;
        value = asn->right;
        return true;
    }

    static bool Calls(const std::shared_ptr<Expression> &expr) {
        if (!expr)
            return false;
        if (std::dynamic_pointer_cast<CallExpressionNode>(expr) || std::dynamic_pointer_cast<NameCallExpressionNode>(expr))
            return true;
        if (auto bin = std::dynamic_pointer_cast<BinaryExpressionNode>(expr))
            return Calls(bin->left) || Calls(bin->right);
        if (auto un = std::dynamic_pointer_cast<UnaryExpressionNode>(expr))
            return Calls(un->operand);
        if (auto index = std::dynamic_pointer_cast<IndexExpressionNode>(expr))
            return Calls(index->left) || Calls(index->right);
        if (auto member = std::dynamic_pointer_cast<MemberExpressionNode>(expr))
            return Calls(member->table) || Calls(member->key);
        if (auto table = AsLiteral<TableLiteralNode>(expr))
            return std::ranges::any_of(table->expressions, [](const auto &value) { return Calls(value); });
        if (auto iff = std::dynamic_pointer_cast<IfExpressionNode>(expr))
            return Calls(iff->condition) || Calls(iff->thenExpr) || Calls(iff->elseExpr);
        return false;
    }

    static std::shared_ptr<Statement> OnlyStmt(const std::shared_ptr<BlockStatementNode> &b) {
        if (!b || b->body.size() != 1)
            return nullptr;
        return b->body[0];
    }

    // If `ifStmt` is a pure diamond that assigns a single target in every arm (the else arm may be a
    // nested diamond -> `elseif`), return the folded IfExpression and set `name`; else nullptr.
    std::shared_ptr<IfExpressionNode> AsIfExpr(const std::shared_ptr<IfStatementNode> &ifStmt, std::string &name) {
        if (!ifStmt || !ifStmt->condition || !ifStmt->thenBranch || !ifStmt->elseBranch)
            return nullptr;
        std::string tn;
        std::shared_ptr<Expression> tv;
        auto thenOnly = OnlyStmt(ifStmt->thenBranch);
        if (!thenOnly || !AsSimpleAssign(thenOnly, tn, tv))
            return nullptr;

        std::shared_ptr<Expression> elseExpr;
        auto elseOnly = OnlyStmt(ifStmt->elseBranch);
        std::string en;
        std::shared_ptr<Expression> ev;
        if (elseOnly && AsSimpleAssign(elseOnly, en, ev)) {
            if (en != tn)
                return nullptr;
            elseExpr = ev;
        } else if (auto nestedIf = std::dynamic_pointer_cast<IfStatementNode>(elseOnly)) {
            std::string nn;
            auto nested = AsIfExpr(nestedIf, nn);
            if (!nested || nn != tn)
                return nullptr;
            elseExpr = nested;
        } else {
            return nullptr;
        }

        name = tn;
        if (auto inverse = std::dynamic_pointer_cast<UnaryExpressionNode>(ifStmt->condition);
            inverse && inverse->op == "not " && !std::dynamic_pointer_cast<IfExpressionNode>(elseExpr))
            return Fission::MakeShared<IfExpressionNode>(inverse->operand, elseExpr, tv);
        return Fission::MakeShared<IfExpressionNode>(ifStmt->condition, tv, elseExpr);
    }

    static bool SameOperand(const std::shared_ptr<Expression> &a, const std::shared_ptr<Expression> &b) {
        const auto ia = std::dynamic_pointer_cast<IdentifierExpressionNode>(a);
        const auto ib = std::dynamic_pointer_cast<IdentifierExpressionNode>(b);
        return ia && ib && ia->identifier && ib->identifier && ia->identifier->name == ib->identifier->name;
    }

    static std::shared_ptr<BinaryExpressionNode> AsLogical(const std::shared_ptr<Expression> &expr, const char *op) {
        const auto binary = std::dynamic_pointer_cast<BinaryExpressionNode>(expr);
        return binary && binary->op == op ? binary : nullptr;
    }

    // Exact rewrites; each operand is still read at most once per path:
    // `if c then x or y else y` == `c and x or y`, `if c then y else x and y` == `(c or x) and y`.
    static std::shared_ptr<Expression> Simplify(const std::shared_ptr<Expression> &expr) {
        const auto iff = std::dynamic_pointer_cast<IfExpressionNode>(expr);
        if (!iff)
            return expr;
        const auto thenExpr = Simplify(iff->thenExpr);
        const auto elseExpr = Simplify(iff->elseExpr);
        if (const auto either = AsLogical(thenExpr, "or"); either && SameOperand(either->right, elseExpr))
            return Fission::MakeShared<BinaryExpressionNode>("or", Fission::MakeShared<BinaryExpressionNode>("and", iff->condition, either->left), elseExpr);
        if (const auto both = AsLogical(elseExpr, "and"); both && SameOperand(both->right, thenExpr))
            return Fission::MakeShared<BinaryExpressionNode>("and", Fission::MakeShared<BinaryExpressionNode>("or", iff->condition, both->left), thenExpr);
        return Fission::MakeShared<IfExpressionNode>(iff->condition, thenExpr, elseExpr);
    }

    // `local v = <value expression>; return v` closing a block returns the expression directly.
    static void InlineReturnedValue(std::vector<std::shared_ptr<Statement>> &stmts) {
        if (stmts.size() < 2)
            return;
        const auto ret = std::dynamic_pointer_cast<ReturnStatementNode>(stmts.back());
        const auto decl = std::dynamic_pointer_cast<VariableDeclarationNode>(stmts[stmts.size() - 2]);
        if (!ret || ret->returnValues.size() != 1 || !decl || !decl->value || !SameOperand(decl->identifier, ret->returnValues.front()))
            return;
        if (!std::dynamic_pointer_cast<IfExpressionNode>(decl->value) && !AsLogical(decl->value, "and") && !AsLogical(decl->value, "or"))
            return;
        ret->returnValues.front() = decl->value;
        stmts.erase(stmts.end() - 2);
    }

    static void FoldBooleanOrValue(std::vector<std::shared_ptr<Statement>> &stmts) {
        for (size_t i = 0; i + 2 < stmts.size(); ++i) {
            const auto decl = std::dynamic_pointer_cast<VariableDeclarationNode>(stmts[i]);
            const auto temp = decl ? std::dynamic_pointer_cast<IdentifierExpressionNode>(decl->identifier) : nullptr;
            const auto initial = decl ? AsLiteral<BooleanLiteralNode>(decl->value) : nullptr;
            const auto guard = std::dynamic_pointer_cast<IfStatementNode>(stmts[i + 1]);
            const auto negated = guard ? std::dynamic_pointer_cast<UnaryExpressionNode>(guard->condition) : nullptr;
            const auto first = negated ? std::dynamic_pointer_cast<BinaryExpressionNode>(negated->operand) : nullptr;
            if (!temp || !temp->identifier || temp->identifier->bIsGlobal || !initial || !initial->value || decl->type || !guard || guard->elseBranch ||
                !guard->thenBranch || guard->thenBranch->body.size() != 1 || !negated || negated->op != "not " || !first ||
                (first->op != "==" && first->op != "~=" && first->op != "<" && first->op != "<=" && first->op != ">" && first->op != ">="))
                continue;

            std::string branchName, destinationName;
            std::shared_ptr<Expression> branchValue, destinationValue;
            if (!AsSimpleAssign(guard->thenBranch->body.front(), branchName, branchValue) || branchName != temp->identifier->name ||
                !AsSimpleAssign(stmts[i + 2], destinationName, destinationValue) || destinationName == branchName ||
                !SameOperand(decl->identifier, destinationValue))
                continue;
            const auto choice = std::dynamic_pointer_cast<IfExpressionNode>(branchValue);
            const auto yes = choice ? AsLiteral<BooleanLiteralNode>(choice->thenExpr) : nullptr;
            const auto no = choice ? AsLiteral<BooleanLiteralNode>(choice->elseExpr) : nullptr;
            const auto second = choice ? std::dynamic_pointer_cast<BinaryExpressionNode>(choice->condition) : nullptr;
            if (!yes || !no || yes->value == no->value || !second || (second->op != "==" && second->op != "~="))
                continue;
            std::unordered_set<std::string> names;
            ScopeAwareRenamer::CollectIdentifierNames(Fission::MakeShared<ExpressionStatementNode>(first), names);
            ScopeAwareRenamer::CollectIdentifierNames(Fission::MakeShared<ExpressionStatementNode>(second), names);
            for (size_t j = i + 3; j < stmts.size(); ++j)
                ScopeAwareRenamer::CollectIdentifierNames(stmts[j], names);
            if (names.contains(branchName))
                continue;
            auto destination = std::static_pointer_cast<AssignmentStatementNode>(stmts[i + 2]);
            destination->right = Fission::MakeShared<BinaryExpressionNode>("or", first, yes->value ? second : Negate(second));
            stmts.erase(stmts.begin() + static_cast<std::ptrdiff_t>(i), stmts.begin() + static_cast<std::ptrdiff_t>(i + 2));
        }
    }

    void Fold(std::vector<std::shared_ptr<Statement>> &stmts) {
        // Fold at THIS level first (top-down): AsIfExpr must see the raw nested `if` in an else arm to
        // build the `elseif` chain; recursing first would rewrite it out from under the detection.
        FoldLevel(stmts);
        // Folded nodes have no remaining block children.
        for (auto &s : stmts)
            FoldChildren(s);
        // Arms that just folded can complete an enclosing diamond.
        FoldLevel(stmts);
        InlineReturnedValue(stmts);
        FoldBooleanOrValue(stmts);
    }

    void FoldLevel(std::vector<std::shared_ptr<Statement>> &stmts) {
        for (size_t i = 0; i < stmts.size(); ++i) {
            Fission::CheckDecompileDeadline();
            auto ifStmt = std::dynamic_pointer_cast<IfStatementNode>(stmts[i]);
            if (!ifStmt)
                continue;
            std::string name;
            auto ifExpr = Simplify(AsIfExpr(ifStmt, name));
            if (!ifExpr)
                continue;

            // Merge with an immediately-preceding bare `local <name>` -> `local <name> = <ifexpr>`.
            if (i > 0) {
                if (auto decl = std::dynamic_pointer_cast<VariableDeclarationNode>(stmts[i - 1]); decl && !decl->value) {
                    if (auto did = std::dynamic_pointer_cast<IdentifierExpressionNode>(decl->identifier);
                        did && did->identifier && did->identifier->name == name) {
                        std::unordered_set<std::string> names;
                        ScopeAwareRenamer::CollectIdentifierNames(Fission::MakeShared<ExpressionStatementNode>(ifExpr), names);
                        const bool shadowsEarlierBinding =
                            names.contains(name) && std::any_of(stmts.begin(), stmts.begin() + static_cast<std::ptrdiff_t>(i - 1), [&](const auto &statement) {
                                auto earlier = std::dynamic_pointer_cast<VariableDeclarationNode>(statement);
                                auto id = earlier ? std::dynamic_pointer_cast<IdentifierExpressionNode>(earlier->identifier) : nullptr;
                                return id && id->identifier && id->identifier->name == name;
                            });
                        if (!names.contains(name) || shadowsEarlierBinding) {
                            stmts[i - 1] = Fission::MakeShared<VariableDeclarationNode>(decl->identifier, ifExpr);
                            stmts.erase(stmts.begin() + static_cast<std::ptrdiff_t>(i));
                            --i;
                            continue;
                        }
                    }
                }
            }
            // Standalone diamond -> `<name> = <ifexpr>` (a reassignment expressed as an if-expression); arms that call
            // stay statements, as a chain assigning an existing local reads.
            if (Calls(ifExpr))
                continue;
            auto lhs = Fission::MakeShared<IdentifierExpressionNode>(Fission::MakeShared<Identifier>(name));
            stmts[i] = Fission::MakeShared<AssignmentStatementNode>(lhs, ifExpr);
        }
    }

    void FoldChildren(const std::shared_ptr<Statement> &s) {
        if (auto fdn = std::dynamic_pointer_cast<FunctionDeclarationNode>(s)) {
            if (fdn->lpFunctionBody)
                FoldFunction(fdn->lpFunctionBody->body);
            return;
        }
        ForEachStatementExpression(s, [&](const std::shared_ptr<Expression> &expr) { FoldExpression(expr); });
        ForEachChildBlock(s, [&](std::vector<std::shared_ptr<Statement>> &body) { Fold(body); });
    }

    void FoldExpression(const std::shared_ptr<Expression> &expr) {
        if (!expr)
            return;
        if (auto fn = std::dynamic_pointer_cast<FunctionDeclarationNode>(expr); fn && fn->lpFunctionBody)
            FoldFunction(fn->lpFunctionBody->body);
        else
            ForEachSubExpression(expr, [&](const std::shared_ptr<Expression> &child) { FoldExpression(child); });
    }
};

#pragma once

#include "InstructionDecoder.hpp"

#include <cstddef>
#include <libassert/assert.hpp>
#include <optional>
#include <vector>

struct DeserializedFunction;
struct DeserializedBytecode;

enum class LiftedOperation : uint32_t {
    NOP,
    BREAK,
    LOAD,
    LOADNJUMP,
    MOVE,
    GETGLOBAL,
    SETGLOBAL,
    GETUPVAL,
    SETUPVAL,
    GETIMPORT,
    GETTABLE,
    SETTABLE,
    GETTABLEKS,
    SETTABLEKS,
    GETTABLEN,
    SETTABLEN,
    NEWCLOSURE,
    NAMECALL,
    CALL,
    RETURN,
    JUMP,
    JUMPIF,
    JUMPIFNOT,
    JUMPIFEQ,
    JUMPIFLE,
    JUMPIFLT,
    JUMPIFNOTEQ,
    JUMPIFNOTLE,
    JUMPIFNOTLT,
    ADD,
    SUB,
    MUL,
    DIV,
    MOD,
    POW,
    ADDK,
    SUBK,
    MULK,
    DIVK,
    MODK,
    POWK,
    AND,
    OR,
    ANDK,
    ORK,
    CONCAT,
    NOT,
    MINUS,
    LENGTH,
    NEWTABLE,
    DUPTABLE,
    SETLIST,
    FORNPREP,
    FORNLOOP,
    FORGLOOP,
    FORGPREP_INEXT,
    FORGPREP_NEXT,
    FASTCALL3,
    GETVARARGS,
    DUPCLOSURE,
    PREPVARARGS,
    FASTCALL,
    FASTPCALL,
    CAPTURE,
    SUBRK,
    DIVRK,
    FASTCALL1,
    FASTCALL2,
    FASTCALL2K,
    FORGPREP,
    JUMPXEQK,
    IDIV,
    IDIVK,

    GETUDATAKS,
    SETUDATAKS,
    NAMECALLUDATA,
    NEWCLASSMEMBER,
    CALLFB,
    CMPPROTO,
    NEWCLASS,

    // a branch whose arms only load true/false: dest, the branch's operands, the branch operation, the value when it jumps
    CONDVALUE,

    PHI // phi node on SSA.
};

enum class LiftedOperandType : uint8_t { Register, ImmediateNil, ImmediateInteger, ImmediateBool, ImmediateConstant, ImmediateAux };

struct LiftedOperand {
    LiftedOperandType type;

    union {
        uint8_t reg;

        union {
            int32_t n;
            bool b;
            int32_t k;
            uint32_t u;
        } imm;
    } value;

    int32_t ssaVersion = -1;
};

struct LiftedInstruction {
    LiftedOperation operation;
    int32_t instructionIndex;
    std::vector<LiftedOperand> operands{};
    std::optional<std::string> instructionRemarks = std::nullopt;
};

struct LiftedFunction {
    std::vector<LiftedInstruction> instructions;
    std::vector<LiftedFunction> subfunctions;
    std::string name;
    uint8_t numparams;
    DeserializedFunction *lpDeserialized;
    // CLOSEUPVALS lifts to NOP; (instruction index, lowest closed register) marks where captured locals end
    std::vector<std::pair<int32_t, uint8_t>> upvalueCloses{};
    // per instruction: the InlineSourceMap source whose body the compiler inlined there, or -1
    std::vector<int32_t> inlineOrigin{};
    // per instruction: index into recoveredCalls of the call rebuilt from an inlined body, or -1
    std::vector<int32_t> recoveredCallAt{};
    // InlineSourceMap source of each rebuilt call
    std::vector<int32_t> recoveredCalls{};
};

class BytecodeLifter {
    // lifts one function's own instructions; subfunctions are attached by LiftDeserializedBytecode.
    LiftedFunction LiftFunctionBytecodeInternal(const DeserializedFunction *function, bool bIsMain = false);

    // AUX words are raw instruction slots without an opcode of their own: they are read as operands and
    // padded with a NOP in the lifted stream. Every read is bounds-checked so a truncated function is
    // rejected as malformed instead of throwing std::out_of_range.
    static uint32_t ReadAuxWord(const DeserializedFunction *function, size_t instructionIndex);

    Fission::InstructionDecoder *lpDecoder = nullptr;

  public:
    BytecodeLifter(Fission::InstructionDecoder *decoder) {
        lpDecoder = decoder;
        ASSERT(lpDecoder != nullptr, "Instruction decoder cannot be nullptr", lpDecoder);
    }

    LiftedFunction LiftDeserializedBytecode(const DeserializedBytecode &bytecode);
};

std::string_view OperationToString(LiftedOperation operation);

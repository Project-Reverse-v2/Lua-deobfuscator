// Compare normalized execution traces from original and decompiled bytecode in a sandboxed Luau VM.
#pragma once

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <functional>
#include <optional>
#include <ranges>
#include <regex>
#include <set>
#include <string>
#include <vector>

#include "lua.h"
#include "lualib.h"

namespace fuzz {

    struct SemTrace {
        enum class Status { Ok, Error, Timeout, LoadFailed };
        Status status = Status::LoadFailed;
        std::string trace;
        bool comparable = true;
        std::vector<std::optional<std::string>> prints;
        std::optional<std::string> error;
    };

    namespace detail {
        struct RunBudget {
            std::chrono::steady_clock::time_point deadline;
            bool expired = false;
            bool comparable = true;
            std::set<const void *> seenObjects;
            std::vector<std::optional<std::string>> prints;
        };

        // interrupt fires on VM back-edges/calls; only raise outside a GC step (gc < 0).
        inline void InterruptHook(lua_State *L, int gc) {
            if (gc >= 0)
                return;
            auto *budget = static_cast<RunBudget *>(lua_callbacks(L)->userdata);
            if (budget && std::chrono::steady_clock::now() > budget->deadline) {
                budget->expired = true;
                luaL_errorL(L, "FUZZ_TIMEOUT"); // not the luaL_error macro: ##__VA_ARGS__ trips -Werror=gnu-zero-variadic-macro-arguments
            }
        }

        inline void SerializeString(const char *s, size_t len, std::string &out) {
            constexpr char hex[] = "0123456789abcdef";
            out += '"';
            for (size_t i = 0; i < len; ++i) {
                const auto ch = static_cast<unsigned char>(s[i]);
                if (ch == '"' || ch == '\\') {
                    out += '\\';
                    out += static_cast<char>(ch);
                } else if (ch < 32 || ch >= 127) {
                    out += "\\x";
                    out += hex[ch >> 4];
                    out += hex[ch & 15];
                } else {
                    out += static_cast<char>(ch);
                }
            }
            out += '"';
        }

        inline void MarkIncomparable(lua_State *L) {
            auto *budget = static_cast<RunBudget *>(lua_callbacks(L)->userdata);
            if (budget)
                budget->comparable = false;
        }

        inline void SerializeValue(lua_State *L, int idx, std::string &out, int depth, std::set<const void *> &visited) {
            idx = lua_absindex(L, idx);
            switch (lua_type(L, idx)) {
            case LUA_TNIL:
                out += "nil";
                break;
            case LUA_TBOOLEAN:
                out += lua_toboolean(L, idx) ? "true" : "false";
                break;
            case LUA_TNUMBER: {
                char buf[40];
                std::snprintf(buf, sizeof(buf), "%.17g", lua_tonumber(L, idx));
                out += buf;
                break;
            }
            case LUA_TSTRING: {
                size_t len = 0;
                const char *s = lua_tolstring(L, idx, &len);
                SerializeString(s, len, out);
                break;
            }
            case LUA_TINTEGER:
                out += "i64(" + std::to_string(lua_tointeger64(L, idx, nullptr)) + ')';
                break;
            case LUA_TBUFFER: {
                auto *budget = static_cast<RunBudget *>(lua_callbacks(L)->userdata);
                if (budget && !budget->seenObjects.insert(lua_topointer(L, idx)).second)
                    MarkIncomparable(L);
                size_t len = 0;
                const auto *data = static_cast<const char *>(lua_tobuffer(L, idx, &len));
                out += "buffer:";
                SerializeString(data, len, out);
                break;
            }
            case LUA_TVECTOR: {
                const float *v = lua_tovector(L, idx);
                char buf[64];
                std::snprintf(buf, sizeof(buf), "vec(%.9g,%.9g,%.9g)", v[0], v[1], v[2]);
                out += buf;
                break;
            }
            case LUA_TTABLE: {
                const void *ptr = lua_topointer(L, idx);
                auto *budget = static_cast<RunBudget *>(lua_callbacks(L)->userdata);
                if (budget && !budget->seenObjects.insert(ptr).second)
                    MarkIncomparable(L);
                if (lua_getmetatable(L, idx)) {
                    MarkIncomparable(L);
                    lua_pop(L, 1);
                }
                if (depth <= 0 || visited.count(ptr)) {
                    MarkIncomparable(L);
                    out += depth <= 0 ? "{...}" : "{cycle}";
                    break;
                }
                visited.insert(ptr);
                out += '{';
                std::vector<std::string> entries;
                lua_pushnil(L);
                while (lua_next(L, idx) != 0) {
                    std::string e;
                    SerializeValue(L, -2, e, 1, visited);
                    e += '=';
                    SerializeValue(L, -1, e, depth - 1, visited);
                    entries.push_back(std::move(e));
                    lua_pop(L, 1);
                }
                std::sort(entries.begin(), entries.end());
                for (const auto &e : entries) {
                    if (out.back() != '{')
                        out += ',';
                    out += e;
                }
                out += '}';
                visited.erase(ptr);
                break;
            }
            default:
                MarkIncomparable(L);
                out += '<';
                out += lua_typename(L, lua_type(L, idx));
                out += '>';
                break;
            }
        }

        // print override: serialize every arg deterministically, tab-separated, into the trace buffer
        // stashed in an upvalue-held lightuserdata.
        inline int TracePrint(lua_State *L) {
            auto *trace = static_cast<std::string *>(lua_tolightuserdata(L, lua_upvalueindex(1)));
            auto *budget = static_cast<RunBudget *>(lua_callbacks(L)->userdata);
            if (trace->size() > (1u << 22)) {
                budget->deadline = {};
                budget->expired = true;
                luaL_errorL(L, "FUZZ_TIMEOUT");
            }
            const bool earlierComparable = budget->comparable;
            budget->comparable = true;
            const size_t start = trace->size();
            const int argc = lua_gettop(L);
            std::set<const void *> visited;
            for (int i = 1; i <= argc; ++i) {
                if (i > 1)
                    *trace += '\t';
                SerializeValue(L, i, *trace, 4, visited);
            }
            *trace += '\n';
            budget->prints.push_back(budget->comparable ? std::optional(trace->substr(start)) : std::nullopt);
            budget->comparable &= earlierComparable;
            return 0;
        }

        inline int SetPrimitiveMetatable(lua_State *L) {
            luaL_checktype(L, 1, LUA_TTABLE);
            const auto apply = [&] {
                lua_pushvalue(L, 1);
                lua_setmetatable(L, -2);
                lua_pop(L, 1);
            };
            lua_pushnil(L);
            apply();
            lua_pushboolean(L, false);
            apply();
            lua_pushnumber(L, 0);
            apply();
            lua_pushinteger64(L, 0);
            apply();
            lua_pushcfunction(L, SetPrimitiveMetatable, nullptr);
            apply();
            return 0;
        }

        inline std::string NormalizeAddresses(const std::string &text) {
            static const std::regex addressRe(R"((table|function|userdata|thread): 0x[0-9a-fA-F]+)");
            return std::regex_replace(text, addressRe, "$1: <address>");
        }

        // strip "[string \"...\"]:<line>:" location prefixes: original and decompiled sources have
        // different line numbers for the same semantic error.
        inline std::string NormalizeError(const std::string &msg) {
            static const std::regex locRe(R"((\[string \"[^\"]*\"\]|\bchunk):\d+:?\s*)");
            return NormalizeAddresses(std::regex_replace(msg, locRe, ""));
        }
    } // namespace detail

    // Fixture preludes. A single environment only exercises one path per program; running under
    // several; plain data, an instrumented callable object, and hostile scalars; flips branches,
    // reaches method bodies, and makes effect ORDER observable (every metamethod hit prints a
    // marker). A faithful decompilation must trace-match under every fixture.
    inline const char *kSemPreludes[] = {
        // P0: plain tables (baseline; matches the original single-fixture oracle).
        "t = { 1, 2, 3, key = 'value', x = 5 }\n"
        "obj = { x = 1, y = 'hello', items = { 4, 5 } }\n"
        "math.randomseed(0)\n",
        // P1: instrumented; callable, method-bearing, and __index-traced, so `t(...)`,
        // `t:set(...)`, `obj:method()` etc. run instead of erroring, and every dynamic lookup
        // lands in the trace as an ordered marker.
        "local function mk(name)\n"
        "    local fixture = { 1, 2, 3, key = 'value', x = 5 }\n"
        "    return setmetatable(fixture, {\n"
        "        __call = function(self, ...) print('<call>', name, ...) return 1, 'r' end,\n"
        "        __index = function(self, k)\n"
        "            print('<index>', name, k)\n"
        "            return function(...) print('<method>', name, k, ...) return 2 end\n"
        "        end,\n"
        "    })\n"
        "end\n"
        "t = mk('t')\n"
        "obj = mk('obj')\n"
        "math.randomseed(0)\n",
        // P2: hostile scalars; forces the error/short-circuit paths from a different angle.
        "t = 0\n"
        "obj = 'hostile'\n"
        "math.randomseed(0)\n",
        // P3: permissive primitives; nil, booleans, numbers and functions answer every operator with a
        // traced marker, so type-incoherent programs keep running and their operator order is observed.
        "local print, type, select = print, type, select\n"
        "local function tag(v)\n"
        "    local ty = type(v)\n"
        "    if ty == 'nil' or ty == 'boolean' or ty == 'number' or ty == 'integer' or ty == 'string' then return v end\n"
        "    return '<' .. ty .. '>'\n"
        "end\n"
        "local mt = {\n"
        "    __index = function(s, k) print('<index>', tag(s), tag(k)) return nil end,\n"
        "    __newindex = function(s, k, v) print('<newindex>', tag(s), tag(k), tag(v)) end,\n"
        "    __call = function(s, ...) print('<call>', tag(s), select('#', ...)) return nil end,\n"
        "    __unm = function(a) print('<unm>', tag(a)) return 0 end,\n"
        "    __len = function(a) print('<len>', tag(a)) return 0 end,\n"
        "    __concat = function(a, b) print('<concat>', tag(a), tag(b)) return '' end,\n"
        "    __lt = function(a, b) print('<lt>', tag(a), tag(b)) return false end,\n"
        "    __le = function(a, b) print('<le>', tag(a), tag(b)) return false end,\n"
        "}\n"
        "local smt = getmetatable('')\n"
        "for _, op in { 'add', 'sub', 'mul', 'div', 'idiv', 'mod', 'pow' } do\n"
        "    local name = '<' .. op .. '>'\n"
        "    mt['__' .. op] = function(a, b) print(name, tag(a), tag(b)) return 0 end\n"
        "    smt['__' .. op] = mt['__' .. op]\n"
        "end\n"
        "smt.__call, smt.__unm, smt.__concat = mt.__call, mt.__unm, mt.__concat\n"
        "__fuzz_setmt(mt)\n"
        "t = { 1, 2, 3, key = 'value', x = 5 }\n"
        "obj = { x = 1, y = 'hello', items = { 4, 5 } }\n"
        "math.randomseed(0)\n",
    };
    inline constexpr size_t kSemPreludeCount = sizeof(kSemPreludes) / sizeof(kSemPreludes[0]);

    // Execute one bytecode blob in a fresh sandboxed state; capture prints, returns, and errors.
    // preludeBc must be the compiled kSemPrelude (same compiler settings; callers reuse one blob).
    inline SemTrace RunLuauTrace(
        const std::string &bytecode, const std::string &preludeBc, std::chrono::milliseconds budget = std::chrono::milliseconds(1000),
        const std::string &driverBc = ""
    ) {
        SemTrace result{};
        lua_State *L = luaL_newstate();
        if (!L)
            return result;
        luaL_openlibs(L);

        lua_getglobal(L, "vector");
        lua_getglobal(L, "table");
        lua_getfield(L, -1, "clone");
        lua_pushvalue(L, -3);
        lua_call(L, 1, 1);
        lua_getfield(L, -3, "create");
        lua_setfield(L, -2, "new");
        for (int axis = 0; axis < 3; ++axis) {
#if LUA_VECTOR_SIZE == 4
            lua_pushvector(L, axis == 0, axis == 1, axis == 2, 0);
#else
            lua_pushvector(L, axis == 0, axis == 1, axis == 2);
#endif
            lua_setfield(L, -2, axis == 0 ? "xAxis" : axis == 1 ? "yAxis" : "zAxis");
        }
        lua_setglobal(L, "Vector3");
        lua_pop(L, 2);

        std::string trace;
        lua_pushlightuserdata(L, &trace);
        lua_pushcclosure(L, detail::TracePrint, "print", 1);
        lua_setglobal(L, "print");

        detail::RunBudget runBudget{};
        runBudget.deadline = std::chrono::steady_clock::now() + budget;
        lua_callbacks(L)->userdata = &runBudget;
        lua_callbacks(L)->interrupt = detail::InterruptHook;

        std::string errorMsg;
        const auto runChunk = [&](const std::string &bc, bool captureReturns) -> int {
            if (luau_load(L, "=chunk", bc.data(), bc.size(), 0) != 0) {
                lua_pop(L, 1);
                return -1; // load failure, not a runtime error
            }
            const int base = lua_gettop(L) - 1;
            const int status = lua_pcall(L, 0, LUA_MULTRET, 0);
            if (status == 0 && captureReturns) {
                const int nret = lua_gettop(L) - base;
                std::set<const void *> visited;
                for (int i = 0; i < nret; ++i) {
                    trace += i == 0 ? "return: " : "\t";
                    detail::SerializeValue(L, base + 1 + i, trace, 4, visited);
                }
                if (nret > 0)
                    trace += '\n';
            } else if (status != 0) {
                size_t len = 0;
                const char *msg = lua_tolstring(L, -1, &len); // must read before settop pops the error object
                if (!msg)
                    runBudget.comparable = false;
                errorMsg = msg ? std::string(msg, len) : "<non-string error>";
            }
            lua_settop(L, base);
            return status;
        };

        lua_pushcfunction(L, detail::SetPrimitiveMetatable, "__fuzz_setmt");
        lua_setglobal(L, "__fuzz_setmt");
        if (runChunk(preludeBc, false) != 0) {
            lua_close(L);
            return result; // fixture must run clean; anything else is a harness bug
        }
        // The prelude is harness setup, not subject behavior. Its prints, comparability and
        // object-serialization state must not leak into the subject's trace or verdict, and its
        // runtime must not consume the subject's timeout budget.
        trace.clear();
        runBudget.prints.clear();
        runBudget.comparable = true;
        runBudget.seenObjects.clear();
        runBudget.deadline = std::chrono::steady_clock::now() + budget;
        runBudget.expired = false;
        lua_pushnil(L);
        lua_setglobal(L, "__fuzz_setmt");

        int status;
        if (driverBc.empty()) {
            status = runChunk(bytecode, true);
        } else if (luau_load(L, "=chunk", bytecode.data(), bytecode.size(), 0) != 0) {
            lua_pop(L, 1);
            status = -1;
        } else {
            lua_setglobal(L, "__integration_subject");
            status = runChunk(driverBc, true);
        }
        if (status == -1) {
            result.status = SemTrace::Status::LoadFailed;
        } else if (status != 0) {
            const std::string err = detail::NormalizeError(errorMsg);
            if (runBudget.expired) {
                result.status = SemTrace::Status::Timeout;
            } else {
                result.status = SemTrace::Status::Error;
                if (errorMsg != "<non-string error>")
                    result.error = err;
                trace += "error: " + err + '\n';
            }
        } else {
            result.status = SemTrace::Status::Ok;
        }
        // printed `pcall` messages carry the same source locations as uncaught errors
        result.trace = detail::NormalizeError(trace);
        result.comparable = runBudget.comparable;
        result.prints = std::move(runBudget.prints);
        for (auto &print : result.prints)
            if (print)
                *print = detail::NormalizeError(*print);
        lua_close(L);
        return result;
    }

    struct SemVerdict {
        enum class Kind { Match, Diverge, Unrunnable } kind = Kind::Unrunnable;
        SemTrace original, decompiled; // for Diverge: the first diverging fixture's traces
        size_t fixture = 0;            // index of the fixture that diverged (or last judged)
        size_t successful = 0, equalErrors = 0, opaque = 0, skipped = 0;
    };

    // An equal error establishes coverage only when the body traced something before it.
    inline SemVerdict CompareSemantics(const std::string &originalBc, const std::string &decompiledBc, const std::vector<std::string> &preludeBcs) {
        SemVerdict v{};
        bool judgedAny = false;
        bool incomplete = false;
        for (size_t i = 0; i < preludeBcs.size(); ++i) {
            SemTrace orig = RunLuauTrace(originalBc, preludeBcs[i]);
            if (orig.status == SemTrace::Status::Timeout || orig.status == SemTrace::Status::LoadFailed) {
                ++v.skipped;
                incomplete = true;
                continue;
            }
            SemTrace dec = RunLuauTrace(decompiledBc, preludeBcs[i]);
            v.fixture = i;
            // unbounded recursion stops where the stack runs out, which depends on each frame's register count
            const auto overflowed = [](const SemTrace &trace) { return trace.error && trace.error->find("stack overflow") != std::string::npos; };
            if (overflowed(orig) && overflowed(dec)) {
                const auto calls = [](const std::string &trace) { return trace.substr(0, trace.rfind("error: ")); };
                const auto a = calls(orig.trace), b = calls(dec.trace);
                if (!a.starts_with(b) && !b.starts_with(a)) {
                    v.kind = SemVerdict::Kind::Diverge;
                    v.original = std::move(orig);
                    v.decompiled = std::move(dec);
                    return v;
                }
                ++v.skipped;
                incomplete = true;
                continue;
            }
            bool printsDiffer = orig.prints.size() != dec.prints.size();
            for (size_t p = 0; !printsDiffer && p < orig.prints.size(); ++p)
                printsDiffer = orig.prints[p] && dec.prints[p] && orig.prints[p] != dec.prints[p];
            if (dec.status != orig.status || printsDiffer || (orig.error && dec.error && orig.error != dec.error) ||
                (orig.comparable && dec.comparable && dec.trace != orig.trace)) {
                // pointer-keyed tables iterate in allocation order, which differs between states
                const bool deterministic = std::ranges::all_of(std::views::iota(0, 3), [&](int) {
                    const SemTrace again = RunLuauTrace(originalBc, preludeBcs[i]);
                    return again.status == orig.status && again.trace == orig.trace;
                });
                if (!deterministic) {
                    ++v.skipped;
                    incomplete = true;
                    continue;
                }
                v.kind = SemVerdict::Kind::Diverge;
                v.original = std::move(orig);
                v.decompiled = std::move(dec);
                return v;
            }
            if (!orig.comparable || !dec.comparable)
                ++v.opaque;
            else if (orig.status == SemTrace::Status::Ok)
                ++v.successful;
            else if (orig.status == SemTrace::Status::Error)
                ++v.equalErrors;
            incomplete |= !orig.comparable || !dec.comparable;
            judgedAny |= orig.comparable && dec.comparable && (orig.status == SemTrace::Status::Ok || !orig.prints.empty());
            v.original = std::move(orig);
            v.decompiled = std::move(dec);
        }
        v.kind = judgedAny && !incomplete ? SemVerdict::Kind::Match : SemVerdict::Kind::Unrunnable;
        return v;
    }

    // compile all fixture preludes once (thread-safe local-static init in callers).
    inline std::vector<std::string> CompilePreludes(const std::function<bool(const std::string &, std::string *)> &compile) {
        std::vector<std::string> out;
        for (size_t i = 0; i < kSemPreludeCount; ++i) {
            std::string bc;
            if (!compile(kSemPreludes[i], &bc))
                return {};
            out.push_back(std::move(bc));
        }
        return out;
    }
} // namespace fuzz

//
// Created by Dottik on 04/17/2026.
//

#include "../Decompiler/IntegrationTestSupport.hpp"
#include "Deserializer.hpp"
#include "Luau/BytecodeBuilder.h"
#include <catch2/catch_test_macros.hpp>

TEST_CASE("V6 - constants check", "[BytecodeDecoder]") {
    /*
       V6 bytecode for `print(\"hi\", 0, vector.create(1,1,1), { a = 2 }, nil, 0.2)`
       0x06, 0x03, 0x05, 0x05, 0x70, 0x72, 0x69, 0x6e, 0x74, 0x02, 0x68, 0x69, 0x06, 0x76, 0x65, 0x63, 0x74, 0x6f, 0x72, 0x06, 0x63, 0x72, 0x65, 0x61, 0x74,
       0x65, 0x01, 0x61, 0x00, 0x01, 0x07, 0x00, 0x00, 0x01, 0x02, 0x00, 0x14, 0x41, 0x00, 0x00, 0x00, 0x0c, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x40, 0x05,
       0x01, 0x02, 0x00, 0x04, 0x02, 0x00, 0x00, 0x04, 0x04, 0x01, 0x00, 0x04, 0x05, 0x01, 0x00, 0x04, 0x06, 0x01, 0x00, 0x44, 0x36, 0x00, 0x02, 0x0c, 0x03,
       0x05, 0x00, 0x00, 0x10, 0x30, 0x80, 0x15, 0x03, 0x04, 0x02, 0x36, 0x04, 0x07, 0x00, 0x04, 0x05, 0x02, 0x00, 0x10, 0x05, 0x04, 0x80, 0x06, 0x00, 0x00,
       0x00, 0x02, 0x05, 0x00, 0x00, 0x05, 0x06, 0x08, 0x00, 0x15, 0x00, 0x07, 0x01, 0x16, 0x00, 0x01, 0x00, 0x09, 0x03, 0x01, 0x04, 0x00, 0x00, 0x00, 0x40,
       0x03, 0x02, 0x03, 0x03, 0x03, 0x04, 0x04, 0x00, 0x10, 0x30, 0x80, 0x03, 0x05, 0x05, 0x01, 0x06, 0x02, 0x9a, 0x99, 0x99, 0x99, 0x99, 0x99, 0xc9, 0x3f,
       0x00, 0x01, 0x00, 0x01, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
       0x01, 0x00, 0x00, 0x00, 0x00, 0x00
     */

    std::vector<uint8_t> bytecodeBinary = {0x06, 0x03, 0x05, 0x05, 0x70, 0x72, 0x69, 0x6e, 0x74, 0x02, 0x68, 0x69, 0x06, 0x76, 0x65, 0x63, 0x74, 0x6f, 0x72,
                                           0x06, 0x63, 0x72, 0x65, 0x61, 0x74, 0x65, 0x01, 0x61, 0x00, 0x01, 0x07, 0x00, 0x00, 0x01, 0x02, 0x00, 0x14, 0x41,
                                           0x00, 0x00, 0x00, 0x0c, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x40, 0x05, 0x01, 0x02, 0x00, 0x04, 0x02, 0x00, 0x00,
                                           0x04, 0x04, 0x01, 0x00, 0x04, 0x05, 0x01, 0x00, 0x04, 0x06, 0x01, 0x00, 0x44, 0x36, 0x00, 0x02, 0x0c, 0x03, 0x05,
                                           0x00, 0x00, 0x10, 0x30, 0x80, 0x15, 0x03, 0x04, 0x02, 0x36, 0x04, 0x07, 0x00, 0x04, 0x05, 0x02, 0x00, 0x10, 0x05,
                                           0x04, 0x80, 0x06, 0x00, 0x00, 0x00, 0x02, 0x05, 0x00, 0x00, 0x05, 0x06, 0x08, 0x00, 0x15, 0x00, 0x07, 0x01, 0x16,
                                           0x00, 0x01, 0x00, 0x09, 0x03, 0x01, 0x04, 0x00, 0x00, 0x00, 0x40, 0x03, 0x02, 0x03, 0x03, 0x03, 0x04, 0x04, 0x00,
                                           0x10, 0x30, 0x80, 0x03, 0x05, 0x05, 0x01, 0x06, 0x02, 0x9a, 0x99, 0x99, 0x99, 0x99, 0x99, 0xc9, 0x3f, 0x00, 0x01,
                                           0x00, 0x01, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                           0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00};
    std::string bytecode;
    bytecode.resize(bytecodeBinary.size());
    memcpy(bytecode.data(), bytecodeBinary.data(), bytecodeBinary.size());

    Deserializer deserializer{};
    DeserializedBytecode *deserialized;
    auto dOpt = deserializer.Deserialize(bytecode);
    REQUIRE(dOpt);
    deserialized = &*dOpt;

    INFO("Checking Deserialized Metadata");
    REQUIRE(deserialized->functions.data() == deserialized->lpMainFunction);

    auto lpMain = deserialized->lpMainFunction;

    REQUIRE(lpMain->constants.size() == 9);
    REQUIRE(lpMain->constants[0].kType == LUA_TSTRING);
    REQUIRE(lpMain->constants[0].GetValue<std::string>() == "print");
    REQUIRE(lpMain->constants[1].kType == LUA_TNIL);
    REQUIRE(lpMain->constants[2].kType == LUA_TSTRING);
    REQUIRE(lpMain->constants[2].GetValue<std::string>() == "hi");
    REQUIRE(lpMain->constants[3].kType == LUA_TSTRING);
    REQUIRE(lpMain->constants[3].GetValue<std::string>() == "vector");
    REQUIRE(lpMain->constants[4].kType == LUA_TSTRING);
    REQUIRE(lpMain->constants[4].GetValue<std::string>() == "create");
    REQUIRE(lpMain->constants[5].kType == LUA_TNIL);
    REQUIRE(lpMain->constants[6].kType == LUA_TSTRING);
    REQUIRE(lpMain->constants[6].GetValue<std::string>() == "a");
    REQUIRE(lpMain->constants[7].kType == LUA_TTABLE);
    REQUIRE(lpMain->constants[8].kType == LUA_TNUMBER);
    REQUIRE(lpMain->constants[8].GetValue<double>() <= 0.2 + std::numeric_limits<double>::epsilon());
    REQUIRE(lpMain->constants[8].GetValue<double>() >= 0.2 - std::numeric_limits<double>::epsilon());
    fuzz::EnableLuauFlags();
    Decompiler decompiler;
    const auto result = decompiler.DecompileVanillaBytecode(bytecode);
    REQUIRE(result.resultCode == DecompileResult::Success);
    integration_test::CheckOutput(bytecode, result.decompilationOutput, Luau::CompileOptions{1, 2});
}

TEST_CASE("V6 - metadata check", "[BytecodeDecoder]") {
    /*
        V6 bytecode for `print'Hello, world!'`

          06 03 02 05   70 72 69 6e   74 0d 48 65   6c 6c 6f 2c   │ ····print·Hello, │
          20 77 6f 72   6c 64 21 00   01 02 00 00   01 02 00 06   │  world!········· │
          41 00 00 00   0c 00 01 00   00 00 00 40   05 01 02 00   │ A··········@···· │
          15 00 02 01   16 00 01 00   03 03 01 04   00 00 00 40   │ ···············@ │
          03 02 00 01   00 01 18 00   00 00 00 00   00 01 00 00   │ ················ │
          00 00 00

     */
    std::vector<uint8_t> bytecodeBinary = {0x06, 0x03, 0x02, 0x05, 0x70, 0x72, 0x69, 0x6e, 0x74, 0x0d, 0x48, 0x65, 0x6c, 0x6c, 0x6f, 0x2c, 0x20,
                                           0x77, 0x6f, 0x72, 0x6c, 0x64, 0x21, 0x00, 0x01, 0x02, 0x00, 0x00, 0x01, 0x02, 0x00, 0x06, 0x41, 0x00,
                                           0x00, 0x00, 0x0c, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x40, 0x05, 0x01, 0x02, 0x00, 0x15, 0x00, 0x02,
                                           0x01, 0x16, 0x00, 0x01, 0x00, 0x03, 0x03, 0x01, 0x04, 0x00, 0x00, 0x00, 0x40, 0x03, 0x02, 0x00, 0x01,
                                           0x00, 0x01, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00};
    std::string bytecode;
    bytecode.resize(bytecodeBinary.size());
    memcpy(bytecode.data(), bytecodeBinary.data(), bytecodeBinary.size());

    Deserializer deserializer{};
    DeserializedBytecode *deserialized;
    auto dOpt = deserializer.Deserialize(bytecode);
    REQUIRE(dOpt);
    deserialized = &*dOpt;

    INFO("Checking Deserialized Metadata");
    REQUIRE(deserialized->bytecodeVersion == 6);
    REQUIRE(deserialized->lpMainFunction != nullptr);
    REQUIRE(deserialized->typesVersion == 3); // v6 bytecode uses tt v3
    REQUIRE(deserialized->functions.size() == 1);
    REQUIRE(deserialized->functions.data() == deserialized->lpMainFunction);

    REQUIRE(deserialized->stringTable.size() == 2);           // method + string used.
    REQUIRE(deserialized->stringTable[0] == "print");         // first string used
    REQUIRE(deserialized->stringTable[1] == "Hello, world!"); // second string used

    INFO("Checking runtime userdata mappings");
    for (size_t i = 0; i < deserialized->userdataMappings.size(); i++) {
        REQUIRE(deserialized->userdataMappings.at(i) == 0); // no ud mappings.
    }

    INFO("Checking lpMain metadata");
    REQUIRE(deserialized->lpMainFunction->bIsMain);
    REQUIRE(deserialized->lpMainFunction->bytecodeId == 0);
    REQUIRE(deserialized->lpMainFunction->isvararg);
    REQUIRE(deserialized->lpMainFunction->nups == 0);
    REQUIRE(deserialized->lpMainFunction->numparams == 0);
    REQUIRE(deserialized->lpMainFunction->upvalueNames.empty());
    fuzz::EnableLuauFlags();
    Decompiler decompiler;
    const auto result = decompiler.DecompileVanillaBytecode(bytecode);
    REQUIRE(result.resultCode == DecompileResult::Success);
    integration_test::CheckOutput(bytecode, result.decompilationOutput, Luau::CompileOptions{1, 2});
}

TEST_CASE("Type metadata emits executable Luau annotations", "[BytecodeDecoder][Integration]") {
    fuzz::EnableLuauFlags();
    for (uint8_t type :
         {uint8_t(LBC_TYPE_TAGGED_USERDATA_BASE), uint8_t(LBC_TYPE_TAGGED_USERDATA_BASE | LBC_TYPE_OPTIONAL_BIT), uint8_t(LBC_TYPE_NUMBER),
          uint8_t(LBC_TYPE_STRING)}) {
        INFO("type byte " << int(type));
        Luau::BytecodeBuilder builder;
        const auto child = builder.beginFunction(1, false);
        builder.setFunctionTypeInfo(std::string{char(LBC_TYPE_FUNCTION), char(1), char(type)});
        builder.emitABC(LOP_RETURN, 0, 2, 0);
        builder.endFunction(1, 0);
        const auto main = builder.beginFunction(0, false);
        const auto childIndex = builder.addChildFunction(child);
        builder.emitAD(LOP_NEWCLOSURE, 0, static_cast<int16_t>(childIndex));
        builder.emitABC(LOP_RETURN, 0, 2, 0);
        builder.endFunction(1, 0);
        builder.setMainFunction(main);
        builder.finalize();
        Decompiler decompiler;
        const auto result = decompiler.DecompileVanillaBytecode(builder.getBytecode(), DecompilerFlags::InferTypes);
        REQUIRE(result.resultCode == DecompileResult::Success);
        CHECK(result.decompilationOutput.find("/*") == std::string::npos);
        Deserializer deserializer;
        auto decoded = deserializer.Deserialize(builder.getBytecode());
        REQUIRE(decoded.has_value());
        const auto &metadata = decoded->functions.at(0).typeinfo;
        REQUIRE_FALSE(metadata.empty());
        REQUIRE(static_cast<uint8_t>(metadata.back()) == type);
        const auto annotation = Deserializer::GetBytecodeTypeName(static_cast<uint8_t>(metadata.back()));
        if ((type & ~LBC_TYPE_OPTIONAL_BIT) == LBC_TYPE_TAGGED_USERDATA_BASE) {
            CHECK(annotation.find("any --[[ userdata, unmapped ]]") != std::string::npos);
            if (type & LBC_TYPE_OPTIONAL_BIT)
                CHECK(annotation.back() == '?');
        }
        integration_test::CheckSource(
            "return function(value: " + annotation + ") return value end", result.decompilationOutput, Luau::CompileOptions{1, 2},
            "local f=__integration_subject(); print(f(7),f('value'),f(nil))"
        );
    }
}

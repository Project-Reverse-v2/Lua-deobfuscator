# envlog.luau — Dynamic Deobfuscation Runtime

This is a fake Roblox/executor environment that logs operations and reconstructs readable Luau from the observed behavior of a protected script.

## How it works

The Luarmor VM cannot be read statically in a useful way (bytecode is encrypted, interpreter is flattened). This runtime executes the script against logging proxies and rebuilds the call graph / operations from what the script actually does.

## Integration

Use `build_harness.luau` — `build_harness("script.lua", config)` — rather
than assembling this by hand; see the top-level README's "runtime/" section
for why and the exact contract. In short, envlog.luau is the *body* of a
wrapper function and expects these upvalues, in this order:

```lua
local __SOURCE, __CONFIG, __RAW, __ROBLOX, __UNICODE, __MARK = ...
```

- `__SOURCE: string` — the protected script
- `__CONFIG: table` — options:
  ```lua
  {
    max_stmts = 250000,
    max_block = 25000,
    max_waits = 50,
    max_depth = 24,
    time_budget = 30,
    -- native = true,   -- if running inside Roblox Studio
    -- probe = true,    -- log global reads
    -- trace = true,    -- full trace
  }
  ```
- `__RAW: table` — `{ getfenv, setfenv, loadstring }` captured *before* any
  environment sandboxing, so the harness has working originals even if the
  surrounding process already shadowed the globals. **Required** — read
  unconditionally near the top of the file, no fallback.
- `__ROBLOX: table?` — `{ enums, classes, datatypes }` built from
  `roblox_api.luau` + `datatypes.luau`. Optional: falls back to
  `{enums="", classes=""}` with no `datatypes` field if omitted, which
  degrades Roblox-type-aware behavior but doesn't crash.
- `__UNICODE: table?` — the table `unicode_data.luau` returns. Optional with
  a similar empty-table fallback.
- `__MARK: string?` — a per-run random nonce used to prefix the
  `ENVLOG-BEGIN`/`END` protocol markers so a protected script can't forge
  them. Optional (defaults to an empty nonce), but using a fresh random
  value each run is recommended.

Then the rest of `envlog.luau` is executed.

## Usage notes

- Best results come from running inside Roblox Studio (native mode) so engine objects behave correctly.
- Outside Studio it still captures a large amount of high-level behavior via proxies.
- Output is printed between `\0ENVLOG-BEGIN` and `\0ENVLOG-END` markers.
- Complements the Rust static/dynamic stages in this project.

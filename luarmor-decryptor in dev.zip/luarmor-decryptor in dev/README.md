# Luarmor Decryptor

Multi-pass dynamic deobfuscator for Luarmor V4 / "superflow" loaders, plus a
pure-Luau dynamic-analysis harness (`runtime/`).

## What changed in this pass, and why (evidence-based)

Every item below was found by reading the actual shipped source and a real
sample (`v4_init_marbeg.lua`, 588KB), not assumed. The previous version of
this tool did not build, and once fixed to build, did not run against a
real sample — see each item for the specific evidence.

1. **Wrong Lua runtime entirely (`Cargo.toml`).** The sample uses `continue;`
   statements and compound-assignment operators (`+=`, `-=`, ...) — Luau-only
   syntax that no standard Lua 5.x grammar accepts. The tool was building
   mlua with the `lua54` feature, so `lua.load(source)` would hit a *parse
   error* before any shim or capture logic ever ran. Switched to mlua's
   `luau` feature, which links the real Luau VM.

2. **`superflow.rs` decoded the wrong data, and decoded it wrong.**
   The old code applied a "radix-85, mod 85" decode to the
   `superflow_bytecode = {...}` table. That table's string literals decode
   (plain `\NNN`/`\xHH` escapes) to bytes spanning the *full* 0–255 range —
   proof it was never base-85 text, since base85 input is restricted to a
   small printable alphabet. Applying `mod 85` to arbitrary bytes silently
   destroys them. Separately, this file has an independent 488,051-byte
   `[==[ ... ]==]` long-bracket string elsewhere, whose byte alphabet is
   *exactly* the canonical Ascii85 set (`!`..`u`, plus `z`) — **that's** the
   real base85 payload, and the old code never even looked for it (it only
   ever searched for the literal marker `superflow_bytecode`).
   `extract/superflow.rs` was rewritten to: (a) leave the
   `superflow_bytecode` table as raw bytes, no decode, and report
   `_bsdata0[N]` slices it can't resolve instead of silently dropping them;
   (b) scan the whole file for long-bracket literals, validate each one's
   alphabet before touching it, and decode validated ones with the exact
   algorithm transcribed from the sample's own decoder function (found at
   the call site `y[0x29](...)`, assigned by `S[0x29] = function(y) ... end`
   — the `85`/`85^2`/`85^3`/`85^4` constants in that function matched
   `0x55`/`0x1C39`/`0x95EED`/`52200625` exactly, which is what confirms this
   is unmodified Adobe Ascii85 arithmetic). Covered by unit tests in
   `src/extract/superflow.rs`.

3. **Luau's `buffer` library.** The sample does `h=buffer` and calls
   `readu32`/`readi16`/`readu16`/`readf32`/`copy` on values derived from it —
   the Luau `buffer` API, not anything in Lua's stdlib (confirmed by the
   bare string literals "readu32"/"readi16"/"readu16"/"readf32" appearing in
   the source, used as field-name lookups). mlua's `luau` feature already
   opens a native `buffer` table, so this mostly fixes itself with item 1,
   but `src/buffer_shim.rs` adds a byte-compatible fallback (installed only
   if the global is missing) in case a future mlua version or a `lua54`
   fallback path is used.

4. **The dynamic bootstrap never actually returned anything.**
   `Arc::try_unwrap(cap)` was called while `lua` — which holds its own
   `Arc<Mutex<Capture>>` clone inside every installed shim closure, kept
   alive by the Lua globals table — was still in scope. That made
   `Arc::try_unwrap` fail with "capture still shared" on *every single run*,
   so `chunks` was always reported as 0 regardless of what actually happened
   during execution. Fixed by dropping `lua` before unwrapping.

5. **`string.dump` doesn't exist in Luau.** It's a PUC-Lua-only bytecode
   dump function; Luau's `string` library has no equivalent. The dump hook
   used to unconditionally fetch `string.dump` and convert it straight into
   an `mlua::Function`, which failed with "error converting Lua nil to
   function" as soon as it ran — before the loader itself was ever reached.
   Now skipped gracefully when the function isn't present.

6. **Missing module wiring (`main.rs`).** `src/luac.rs` existed on disk but
   was never declared with `mod luac;`, and `deobf.rs` called
   `crate::decompile_bytecode(...)` for a function that's actually private
   inside `deobf.rs` itself. Both are straightforward `rustc`-caught bugs,
   but between them the project didn't compile with any feature
   combination before this pass.

After all of the above, a real run against the sample parses and executes
through the Luau bootstrap with **zero runtime errors**, and the dynamic
capture independently confirms the static finding in item 2: it reports
`bsdata_slots: [4, 12]` — the *exact* two `_bsdata0` indices the static
`superflow_bytecode` table analysis found it couldn't resolve on its own.

## What's still unresolved (not attempted — stated rather than guessed)

- **The decoded base85 blob's own format.** It's dense, low-byte-value-
  dominated data consistent with a Luau bytecode or custom VM instruction
  stream, but no opcode table has been recovered, and none is invented here.
- **The two `_bsdata0` slices.** Their real content is supplied by the
  external Luarmor bootstrapper that calls this chunk (not present in this
  file), so it cannot be recovered from static analysis of this file alone,
  and the dynamic sandbox can only report *that* they're needed, not *what*
  they contain.
- **Full VM devirtualization.** This sample is a flattened custom VM; doing
  this properly is an interpreter-recovery project of its own (see the
  `deobf` skill's section on virtualized samples), not a "decode one more
  layer" fix.

## `runtime/` — the pure-Luau dynamic harness (envlog.luau)

`runtime/envlog.luau` builds a fake Roblox/executor environment out of
logging proxies and reconstructs readable behavior from what a protected
script actually does at runtime — a different approach from the Rust
bootstrap above (meant to run under a real `luau` interpreter, e.g. in
Roblox Studio, not embedded via mlua).

**This also didn't actually work as shipped.** `runtime/README.md`
documents only two of envlog.luau's external dependencies (`__SOURCE`,
`__CONFIG`), but the file reads at least two more that are *not* optional —
`__RAW` (`.getfenv`/`.setfenv`/`.loadstring`, read once near the top) and,
with safe fallbacks if omitted, `__ROBLOX` and `__UNICODE` (built from
`roblox_api.luau`/`unicode_data.luau`/`datatypes.luau`, which ship in this
directory but were never wired together by anything — no driver script
existed anywhere in the archive). `datatypes.luau`'s own header comment
says plainly what `__ROBLOX` should contain ("bundled into the harness as
`__ROBLOX.datatypes`"), which is where the shape below comes from —
it isn't guessed.

`runtime/build_harness.luau` is a new driver that assembles all of this and
calls into `envlog.luau`:

```bash
luau -e '
  local h = require("./build_harness")
  print(h.build_harness("/path/to/protected_script.lua"))
'
```

or from another Luau script:

```lua
local harness = require("runtime/build_harness")
local output = harness.build_harness("script.lua", { time_budget = 30 })
```

All five Luau files in `runtime/` (`envlog.luau`, `build_harness.luau`,
`roblox_api.luau`, `unicode_data.luau`, `datatypes.luau`) have been checked
and parse cleanly under the real Luau parser (verified here via the mlua
`luau` backend this project now links — see Build). **`build_harness.luau`
has not been executed end-to-end against a real `luau` CLI** in the
environment this was written in (none was installed there); it was written
directly from envlog.luau's own documented reads of these names, but treat
it as reviewed, not field-verified, until you've run it yourself.

## Build

```bash
cargo build --release --features bootstrap,http
```

## Usage

```bash
./target/release/luarmor-decryptor deobf script.lua ./output 8 30000
```

Flags:
- `passes` — max VM passes (default 8)
- `timeout_ms` — timeout per pass
- `--no-fetch` — disable remote HTTP fetching

## Output

- `payload.raw` — original input, byte-for-byte
- `superflow_table_raw.bin` / `superflow_table_info.json` — the
  `superflow_bytecode` table's raw bytes (see item 2 above: never
  base85-decoded) plus which `_bsdata0[N]` slices were missing
- `base85_blobs_info.json` — every long-bracket string literal found, its
  offset, and whether its alphabet validated as base85
- `base85_blob_NN_decoded.bin` — the decoded bytes for each blob that did
  validate
- `dynamic/` — captured chunks + `dynamic_report.json`
- `dynamic_summary.txt` — human-readable summary of what was captured
  (errors, URLs seen/fetched, `_bsdata0` slots accessed, chunk count)
- `*.decompiled.lua` / `*.captured.lua` — extracted payloads

use anyhow::Result;
use std::path::Path;
use std::time::Duration;

mod bootstrap;
mod buffer_shim;
mod deobf;
mod dynamic;
mod extract;
mod luac;

use crate::dynamic::DynamicConfig;

fn main() -> Result<()> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 3 {
        eprintln!("Usage: {} deobf <file> <out_dir> [passes] [timeout_ms] [--no-fetch]", args[0]);
        std::process::exit(1);
    }

    let file = Path::new(&args[2]);
    let out = Path::new(&args[3]);
    let passes = args.get(4).and_then(|s| s.parse().ok()).unwrap_or(5);
    let timeout_ms = args.get(5).and_then(|s| s.parse().ok()).unwrap_or(20_000);
    let no_fetch = args.iter().any(|a| a == "--no-fetch");

    cmd_deobf(file, out, passes, timeout_ms, no_fetch)?;
    Ok(())
}

fn cmd_deobf(file: &Path, out: &Path, passes: usize, timeout_ms: u64, no_fetch: bool) -> Result<()> {
    std::fs::create_dir_all(out)?;
    let payload = std::fs::read(file)?;

    let config = DynamicConfig {
        max_passes: passes,
        timeout_per_pass: Duration::from_millis(timeout_ms),
        fetch_remote: !no_fetch,
        recurse_on_luarmor: true,
        max_recursion_depth: 3,
    };

    let result = deobf::deobf_with_config(&payload, out, &config)?;
    println!("Stages run:      {:?}", result.stages_run);
    println!("Superflow table (raw, unresolved bsdata noted): {} bytes", result.static_blob);
    println!(
        "Base85 long-string blobs: {} found, {} decoded",
        result.base85_blobs_found, result.base85_blobs_decoded
    );
    println!("Captured chunks: {}", result.captured_chunks);
    for p in &result.decompiled {
        println!("Decompiled: {}", p.display());
    }
    Ok(())
}

// src/bootstrap.rs — improved for Luarmor V4
#![cfg(feature = "bootstrap")]

use anyhow::{Context, Result};
use mlua::{Function, Lua, MultiValue, String as LString, Table, Value};
use std::collections::HashMap;
use std::path::Path;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone)]
pub struct CapturedChunk {
    pub source: String,
    pub name: Option<String>,
    pub data: Vec<u8>,
    pub is_bytecode: bool,
}

#[derive(Default)]
pub struct Capture {
    pub chunks: Vec<CapturedChunk>,
    pub http_responses: Vec<(String, Vec<u8>)>,
    pub bxor_samples: Vec<(u64, u64)>,
    pub bsdata_slots_accessed: Vec<usize>,
    pub string_char_runs: Vec<usize>,
    pub env_swaps: Vec<(String, String)>,
    pub tracebacks: Vec<String>,
    pub errors: Vec<String>,
    pub raw_superflow_parts: Vec<Vec<u8>>,
}

pub fn run(path: &Path, timeout: Duration) -> Result<Capture> {
    let source = std::fs::read(path)
        .with_context(|| format!("read {}", path.display()))?;
    run_with_cache(&source, &HashMap::new(), timeout)
}

pub fn run_with_cache(
    source: &[u8],
    http_cache: &HashMap<String, Vec<u8>>,
    timeout: Duration,
) -> Result<Capture> {
    let lua = Lua::new();
    let cap = Arc::new(Mutex::new(Capture::default()));
    let deadline = Arc::new(AtomicU64::new(
        now_ms() + timeout.as_millis() as u64,
    ));
    let cache = Arc::new(http_cache.clone());

    // mlua's `Error` type is not `Send + Sync` when built against Luau
    // (unlike the lua54 backend this file was originally written
    // against), so it can't convert into `anyhow::Error` via plain `?`.
    // Everything below is pure Lua-API setup/execution; it runs inside
    // one closure returning `mlua::Result` and is converted to anyhow
    // exactly once at the boundary, instead of at every call site.
    let setup_and_run = || -> mlua::Result<()> {
        install_timeout(&lua, &deadline)?;
        install_env_shims(&lua, &cap)?;
        install_debug_shims(&lua)?;
        install_os_shims(&lua)?;
        install_math_shims(&lua)?;
        install_bit32_shim(&lua, &cap)?;
        crate::buffer_shim::install_buffer_library(&lua)?;
        install_bsdata_proxy(&lua, &cap)?;
        install_string_dump_hook(&lua, &cap)?;
        install_loadstring_hook(&lua, &cap)?;
        install_loadfile_hook(&lua, &cap)?;
        install_string_hooks(&lua, &cap)?;
        install_game_stub(&lua, &cap, &cache)?;
        install_http_stubs(&lua, &cap, &cache)?;
        install_require_stub(&lua)?;

        // Always pcall the loader so partial execution still captures.
        {
            let v: Value = lua.globals().get("pcall")?;
        }
        let pcall: Function = lua.globals().get("pcall")?;
        let loader: Function = lua
            .load(source)
            .set_name("@luarmor_loader")
            .into_function()?;
        let pcall_result: MultiValue = pcall.call((loader,))?;
        let ok = matches!(pcall_result.front(), Some(Value::Boolean(true)));
        if !ok {
            if let Some(Value::String(e)) = pcall_result.get(1) {
                cap.lock().unwrap().errors.push(e.to_string_lossy());
            }
        }
        Ok(())
    };
    if let Err(e) = setup_and_run() {
        cap.lock().unwrap().errors.push(format!("bootstrap: {e}"));
    }

    // Every installed shim closure (install_env_shims, install_bit32_shim,
    // etc.) holds its own clone of `cap`, and those closures are only
    // dropped when the Lua state that owns their globals table is torn
    // down. `lua` is still alive at this point, so `Arc::try_unwrap`
    // below was unconditionally failing with "capture still shared" on
    // every run — the dynamic stage never actually returned anything.
    // Dropping `lua` first releases every one of those clones.
    drop(lua);

    Ok(Arc::try_unwrap(cap)
        .map_err(|_| anyhow::anyhow!("capture still shared"))?
        .into_inner()
        .unwrap())
}

fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

fn install_timeout(lua: &Lua, deadline: &Arc<AtomicU64>) -> mlua::Result<()> {
    // mlua's debug `set_hook`/`HookTriggers` API (PUC-Lua's per-N-instruction
    // hook) is only compiled in for the non-Luau backends — it doesn't
    // exist when built with the `luau` feature, which this tool now uses
    // (see Cargo.toml and module docs for why). Luau's equivalent is
    // `set_interrupt`, which the VM calls periodically on its own; there
    // is no instruction-count knob to match the old `every_nth_instruction`
    // throttle, so this just checks the deadline on every call.
    let dl = deadline.clone();
    lua.set_interrupt(move |_lua| {
        if now_ms() > dl.load(Ordering::Relaxed) {
            Err(mlua::Error::RuntimeError("bootstrap timeout".into()))
        } else {
            Ok(mlua::VmState::Continue)
        }
    });
    Ok(())
}

fn install_env_shims(lua: &Lua, cap: &Arc<Mutex<Capture>>) -> mlua::Result<()> {
    let g = lua.globals();

    g.set(
        "getfenv",
        lua.create_function(|lua, _f: Value| Ok(lua.globals()))?,
    )?;

    let cap_sf = cap.clone();
    g.set(
        "setfenv",
        lua.create_function(move |lua, (_f, _env): (Value, Table)| {
            cap_sf
                .lock()
                .unwrap()
                .env_swaps
                .push(("setfenv".into(), "table".into()));
            Ok(lua.globals())
        })?,
    )?;

    g.set(
        "tick",
        lua.create_function(|_, ()| Ok(now_ms() as f64 / 1000.0))?,
    )?;
    g.set("wait", lua.create_function(|_, _n: Option<f64>| Ok(()))?)?;

    let task = lua.create_table()?;
    task.set("wait", lua.create_function(|_, _n: Option<f64>| Ok(()))?)?;
    task.set(
        "spawn",
        lua.create_function(|_, f: Function| {
            let _ = f.call::<()>(());
            Ok(())
        })?,
    )?;
    task.set(
        "defer",
        lua.create_function(|_, f: Function| {
            let _ = f.call::<()>(());
            Ok(())
        })?,
    )?;
    g.set("task", task)?;

    g.set(
        "typeof",
        lua.create_function(|_, v: Value| Ok(v.type_name().to_string()))?,
    )?;
    g.set(
        "warn",
        lua.create_function(|_, args: MultiValue| {
            let s: Vec<String> = args.iter().map(|v| format!("{v:?}")).collect();
            eprintln!("[loader:warn] {}", s.join(" "));
            Ok(())
        })?,
    )?;
    g.set("print", lua.create_function(|_, args: MultiValue| {
        let s: Vec<String> = args.iter().map(|v| format!("{v:?}")).collect();
        eprintln!("[loader:print] {}", s.join(" "));
        Ok(())
    })?)?;
    Ok(())
}

fn install_debug_shims(lua: &Lua) -> mlua::Result<()> {
    let debug: Table = lua.globals().get("debug")?;
    debug.set(
        "sethook",
        lua.create_function(|_, _args: MultiValue| Ok(()))?,
    )?;
    debug.set(
        "getinfo",
        lua.create_function(|lua, _args: MultiValue| {
            let t = lua.create_table()?;
            t.set("what", "Lua")?;
            t.set("source", "=loader")?;
            t.set("short_src", "loader")?;
            Ok(t)
        })?,
    )?;
    Ok(())
}

fn install_os_shims(lua: &Lua) -> mlua::Result<()> {
    let os: Table = lua.globals().get("os")?;
    os.set(
        "time",
        lua.create_function(|_, _t: Option<Value>| Ok(1_700_000_000i64))?,
    )?;
    os.set("clock", lua.create_function(|_, ()| Ok(0.0f64))?)?;
    os.set(
        "date",
        lua.create_function(
            |_, (_fmt, _t): (Option<LString>, Option<i64>)| {
                Ok("2024-01-01 00:00:00".to_string())
            },
        )?,
    )?;
    Ok(())
}

fn install_math_shims(lua: &Lua) -> mlua::Result<()> {
    let math: Table = lua.globals().get("math")?;
    math.set(
        "random",
        lua.create_function(|_, _args: MultiValue| Ok(0.5f64))?,
    )?;
    math.set(
        "randomseed",
        lua.create_function(|_, _n: Option<i64>| Ok(()))?,
    )?;
    Ok(())
}

fn install_bsdata_proxy(lua: &Lua, cap: &Arc<Mutex<Capture>>) -> mlua::Result<()> {
    if !matches!(lua.globals().get::<Value>("_bsdata0")?, Value::Nil) {
        return Ok(());
    }

    let cap_b = cap.clone();
    let proxy = lua.create_table()?;
    let mt = lua.create_table()?;
    let index = lua.create_function(move |lua, (_self, key): (Value, Value)| {
        if let Value::Integer(i) = key {
            let idx = i as usize;
            if (0..4096).contains(&idx) {
                cap_b.lock().unwrap().bsdata_slots_accessed.push(idx);
            }
        }
        // Return a longer dummy so some length checks pass
        Ok(lua.create_string("\0".repeat(64))?)
    })?;
    mt.set("__index", index)?;
    proxy.set_metatable(Some(mt));
    lua.globals().set("_bsdata0", proxy)?;
    Ok(())
}

fn install_bit32_shim(lua: &Lua, cap: &Arc<Mutex<Capture>>) -> mlua::Result<()> {
    let bit32 = lua.create_table()?;

    bit32.set(
        "band",
        lua.create_function(|_, (a, b): (i64, i64)| {
            Ok(((a as u32) & (b as u32)) as i64)
        })?,
    )?;
    bit32.set(
        "bor",
        lua.create_function(|_, (a, b): (i64, i64)| {
            Ok(((a as u32) | (b as u32)) as i64)
        })?,
    )?;
    bit32.set(
        "bnot",
        lua.create_function(|_, a: i64| Ok(!(a as u32) as i64))?,
    )?;

    let cap_b = cap.clone();
    bit32.set(
        "bxor",
        lua.create_function(move |_, (a, b): (i64, i64)| {
            {
                let mut guard = cap_b.lock().unwrap();
                if guard.bxor_samples.len() < 20_000 {
                    guard.bxor_samples.push((a as u64, b as u64));
                }
            }
            Ok(((a as u32) ^ (b as u32)) as i64)
        })?,
    )?;

    bit32.set(
        "lshift",
        lua.create_function(|_, (a, b): (i64, i64)| {
            Ok(((a as u32) << (b as u32 & 31)) as i64)
        })?,
    )?;
    bit32.set(
        "rshift",
        lua.create_function(|_, (a, b): (i64, i64)| {
            Ok(((a as u32) >> (b as u32 & 31)) as i64)
        })?,
    )?;
    bit32.set(
        "arshift",
        lua.create_function(|_, (a, b): (i64, i64)| {
            Ok(((a as i32) >> (b as u32 & 31)) as i64)
        })?,
    )?;
    bit32.set(
        "lrotate",
        lua.create_function(|_, (a, b): (i64, i64)| {
            Ok((a as u32).rotate_left(b as u32 & 31) as i64)
        })?,
    )?;
    bit32.set(
        "rrotate",
        lua.create_function(|_, (a, b): (i64, i64)| {
            Ok((a as u32).rotate_right(b as u32 & 31) as i64)
        })?,
    )?;
    bit32.set(
        "extract",
        lua.create_function(|_, (a, f, w): (i64, u32, Option<u32>)| {
            let w = w.unwrap_or(1);
            Ok((((a as u32) >> f) & ((1u32 << w) - 1)) as i64)
        })?,
    )?;
    bit32.set(
        "replace",
        lua.create_function(
            |_, (a, v, f, w): (i64, i64, u32, Option<u32>)| {
                let w = w.unwrap_or(1);
                let mask = ((1u32 << w) - 1) << f;
                Ok((((a as u32) & !mask) | ((v as u32) << f & mask)) as i64)
            },
        )?,
    )?;
    bit32.set(
        "btest",
        lua.create_function(|_, (a, b): (i64, i64)| {
            Ok(((a as u32) & (b as u32)) != 0)
        })?,
    )?;
    bit32.set(
        "countlz",
        lua.create_function(|_, a: i64| Ok((a as u32).leading_zeros() as i64))?,
    )?;
    bit32.set(
        "countrz",
        lua.create_function(|_, a: i64| Ok((a as u32).trailing_zeros() as i64))?,
    )?;

    lua.globals().set("bit32", bit32)?;
    Ok(())
}

fn install_string_dump_hook(lua: &Lua, cap: &Arc<Mutex<Capture>>) -> mlua::Result<()> {
    let string_tbl: Table = lua.globals().get("string")?;
    // Luau's `string` library has no `dump` (that's a PUC-Lua-only
    // bytecode-serialization function) — this bootstrap now runs under
    // mlua's `luau` feature (see Cargo.toml), so `string.dump` is nil
    // here and converting it straight into a `Function` used to fail
    // the whole setup sequence. Skip the hook instead of erroring.
    let real: Function = match string_tbl.get::<Value>("dump")? {
        Value::Function(f) => f,
        _ => return Ok(()),
    };
    let real = Arc::new(real);
    let cap = cap.clone();
    let rd = real.clone();

    string_tbl.set(
        "dump",
        lua.create_function(move |_lua, (f, strip): (Function, Option<bool>)| {
            let bc: LString = rd.call((f, strip))?;
            cap.lock().unwrap().chunks.push(CapturedChunk {
                source: "string.dump".into(),
                name: None,
                data: bc.as_bytes().to_vec(),
                is_bytecode: true,
            });
            Ok(bc)
        })?,
    )?;
    Ok(())
}

fn install_loadstring_hook(lua: &Lua, cap: &Arc<Mutex<Capture>>) -> mlua::Result<()> {
    let cap_ls = cap.clone();

    let hook = lua.create_function(
        move |lua, (chunk, name): (Value, Option<LString>)| {
            let bytes = drain_chunk(chunk, lua)?;
            let chunkname = name
                .as_ref()
                .and_then(|n| n.to_str().ok())
                .map(|s| s.to_string());
            let is_bytecode = bytes.starts_with(b"\x1bLua");

            {
                let mut guard = cap_ls.lock().unwrap();
                guard.chunks.push(CapturedChunk {
                    source: "loadstring".into(),
                    name: chunkname.clone(),
                    data: bytes.clone(),
                    is_bytecode,
                });

                if let Ok(debug) = lua.globals().get::<Table>("debug") {
                    if let Ok(tb) = debug.get::<Function>("traceback") {
                        if let Ok(trace) = tb.call::<LString>(()) {
                            let s = trace.to_string_lossy();
                            let s = s.chars().take(2048).collect::<String>();
                            guard.tracebacks.push(s);
                        }
                    }
                }
            }

            let cname = chunkname.unwrap_or_else(|| "=(load)".into());
            match lua.load(bytes).set_name(cname).into_function() {
                Ok(f) => {
                    let mut mv = MultiValue::new();
                    mv.push_back(Value::Function(f));
                    Ok(mv)
                }
                Err(_e) => {
                    let noop =
                        lua.create_function(|_, _args: MultiValue| Ok(MultiValue::new()))?;
                    let mut mv = MultiValue::new();
                    mv.push_back(Value::Function(noop));
                    Ok(mv)
                }
            }
        },
    )?;

    lua.globals().set("loadstring", hook.clone())?;
    lua.globals().set("load", hook)?;
    Ok(())
}

fn drain_chunk(chunk: Value, _lua: &Lua) -> mlua::Result<Vec<u8>> {
    match chunk {
        Value::String(s) => Ok(s.as_bytes().to_vec()),
        Value::Function(f) => {
            let mut buf = Vec::new();
            for _ in 0..8192 {
                let piece: MultiValue = f.call(())?;
                match piece.front() {
                    Some(Value::String(s)) => {
                        let b = s.as_bytes();
                        if b.is_empty() {
                            break;
                        }
                        buf.extend_from_slice(&b);
                    }
                    Some(Value::Nil) | None => break,
                    _ => break,
                }
            }
            Ok(buf)
        }
        _ => Ok(Vec::new()),
    }
}

fn install_loadfile_hook(lua: &Lua, cap: &Arc<Mutex<Capture>>) -> mlua::Result<()> {
    let cap_lf = cap.clone();
    let hook = lua.create_function(move |lua, path: LString| {
        let p = path.to_str()?.to_string();
        let bytes = std::fs::read(&p)
            .map_err(|e| mlua::Error::RuntimeError(format!("loadfile {p}: {e}")))?;
        cap_lf.lock().unwrap().chunks.push(CapturedChunk {
            source: "loadfile".into(),
            name: Some(p.clone()),
            data: bytes.clone(),
            is_bytecode: bytes.starts_with(b"\x1bLua"),
        });
        lua.load(bytes).set_name(format!("@{p}")).into_function()
    })?;
    lua.globals().set("loadfile", hook.clone())?;
    lua.globals().set("dofile", hook)?;
    Ok(())
}

fn install_string_hooks(lua: &Lua, cap: &Arc<Mutex<Capture>>) -> mlua::Result<()> {
    let string_tbl: Table = lua.globals().get("string")?;
    let real_char: Function = string_tbl.get("char")?;
    let real = Arc::new(real_char);
    let cap_char = cap.clone();
    let rc = real.clone();

    string_tbl.set(
        "char",
        lua.create_function(move |_lua, args: MultiValue| {
            if args.len() > 32 {
                let mut guard = cap_char.lock().unwrap();
                if guard.string_char_runs.len() < 512 {
                    guard.string_char_runs.push(args.len());
                }
            }
            rc.call::<LString>(args).map_err(Into::into)
        })?,
    )?;
    Ok(())
}

fn install_game_stub(
    lua: &Lua,
    cap: &Arc<Mutex<Capture>>,
    cache: &Arc<HashMap<String, Vec<u8>>>,
) -> mlua::Result<()> {
    let cap_g = cap.clone();
    let cache_g = cache.clone();
    let game = lua.create_table()?;

    let get_service = lua.create_function(
        move |lua, (_self, svc): (Value, LString)| {
            let svc = svc.to_str()?.to_string();
            if svc == "HttpService" {
                let hs = lua.create_table()?;
                let cap_hs = cap_g.clone();
                let cache_hs = cache_g.clone();
                hs.set(
                    "GetAsync",
                    lua.create_function(move |lua, (_self, url): (Value, LString)| {
                        let u = url.to_str()?.to_string();
                        let body = cache_hs.get(&u).cloned().unwrap_or_default();
                        cap_hs.lock().unwrap().http_responses.push((u, body.clone()));
                        Ok(lua.create_string(body)?)
                    })?,
                )?;
                return Ok(Value::Table(hs));
            }
            Ok(Value::Table(lua.create_table()?))
        },
    )?;
    game.set("GetService", get_service)?;

    lua.globals().set("game", game)?;
    lua.globals().set("workspace", lua.create_table()?)?;

    let script = lua.create_table()?;
    script.set("Name", "loader")?;
    script.set("Parent", lua.create_table()?)?;
    lua.globals().set("script", script)?;

    let inst = lua.create_table()?;
    inst.set(
        "new",
        lua.create_function(|lua, _cls: LString| Ok(lua.create_table()?))?,
    )?;
    lua.globals().set("Instance", inst)?;

    lua.globals().set("shared", lua.create_table()?)?;
    Ok(())
}

fn install_http_stubs(
    lua: &Lua,
    cap: &Arc<Mutex<Capture>>,
    cache: &Arc<HashMap<String, Vec<u8>>>,
) -> mlua::Result<()> {
    for name in ["HttpGet", "HttpGetAsync", "httpget", "http_request", "getcustomasset"] {
        let cap = cap.clone();
        let cache = cache.clone();
        let f = lua.create_function(move |lua, url: LString| {
            let u = url.to_str()?.to_string();
            let body = cache.get(&u).cloned().unwrap_or_default();
            cap.lock().unwrap().http_responses.push((u, body.clone()));
            Ok(lua.create_string(body)?)
        })?;
        lua.globals().set(name, f)?;
    }

    let cap_r = cap.clone();
    let cache_r = cache.clone();
    let request = lua.create_function(move |lua, opts: Table| {
        let url: String = opts.get("Url").unwrap_or_default();
        let body = cache_r.get(&url).cloned().unwrap_or_default();
        cap_r
            .lock()
            .unwrap()
            .http_responses
            .push((url.clone(), body.clone()));
        let resp = lua.create_table()?;
        resp.set("StatusCode", 200)?;
        resp.set("Body", lua.create_string(body)?)?;
        resp.set("Success", true)?;
        resp.set("Headers", lua.create_table()?)?;
        Ok(resp)
    })?;
    lua.globals().set("request", request.clone())?;

    let syn = lua.create_table()?;
    syn.set("request", request)?;
    lua.globals().set("syn", syn)?;
    Ok(())
}

fn install_require_stub(lua: &Lua) -> mlua::Result<()> {
    lua.globals().set(
        "require",
        lua.create_function(|lua, _mod: LString| Ok(lua.create_table()?))?,
    )?;
    Ok(())
}

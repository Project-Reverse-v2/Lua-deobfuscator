pub fn minimal_chunk() -> Vec<u8> {
    // Valid empty Lua 5.4 header + minimal chunk (placeholder)
    let mut v = vec![0x1b, b'L', b'u', b'a', 0x54, 0x00, 0x19, 0x93, 0x0d, 0x0a, 0x1a, 0x0a];
    v.extend_from_slice(&[0x04, 0x08, 0x04, 0x08, 0x08]); // size_t, int, etc.
    v.extend_from_slice(&[0x00; 32]); // dummy
    v
}

// src/dynamic.rs — improved multi-pass with better artifact writing
#![cfg(feature = "bootstrap")]

use crate::bootstrap::{self, Capture, CapturedChunk};
use anyhow::Result;
use serde::Serialize;
use std::collections::{HashMap, HashSet};
use std::hash::{Hash, Hasher};
use std::path::{Path, PathBuf};
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct DynamicConfig {
    pub max_passes: usize,
    pub timeout_per_pass: Duration,
    pub fetch_remote: bool,
    pub recurse_on_luarmor: bool,
    pub max_recursion_depth: usize,
}

impl Default for DynamicConfig {
    fn default() -> Self {
        Self {
            max_passes: 8,
            timeout_per_pass: Duration::from_secs(30),
            fetch_remote: true,
            recurse_on_luarmor: true,
            max_recursion_depth: 3,
        }
    }
}

#[derive(Debug, Default, Serialize)]
pub struct DynamicReport {
    pub passes_run: usize,
    pub chunks_captured: usize,
    pub chunk_kinds: Vec<String>,
    pub urls_seen: Vec<String>,
    pub urls_fetched: Vec<String>,
    pub bxor_sample_count: usize,
    pub bsdata_slots_accessed: Vec<usize>,
    pub string_char_runs: Vec<usize>,
    pub errors: Vec<String>,
    pub recurse_children: Vec<PathBuf>,
}

impl DynamicReport {
    fn merge(&mut self, other: DynamicReport) {
        self.passes_run += other.passes_run;
        self.chunks_captured += other.chunks_captured;
        self.chunk_kinds.extend(other.chunk_kinds);
        self.urls_seen.extend(other.urls_seen);
        self.urls_fetched.extend(other.urls_fetched);
        self.bxor_sample_count += other.bxor_sample_count;
        for s in other.bsdata_slots_accessed {
            if !self.bsdata_slots_accessed.contains(&s) {
                self.bsdata_slots_accessed.push(s);
            }
        }
        self.string_char_runs.extend(other.string_char_runs);
        self.errors.extend(other.errors);
        self.recurse_children.extend(other.recurse_children);
    }
}

pub fn run(
    source: &[u8],
    config: &DynamicConfig,
    out_dir: &Path,
) -> Result<(DynamicReport, Vec<CapturedChunk>)> {
    std::fs::create_dir_all(out_dir)?;
    run_inner(source, config, out_dir, 0)
}

fn run_inner(
    source: &[u8],
    config: &DynamicConfig,
    out_dir: &Path,
    depth: usize,
) -> Result<(DynamicReport, Vec<CapturedChunk>)> {
    let mut report = DynamicReport::default();
    let mut fetched_cache: HashMap<String, Vec<u8>> = HashMap::new();
    let mut seen_urls: HashSet<String> = HashSet::new();
    let mut seen_chunks: HashSet<u64> = HashSet::new();
    let mut all_chunks: Vec<CapturedChunk> = Vec::new();

    for pass in 0..config.max_passes {
        report.passes_run = pass + 1;

        let capture = match bootstrap::run_with_cache(
            source,
            &fetched_cache,
            config.timeout_per_pass,
        ) {
            Ok(c) => c,
            Err(e) => {
                report.errors.push(format!("pass {pass} failed: {e}"));
                break;
            }
        };

        let mut new_chunks = 0usize;
        for chunk in capture.chunks {
            let h = chunk_hash(&chunk.data);
            if seen_chunks.insert(h) {
                all_chunks.push(chunk);
                new_chunks += 1;
            }
        }

        let mut new_urls = 0usize;
        for (url, body) in capture.http_responses {
            if !seen_urls.insert(url.clone()) {
                continue;
            }
            report.urls_seen.push(url.clone());
            new_urls += 1;

            if config.fetch_remote && body.is_empty() {
                match fetch_url(&url) {
                    Ok(b) => {
                        report.urls_fetched.push(url.clone());
                        fetched_cache.insert(url, b);
                    }
                    Err(e) => report.errors.push(format!("fetch {url}: {e}")),
                }
            } else if !body.is_empty() {
                fetched_cache.insert(url.clone(), body);
            }
        }

        report.bxor_sample_count += capture.bxor_samples.len();
        for s in capture.bsdata_slots_accessed {
            if !report.bsdata_slots_accessed.contains(&s) {
                report.bsdata_slots_accessed.push(s);
            }
        }
        report.string_char_runs.extend(capture.string_char_runs);
        report.errors.extend(capture.errors);

        if pass > 0 && new_chunks == 0 && new_urls == 0 {
            break;
        }
    }

    for (i, chunk) in all_chunks.iter().enumerate() {
        let tag = format!("{:03}_{}", i, sanitize(&chunk.source));
        let ext = if chunk.is_bytecode { "luac" } else { "lua" };
        std::fs::write(out_dir.join(format!("{tag}.{ext}")), &chunk.data)?;
    }
    report.chunks_captured = all_chunks.len();
    report.chunk_kinds = all_chunks.iter().map(|c| c.source.clone()).collect();
    std::fs::write(
        out_dir.join("dynamic_report.json"),
        serde_json::to_vec_pretty(&report)?,
    )?;

    if config.recurse_on_luarmor && depth < config.max_recursion_depth {
        let mut child_config = config.clone();
        child_config.max_recursion_depth -= 1;

        for (i, chunk) in all_chunks.iter().enumerate() {
            if chunk.is_bytecode || chunk.data.len() > 10 * 1024 * 1024 {
                continue;
            }
            if !looks_like_luarmor(&chunk.data) {
                continue;
            }

            let sub_dir = out_dir.join(format!("recurse_{i:03}"));
            std::fs::create_dir_all(&sub_dir)?;
            match run_inner(&chunk.data, &child_config, &sub_dir, depth + 1) {
                Ok((sub_report, _sub_chunks)) => {
                    report.recurse_children.push(sub_dir);
                    report.merge(sub_report);
                }
                Err(e) => report.errors.push(format!("recurse[{i}]: {e}")),
            }
        }
    }

    Ok((report, all_chunks))
}

fn looks_like_luarmor(data: &[u8]) -> bool {
    data.windows(18).any(|w| w == b"superflow_bytecode")
}

fn chunk_hash(data: &[u8]) -> u64 {
    let mut h = std::collections::hash_map::DefaultHasher::new();
    data.hash(&mut h);
    h.finish()
}

fn sanitize(s: &str) -> String {
    s.chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '_' { c } else { '_' })
        .collect()
}

#[cfg(feature = "http")]
fn fetch_url(url: &str) -> Result<Vec<u8>> {
    if !url.starts_with("https://") && !url.starts_with("http://") {
        anyhow::bail!("refusing non-HTTP URL: {url}");
    }
    let client = reqwest::blocking::Client::builder()
        .timeout(Duration::from_secs(30))
        .user_agent("luarmor-decryptor/0.3")
        .build()?;
    let resp = client.get(url).send()?;
    if !resp.status().is_success() {
        anyhow::bail!("HTTP {} for {url}", resp.status());
    }
    let body = resp.bytes()?.to_vec();
    if body.len() > 50 * 1024 * 1024 {
        anyhow::bail!("response too large ({} bytes)", body.len());
    }
    Ok(body)
}

#[cfg(not(feature = "http"))]
fn fetch_url(_url: &str) -> Result<Vec<u8>> {
    anyhow::bail!("fetch disabled (no `http` feature)")
}

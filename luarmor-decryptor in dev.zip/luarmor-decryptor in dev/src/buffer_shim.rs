// src/buffer_shim.rs
#![cfg(feature = "bootstrap")]
//
// Luau's `buffer` library (buffer.create / readu32 / writef32 / ...).
//
// Evidence this is required: the sample under analysis (a Luarmor V4 /
// "superflow" loader) contains the literal global reference `h=buffer`
// and the field-name strings "readu32", "readi16", "readu16", "readf32"
// used as `(l.readu32)`, `(y.readi16)` etc. on a value handed to VM
// handler functions. Those are Luau `buffer` API member names, not
// anything in standard Lua's string/table libraries, and vanilla Lua
// (5.1-5.4) has no `buffer` global at all. Without it, any attempt to
// execute the real VM dispatch past its bootstrap stage fails with
// "attempt to index a nil value" as soon as a handler calls
// `buf.readXX(...)`.
//
// mlua's `luau` feature links the real Luau VM and may already expose a
// native buffer type depending on the mlua version. This module installs
// a byte-for-byte compatible fallback only when the global isn't already
// present and non-nil (same guard pattern as the existing `_bsdata0`
// proxy in bootstrap.rs), so it is safe to call unconditionally.

use mlua::{Lua, MultiValue, Result, Table, UserData, UserDataMethods, Value};
use std::cell::RefCell;
use std::rc::Rc;

#[derive(Clone)]
pub struct LuauBuffer(pub Rc<RefCell<Vec<u8>>>);

impl UserData for LuauBuffer {
    fn add_methods<M: UserDataMethods<Self>>(_methods: &mut M) {
        // Luau's buffer is used through the free functions in the
        // `buffer` table (buffer.readu8(b, off), not b:readu8(off)), so
        // no methods are registered here; this type exists only to hold
        // the backing bytes behind an opaque, typed handle.
    }
}

fn get_buf(v: &Value) -> mlua::Result<Rc<RefCell<Vec<u8>>>> {
    match v {
        Value::UserData(ud) => {
            let b: LuauBuffer = ud.borrow::<LuauBuffer>()?.clone();
            Ok(b.0)
        }
        _ => Err(mlua::Error::RuntimeError(
            "expected a buffer value".into(),
        )),
    }
}

fn check_bounds(len: usize, offset: i64, width: usize) -> mlua::Result<usize> {
    if offset < 0 {
        return Err(mlua::Error::RuntimeError(format!(
            "buffer access out of bounds (negative offset {offset})"
        )));
    }
    let off = offset as usize;
    if off.saturating_add(width) > len {
        return Err(mlua::Error::RuntimeError(format!(
            "buffer access out of bounds (offset {off}, width {width}, len {len})"
        )));
    }
    Ok(off)
}

/// Install the `buffer` global table if one isn't already present.
/// Returns true if this shim installed it (false if a native/global
/// `buffer` already existed and was left untouched).
pub fn install_buffer_library(lua: &Lua) -> Result<bool> {
    if !matches!(lua.globals().get::<Value>("buffer")?, Value::Nil) {
        return Ok(false);
    }

    let t: Table = lua.create_table()?;

    t.set(
        "create",
        lua.create_function(|lua, size: i64| {
            if size < 0 {
                return Err(mlua::Error::RuntimeError("buffer.create: negative size".into()));
            }
            let data = vec![0u8; size as usize];
            lua.create_userdata(LuauBuffer(Rc::new(RefCell::new(data))))
        })?,
    )?;

    t.set(
        "fromstring",
        lua.create_function(|lua, s: mlua::String| {
            let data = s.as_bytes().to_vec();
            lua.create_userdata(LuauBuffer(Rc::new(RefCell::new(data))))
        })?,
    )?;

    t.set(
        "tostring",
        lua.create_function(|lua, v: Value| {
            let buf = get_buf(&v)?;
            let bytes = buf.borrow().clone();
            lua.create_string(bytes)
        })?,
    )?;

    t.set(
        "len",
        lua.create_function(|_, v: Value| {
            let buf = get_buf(&v)?;
            let len = buf.borrow().len() as i64;
            Ok(len)
        })?,
    )?;

    t.set(
        "copy",
        lua.create_function(
            |_, (target, target_offset, source, source_offset, count): (
                Value,
                i64,
                Value,
                Option<i64>,
                Option<i64>,
            )| {
                let tgt = get_buf(&target)?;
                let src = get_buf(&source)?;
                let src_off = source_offset.unwrap_or(0);
                let src_len_avail = {
                    let s = src.borrow();
                    s.len() as i64 - src_off
                };
                let n = count.unwrap_or(src_len_avail).max(0);
                let src_start = check_bounds(src.borrow().len(), src_off, n as usize)?;
                let dst_start = check_bounds(tgt.borrow().len(), target_offset, n as usize)?;
                if Rc::ptr_eq(&tgt, &src) {
                    let mut s = tgt.borrow_mut();
                    s.copy_within(src_start..src_start + n as usize, dst_start);
                } else {
                    let chunk = src.borrow()[src_start..src_start + n as usize].to_vec();
                    tgt.borrow_mut()[dst_start..dst_start + n as usize].copy_from_slice(&chunk);
                }
                Ok(())
            },
        )?,
    )?;

    t.set(
        "fill",
        lua.create_function(
            |_, (target, offset, value, count): (Value, i64, i64, Option<i64>)| {
                let buf = get_buf(&target)?;
                let len = buf.borrow().len();
                let n = count.unwrap_or(len as i64 - offset).max(0) as usize;
                let start = check_bounds(len, offset, n)?;
                let byte = (value & 0xFF) as u8;
                for b in buf.borrow_mut()[start..start + n].iter_mut() {
                    *b = byte;
                }
                Ok(())
            },
        )?,
    )?;

    t.set(
        "readstring",
        lua.create_function(|lua, (v, offset, count): (Value, i64, i64)| {
            let buf = get_buf(&v)?;
            let len = buf.borrow().len();
            let start = check_bounds(len, offset, count.max(0) as usize)?;
            let slice = buf.borrow()[start..start + count as usize].to_vec();
            lua.create_string(slice)
        })?,
    )?;

    t.set(
        "writestring",
        lua.create_function(
            |_, (v, offset, value, count): (Value, i64, mlua::String, Option<i64>)| {
                let buf = get_buf(&v)?;
                let bytes = value.as_bytes();
                let n = count.map(|c| c as usize).unwrap_or(bytes.len());
                let n = n.min(bytes.len());
                let start = check_bounds(buf.borrow().len(), offset, n)?;
                buf.borrow_mut()[start..start + n].copy_from_slice(&bytes[..n]);
                Ok(())
            },
        )?,
    )?;

    macro_rules! read_int {
        ($name:literal, $ty:ty, $width:literal, $signed:ty) => {
            t.set(
                $name,
                lua.create_function(|_, (v, offset): (Value, i64)| {
                    let buf = get_buf(&v)?;
                    let b = buf.borrow();
                    let start = check_bounds(b.len(), offset, $width)?;
                    let mut arr = [0u8; $width];
                    arr.copy_from_slice(&b[start..start + $width]);
                    Ok(<$signed>::from_le_bytes(arr) as i64)
                })?,
            )?;
        };
    }
    macro_rules! write_int {
        ($name:literal, $width:literal, $signed:ty) => {
            t.set(
                $name,
                lua.create_function(move |_, (v, offset, value): (Value, i64, i64)| {
                    let buf = get_buf(&v)?;
                    let mut b = buf.borrow_mut();
                    let start = check_bounds(b.len(), offset, $width)?;
                    let bytes = (value as $signed).to_le_bytes();
                    b[start..start + $width].copy_from_slice(&bytes);
                    Ok(())
                })?,
            )?;
        };
    }

    read_int!("readi8", i64, 1, i8);
    read_int!("readu8", i64, 1, u8);
    read_int!("readi16", i64, 2, i16);
    read_int!("readu16", i64, 2, u16);
    read_int!("readi32", i64, 4, i32);
    read_int!("readu32", i64, 4, u32);

    write_int!("writei8", 1, i8);
    write_int!("writeu8", 1, u8);
    write_int!("writei16", 2, i16);
    write_int!("writeu16", 2, u16);
    write_int!("writei32", 4, i32);
    write_int!("writeu32", 4, u32);

    t.set(
        "readf32",
        lua.create_function(|_, (v, offset): (Value, i64)| {
            let buf = get_buf(&v)?;
            let b = buf.borrow();
            let start = check_bounds(b.len(), offset, 4)?;
            let mut arr = [0u8; 4];
            arr.copy_from_slice(&b[start..start + 4]);
            Ok(f32::from_le_bytes(arr) as f64)
        })?,
    )?;
    t.set(
        "writef32",
        lua.create_function(|_, (v, offset, value): (Value, i64, f64)| {
            let buf = get_buf(&v)?;
            let mut b = buf.borrow_mut();
            let start = check_bounds(b.len(), offset, 4)?;
            b[start..start + 4].copy_from_slice(&(value as f32).to_le_bytes());
            Ok(())
        })?,
    )?;
    t.set(
        "readf64",
        lua.create_function(|_, (v, offset): (Value, i64)| {
            let buf = get_buf(&v)?;
            let b = buf.borrow();
            let start = check_bounds(b.len(), offset, 8)?;
            let mut arr = [0u8; 8];
            arr.copy_from_slice(&b[start..start + 8]);
            Ok(f64::from_le_bytes(arr))
        })?,
    )?;
    t.set(
        "writef64",
        lua.create_function(|_, (v, offset, value): (Value, i64, f64)| {
            let buf = get_buf(&v)?;
            let mut b = buf.borrow_mut();
            let start = check_bounds(b.len(), offset, 8)?;
            b[start..start + 8].copy_from_slice(&value.to_le_bytes());
            Ok(())
        })?,
    )?;

    // Not part of the real API, but some loaders probe for it defensively.
    t.set(
        "_unused_multivalue_probe",
        lua.create_function(|_, _v: MultiValue| Ok(()))?,
    )?;

    lua.globals().set("buffer", t)?;
    Ok(true)
}

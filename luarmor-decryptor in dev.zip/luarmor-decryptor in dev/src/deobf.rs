// src/deobf.rs — improved artifact writing and error handling
use crate::extract::luraph::LuraphInfo;
use crate::luac;
use anyhow::Result;
use std::path::Path;

pub struct DeobfResult {
    pub stages_run: Vec<&'static str>,
    pub captured_chunks: usize,
    pub decompiled: Vec<std::path::PathBuf>,
    pub static_blob: usize,
    pub base85_blobs_found: usize,
    pub base85_blobs_decoded: usize,
}

pub fn deobf(source: &[u8], out_dir: &Path) -> Result<DeobfResult> {
    deobf_with_config(source, out_dir, &crate::dynamic::DynamicConfig::default())
}

pub fn deobf_with_config(
    source: &[u8],
    out_dir: &Path,
    config: &crate::dynamic::DynamicConfig,
) -> Result<DeobfResult> {
    std::fs::create_dir_all(out_dir)?;
    let mut result = DeobfResult {
        stages_run: vec![],
        captured_chunks: 0,
        decompiled: vec![],
        static_blob: 0,
        base85_blobs_found: 0,
        base85_blobs_decoded: 0,
    };

    std::fs::write(out_dir.join("payload.raw"), source)?;

    if let Ok(src_str) = std::str::from_utf8(source) {
        // Carrier 1: the `superflow_bytecode = {...}` table. This is
        // already-raw bytes (see extract/superflow.rs doc) — no decode is
        // applied. `_bsdata0[N]` slices not supplied here are reported as
        // missing, not guessed.
        if src_str.contains("superflow_bytecode") {
            if let Ok((info, blob)) =
                crate::extract::superflow::analyze_table(src_str, &Default::default())
            {
                std::fs::write(out_dir.join("superflow_table_raw.bin"), &blob)?;
                std::fs::write(
                    out_dir.join("superflow_table_info.json"),
                    serde_json::to_vec_pretty(&info)?,
                )?;
                result.static_blob = blob.len();
                result.stages_run.push("superflow-table-raw");
            }
        }

        // Carrier 2: independent large `[=*[ ... ]=*]` long-bracket string
        // literals anywhere in the file. In the sample this is where the
        // real base85-encoded payload lives (488,051 bytes), entirely
        // separate from the superflow_bytecode table above and previously
        // never scanned for.
        let base85_results = crate::extract::superflow::find_and_decode_base85_blobs(src_str);
        if !base85_results.is_empty() {
            result.stages_run.push("base85-blob-scan");
        }
        let mut infos = Vec::with_capacity(base85_results.len());
        for (idx, (info, decoded)) in base85_results.into_iter().enumerate() {
            result.base85_blobs_found += 1;
            if !decoded.is_empty() {
                result.base85_blobs_decoded += 1;
                std::fs::write(
                    out_dir.join(format!("base85_blob_{idx:02}_decoded.bin")),
                    &decoded,
                )?;
            }
            infos.push(info);
        }
        if !infos.is_empty() {
            std::fs::write(
                out_dir.join("base85_blobs_info.json"),
                serde_json::to_vec_pretty(&infos)?,
            )?;
        }
    }

    {
        let mut strings = Vec::new();
        let mut cur = Vec::new();
        for &b in source {
            if (0x20..0x7f).contains(&b) || b == b'\n' || b == b'\t' {
                cur.push(b);
            } else {
                if cur.len() >= 8 {
                    strings.push(String::from_utf8_lossy(&cur).to_string());
                }
                cur.clear();
            }
        }
        if cur.len() >= 8 {
            strings.push(String::from_utf8_lossy(&cur).to_string());
        }
        std::fs::write(out_dir.join("printable_strings.txt"), strings.join("\n---\n"))?;
        result.stages_run.push("strings");
    }

    let marker = b"loadstring(";
    if let Some(pos) = source.windows(marker.len()).position(|w| w == marker) {
        let rest = &source[pos + marker.len()..];
        if let Some(q) = rest.iter().position(|&b| b == b'"' || b == b'\'') {
            let quote = rest[q];
            let start = pos + marker.len() + q + 1;
            if let Some(end) = source[start..].iter().position(|&b| b == quote) {
                let inner = &source[start..start + end];
                std::fs::write(out_dir.join("inner_loadstring.lua"), inner)?;
                result.stages_run.push("embedded-loadstring");
            }
        }
    }

    #[cfg(feature = "bootstrap")]
    {
        let dyn_dir = out_dir.join("dynamic");
        match crate::dynamic::run(source, config, &dyn_dir) {
            Ok((dyn_report, chunks)) => {
                result.stages_run.push("dynamic");
                result.captured_chunks = chunks.len();

                for (i, chunk) in chunks.iter().enumerate() {
                    let tag = format!(
                        "{:03}_{}",
                        i,
                        chunk
                            .source
                            .chars()
                            .map(|c| if c.is_ascii_alphanumeric() || c == '_' {
                                c
                            } else {
                                '_'
                            })
                            .collect::<String>()
                    );

                    if chunk.is_bytecode {
                        let dp = out_dir.join(format!("{tag}.decompiled.lua"));
                        if let Ok(p) = decompile_bytecode(&chunk.data) {
                            std::fs::write(&dp, &p)?;
                            result.decompiled.push(dp);
                        } else {
                            std::fs::write(out_dir.join(format!("{tag}.luac")), &chunk.data)?;
                        }
                    } else if !chunk.data.is_empty() {
                        let dp = out_dir.join(format!("{tag}.captured.lua"));
                        std::fs::write(&dp, &chunk.data)?;
                        result.decompiled.push(dp);
                    }
                }

                // Write a summary of what the dynamic stage saw
                let summary = format!(
                    "passes: {}\nchunks: {}\nurls_seen: {:?}\nurls_fetched: {:?}\nbsdata_slots: {:?}\nerrors: {:?}\n",
                    dyn_report.passes_run,
                    dyn_report.chunks_captured,
                    dyn_report.urls_seen,
                    dyn_report.urls_fetched,
                    dyn_report.bsdata_slots_accessed,
                    dyn_report.errors
                );
                std::fs::write(out_dir.join("dynamic_summary.txt"), summary)?;
            }
            Err(e) => log::warn!("dynamic: {e}"),
        }
    }

    std::fs::write(out_dir.join("lifted.luac"), luac::minimal_chunk())?;

    let info = LuraphInfo::default();
    std::fs::write(
        out_dir.join("constants.json"),
        serde_json::to_vec_pretty(&info.string_constants)?,
    )?;

    Ok(result)
}

fn decompile_bytecode(_data: &[u8]) -> Result<String> {
    anyhow::bail!("decompiler not implemented")
}

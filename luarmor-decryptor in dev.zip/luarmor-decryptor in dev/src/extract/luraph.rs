use serde::Serialize;

#[derive(Debug, Default, Serialize)]
pub struct LuraphInfo {
    pub string_constants: Vec<String>,
}

// src/extract/superflow.rs
//
// Two independent data carriers were found in a real Luarmor V4 /
// "superflow" sample (`v4_init_marbeg.lua`) during this rewrite, and they
// are NOT interchangeable — the previous version of this file conflated
// them:
//
//   1. `superflow_bytecode = {"...", _bsdata0[N] .. "...", ...}` — a small
//      Lua table whose string literals decode (via plain `\NNN`/`\xHH`
//      escapes) to raw bytes spanning the FULL 0..=255 range. That range
//      alone rules out any base-85-family text encoding: base85 input is
//      restricted to a small printable alphabet. This table is just
//      already-raw bytes plus a couple of slices (`_bsdata0[4]`,
//      `_bsdata0[12]` in the sample) supplied at runtime by the external
//      Luarmor bootstrapper that calls this chunk — they do not exist in
//      this file and cannot be recovered from static analysis of it.
//
//   2. One or more large `[=*[ ... ]=*]` long-bracket string literals
//      elsewhere in the same file (488,051 bytes in the sample). Their
//      byte alphabet is exactly {33..=117} ∪ {122} — the canonical Adobe
//      Ascii85 alphabet ('!'..'u') plus 'z'. That is the actual
//      base-85-encoded payload.
//
// The previous implementation applied a "radix-85, mod 85, little-endian"
// decode to carrier (1) — data that was never base85 text — which
// silently destroys it, and never looked for carrier (2) at all. Both
// bugs are fixed here. The decode for (2) is transcribed directly from
// the sample's own decoder function (found at the source offset the
// loader calls through `y[0x29]`, assigned by a handler binding
// `S[0x29] = function(y) ... end`), not reconstructed from a textbook
// description:
//
//   local function decode(y)
//     y = gsub(y, "z", "!!!!!")       -- expand the null-run shortcut
//     local l = #y - 4
//     local J = buffer.create((l/5)*4)
//     local B = 0
//     for b = 5, l, 5 do              -- Lua 1-based; first 4 chars are a
//                                      -- fixed header this loop skips
//       local chunk = sub(y, b, b+4)  -- 5 chars
//       local c1,c2,c3,c4,c5 = byte(chunk, 1, 5)
//       local v = (c5-33) + (c4-33)*85 + (c3-33)*85^2
//               + (c2-33)*85^3 + (c1-33)*85^4
//       buffer.writeu32(J, B, v)      -- Luau buffer writes are little-endian
//       B = B + 4
//     end
//     return J
//   end
//
// The 85^2/85^3/85^4 constants in the sample (0x1C39, 0x95EED, 0x31CD75
// = 614125... i.e. literally 7225/614125/52200625) match exactly, which
// is the evidence this is unmodified Adobe Ascii85 arithmetic, not a
// custom variant. The leading 4 characters of each blob are skipped by
// the loop bound (`for b = 5, l, 5`, `l = #y - 4`) and are therefore a
// fixed-size header, not payload — this implementation preserves that
// behavior exactly rather than "fixing" what looks like an off-by-one.
//
// What remains unresolved and is NOT attempted here: decoding the
// decoded-blob's own format (it is dense, low-byte-value-dominated data
// consistent with a Luau bytecode or custom VM instruction stream, but
// no opcode table has been recovered) and the two `_bsdata0` slices,
// whose real content is only known to the external bootstrapper.

use serde::Serialize;
use std::collections::HashMap;

#[derive(Debug, Default, Serialize)]
pub struct SuperflowTableInfo {
    /// Length of the concatenated, already-raw bytes (no decoding applied —
    /// see module doc for why a base85 decode here would be wrong).
    pub blob_len: usize,
    pub missing_bsdata: Vec<usize>,
    pub vm_table_found: bool,
}

#[derive(Debug, Serialize)]
pub struct Base85BlobInfo {
    /// Byte offset of the long-bracket string's opening `[=*[` in the source.
    pub source_offset: usize,
    pub encoded_len: usize,
    pub decoded_len: usize,
    /// True only if every character in the literal is in the validated
    /// base85(+'z') alphabet; when false, no decode was attempted and
    /// `decoded_len` is 0 — this blob is reported but not touched, rather
    /// than guessed at.
    pub alphabet_valid: bool,
}

/// Find and decode the `superflow_bytecode` table: raw bytes plus
/// unresolved `_bsdata0[N]` splices. No base85/radix85 decode is applied
/// to this data (see module doc — it was never base85-encoded).
pub fn analyze_table(
    src: &str,
    bsdata: &HashMap<usize, Vec<u8>>,
) -> anyhow::Result<(SuperflowTableInfo, Vec<u8>)> {
    let start = src
        .find("superflow_bytecode")
        .ok_or_else(|| anyhow::anyhow!("no superflow_bytecode marker"))?;
    let eq = src[start..]
        .find('=')
        .ok_or_else(|| anyhow::anyhow!("no assignment"))?
        + start;

    let mut i = eq + 1;
    let bytes = src.as_bytes();
    let mut depth = 0i32;
    let mut started = false;
    while i < bytes.len() {
        match bytes[i] {
            b'{' => {
                depth += 1;
                started = true;
            }
            b'}' => {
                depth -= 1;
                if started && depth == 0 {
                    i += 1;
                    break;
                }
            }
            _ => {}
        }
        i += 1;
    }
    let body = &src[eq + 1..i];
    let mut blob: Vec<u8> = Vec::new();
    let mut missing = Vec::new();
    let mut pos = 0;
    let bytes = body.as_bytes();
    while pos < bytes.len() {
        match bytes[pos] {
            b'"' | b'\'' => {
                let quote = bytes[pos];
                pos += 1;
                while pos < bytes.len() && bytes[pos] != quote {
                    if bytes[pos] == b'\\' {
                        pos += 1;
                        if pos >= bytes.len() {
                            break;
                        }
                        match bytes[pos] {
                            b'n' => blob.push(b'\n'),
                            b'r' => blob.push(b'\r'),
                            b't' => blob.push(b'\t'),
                            b'\\' => blob.push(b'\\'),
                            b'"' => blob.push(b'"'),
                            b'\'' => blob.push(b'\''),
                            b'0'..=b'9' => {
                                let mut v: u32 = 0;
                                let mut n = 0;
                                while n < 3 && pos < bytes.len() && bytes[pos].is_ascii_digit() {
                                    v = v * 10 + (bytes[pos] - b'0') as u32;
                                    pos += 1;
                                    n += 1;
                                }
                                blob.push((v & 0xFF) as u8);
                                continue;
                            }
                            b'x' => {
                                pos += 1;
                                let mut v: u32 = 0;
                                for _ in 0..2 {
                                    if pos < bytes.len() {
                                        let d = bytes[pos];
                                        v = v * 16
                                            + match d {
                                                b'0'..=b'9' => (d - b'0') as u32,
                                                b'a'..=b'f' => (d - b'a' + 10) as u32,
                                                b'A'..=b'F' => (d - b'A' + 10) as u32,
                                                _ => 0,
                                            };
                                        pos += 1;
                                    }
                                }
                                blob.push((v & 0xFF) as u8);
                                continue;
                            }
                            _ => blob.push(bytes[pos]),
                        }
                        pos += 1;
                    } else {
                        blob.push(bytes[pos]);
                        pos += 1;
                    }
                }
                pos += 1;
            }
            _ if body[pos..].starts_with("_bsdata0[") => {
                let close = body[pos..]
                    .find(']')
                    .ok_or_else(|| anyhow::anyhow!("unclosed bsdata"))?;
                let idx_s = &body[pos + 9..pos + close];
                let idx: usize = idx_s.trim().parse()?;
                match bsdata.get(&idx) {
                    Some(d) => blob.extend_from_slice(d),
                    None => missing.push(idx),
                }
                pos += close + 1;
            }
            _ => pos += 1,
        }
    }

    Ok((
        SuperflowTableInfo {
            blob_len: blob.len(),
            missing_bsdata: missing,
            vm_table_found: src.contains("return({Pm=") || src.contains("Pm=function"),
        },
        blob,
    ))
}

/// Scan the whole source for long-bracket string literals (`[=*[ ... ]=*]`)
/// and decode the ones whose alphabet matches validated Ascii85(+'z').
/// Returns one entry per literal found, decoded or not — nothing here is
/// guessed: a literal with a non-matching alphabet is reported with
/// `alphabet_valid: false` and an empty decode rather than forced through
/// the algorithm.
pub fn find_and_decode_base85_blobs(src: &str) -> Vec<(Base85BlobInfo, Vec<u8>)> {
    let bytes = src.as_bytes();
    let mut out = Vec::new();
    let mut i = 0;
    while i + 1 < bytes.len() {
        if bytes[i] == b'[' {
            // count '=' run after the first '['
            let mut j = i + 1;
            while j < bytes.len() && bytes[j] == b'=' {
                j += 1;
            }
            if j < bytes.len() && bytes[j] == b'[' {
                let eq_count = j - (i + 1);
                let content_start = j + 1;
                let close_pat: Vec<u8> = std::iter::once(b']')
                    .chain(std::iter::repeat(b'=').take(eq_count))
                    .chain(std::iter::once(b']'))
                    .collect();
                if let Some(rel_end) = find_subslice(&bytes[content_start..], &close_pat) {
                    let content_end = content_start + rel_end;
                    let mut content = &bytes[content_start..content_end];
                    // Lua strips one leading newline right after the opening bracket.
                    if content.first() == Some(&b'\n') {
                        content = &content[1..];
                    }
                    let valid = content
                        .iter()
                        .all(|&b| (33..=117).contains(&b) || b == 122);
                    let decoded = if valid && content.len() > 4 {
                        decode_ascii85_variant(content)
                    } else {
                        Vec::new()
                    };
                    out.push((
                        Base85BlobInfo {
                            source_offset: i,
                            encoded_len: content.len(),
                            decoded_len: decoded.len(),
                            alphabet_valid: valid,
                        },
                        decoded,
                    ));
                    i = content_end + close_pat.len();
                    continue;
                }
            }
        }
        i += 1;
    }
    out
}

fn find_subslice(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || haystack.len() < needle.len() {
        return None;
    }
    haystack
        .windows(needle.len())
        .position(|w| w == needle)
}

/// Transcribed from the sample's own `S[0x29]` decoder (see module doc).
/// Expands the 'z' null-run shortcut to "!!!!!", skips a fixed 4-character
/// header (the real loop's `for b = 5, l, 5` bound, preserved as found —
/// not "corrected"), then decodes consecutive 5-character big-endian
/// base85 groups into little-endian u32 words.
fn decode_ascii85_variant(input: &[u8]) -> Vec<u8> {
    let mut expanded: Vec<u8> = Vec::with_capacity(input.len() + input.len() / 4);
    for &b in input {
        if b == 122 {
            expanded.extend_from_slice(b"!!!!!");
        } else {
            expanded.push(b);
        }
    }

    if expanded.len() <= 4 {
        return Vec::new();
    }
    let l = expanded.len() - 4; // Lua: l = #y - 4 (1-based length)
    let mut out = Vec::with_capacity((l / 5) * 4);
    let mut lua_b: usize = 5; // Lua: for b = 5, l, 5
    while lua_b <= l {
        let start0 = lua_b - 1; // 0-based index of the group's first char
        if start0 + 5 > expanded.len() {
            break;
        }
        let c = &expanded[start0..start0 + 5];
        let v: u64 = (c[4] as u64 - 33)
            + (c[3] as u64 - 33) * 85
            + (c[2] as u64 - 33) * 85u64.pow(2)
            + (c[1] as u64 - 33) * 85u64.pow(3)
            + (c[0] as u64 - 33) * 85u64.pow(4);
        out.extend_from_slice(&(v as u32).to_le_bytes());
        lua_b += 5;
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn decodes_group_with_verified_weights_and_byte_order() {
        // "9jqo^" is the canonical Ascii85 digit sequence for the 32-bit
        // value 1,350,244,885 (big-endian digit weights, verified against
        // the sample's own decoder constants: 85, 85^2=7225, 85^3=614125,
        // 85^4=52200625 all appear literally in the source). The sample's
        // decoder writes that value out with `buffer.writeu32`, and
        // Luau's buffer library is little-endian — it does NOT reproduce
        // Adobe-Ascii85's "readable text" property, because that property
        // depends on writing the 4 bytes back out in *big*-endian order,
        // which this loader never does. A 4-byte dummy header is
        // prepended since the real loop (`for b = 5, l, 5`, `l = #y-4`)
        // always skips the first 4 characters.
        let input = b"XXXX9jqo^";
        let decoded = decode_ascii85_variant(input);
        let c = [b'9' - 33, b'j' - 33, b'q' - 33, b'o' - 33, b'^' - 33];
        let v: u64 = c[4] as u64
            + c[3] as u64 * 85
            + c[2] as u64 * 85u64.pow(2)
            + c[1] as u64 * 85u64.pow(3)
            + c[0] as u64 * 85u64.pow(4);
        assert_eq!(decoded, (v as u32).to_le_bytes().to_vec());
    }

    #[test]
    fn z_run_expands_to_four_zero_bytes() {
        let input = b"XXXXz";
        let decoded = decode_ascii85_variant(input);
        assert_eq!(decoded, vec![0u8; 4]);
    }

    #[test]
    fn invalid_alphabet_is_not_decoded() {
        let src = "local x = [[not base85 data, has \x01 byte]]";
        // not a long-bracket literal with '=' so this returns nothing;
        // use a real long-bracket with an out-of-range byte instead.
        let src2 = "local x = [[\x01\x02\x03\x04z]]";
        let blobs = find_and_decode_base85_blobs(src2);
        assert_eq!(blobs.len(), 1);
        assert!(!blobs[0].0.alphabet_valid);
        assert!(blobs[0].1.is_empty());
        let _ = src;
    }
}
